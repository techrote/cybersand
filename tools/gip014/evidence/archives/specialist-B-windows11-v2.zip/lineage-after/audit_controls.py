"""Read a retained before report and check narrow deliberate audit mutations."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import audit_authored_lineage as audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('before_report', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    raw = audit.bounded(args.before_report)
    if audit.sha(raw) != '138e320b6bc8d4477e7a702abb1994c25f5357b523f27d47cda28f89e3d49221':
        raise ValueError('controls require the exact retained request3 before report')
    tape = audit.decode(raw)['cases'][0]['transcript']
    initial = tape['initialization']
    native, receipt = initial['observation']['native'], initial['native_receipt']
    saved = tape['steps'][-2]
    checks = {'actual_prior_canonical_receipt': audit.construction(receipt, native)}
    changed, observed = deepcopy(receipt), deepcopy(native)
    changed['session_generation'] += 1
    observed['generation'] += 1
    checks['outer_generation_relabel_rejected'] = not audit.construction(changed, observed)
    changed = deepcopy(receipt)
    changed['canonical_bytes'][4] ^= 1
    changed['receipt_hash'] = audit.sha(bytes(map(int, changed['canonical_bytes'])))
    checks['rehashed_wrong_domain_rejected'] = not audit.construction(changed, native)
    changed = deepcopy(receipt)
    changed['schema_version'] = True
    checks['boolean_schema_rejected'] = not audit.construction(changed, native)
    checks['actual_prior_full_capture'] = audit.capture_valid(saved['persistence_capture'], saved['after'])
    observed = deepcopy(saved['after'])
    observed['native']['generation'] += 1
    checks['stale_capture_observation_rejected'] = not audit.capture_valid(saved['persistence_capture'], observed)
    changed = deepcopy(saved['persistence_capture'])
    changed['native_receipt'] = {}
    checks['missing_capture_receipt_rejected'] = not audit.capture_valid(changed, saved['after'])
    checks['actual_authored_rectangle_interpretation'] = audit.authored_plane(tape['initial_authored_fixture']) == audit.AUTHORED_SHA
    changed = deepcopy(tape['initial_authored_fixture'])
    changed['edits'][0][4] = 2 if changed['edits'][0][4] != 2 else 58
    checks['changed_authored_material_changes_digest'] = audit.authored_plane(changed) != audit.AUTHORED_SHA
    changed = deepcopy(tape['initial_authored_fixture'])
    changed['edits'][0][0] = 512
    try:
        audit.authored_plane(changed)
        checks['outside_authored_bounds_rejected'] = False
    except ValueError:
        checks['outside_authored_bounds_rejected'] = True
    checks['boolean_native_counter_rejected'] = not audit.integer(True)
    checks['huge_integer_rejected_without_overflow'] = not audit.integer(10**1000)
    checks['both_fixed_candidate_registrations'] = all(audit.sha((audit.HERE / name).read_bytes()) in audit.REGISTERED_PINS
        for name in ('candidate-pins.json', 'candidate-pins-request10.json'))
    result = {'scope': 'previous raw observations plus deliberate in-memory audit controls; no new native gameplay',
              'before_report_sha256': audit.sha(raw), 'audit_script_sha256': audit.sha(Path(audit.__file__).read_bytes()),
              'controls_script_sha256': audit.sha(Path(__file__).read_bytes()),
              'checks': checks, 'status': 'pass' if all(checks.values()) else 'fail'}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, sort_keys=True))
    return 0 if result['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
