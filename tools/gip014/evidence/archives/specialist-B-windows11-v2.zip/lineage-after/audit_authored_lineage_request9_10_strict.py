#!/usr/bin/env python3
"""Read retained authored-lineage evidence only; never launches or alters the game.

Candidate pins are immutable, separately registered source identities. A missing
report, failed process or failed relationship remains an unsuccessful audit.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import struct
import sys
import zipfile

HERE = Path(__file__).resolve().parent
REGISTERED_PINS = {
    "de8f30312eb9c945058f6cf0fffa2cd49f8a2bb29e401b0125064464a5922c74",  # request9: original parse failure
    "e1761ab5aa43b4c206a7b2f7dcb8d1b9154602e8c6b87838555c1694c8afd339",  # request10: explicit-bool gate only
}
MARKER = "GOBLIN_AUTHORED_LINEAGE_RESULT "
SCRIPT = "res://goblin/tests/test_authored_lineage.gd"
AUTHORED_SHA = "acea5f8e573d757af5c560778bbd2222f96065c298e62fcfb8996817486da14a"
FRESH = {"reopen_layout", "restore_start"}
RETAINING = {"actor_place", "actor_reset", "actor_remove", "response_mode"}
CASES = {
    "fresh_authored": ([('save_layout', {}), ('reopen_layout', {})], True),
    "retained_evolved": ([('play', {'ticks': 16}), ('pause', {}),
                           ('response_mode', {'mode': 'LA-EVENT-OFF'}), ('save_layout', {}), ('reopen_layout', {})], False),
    "restore_authored": ([('play', {'ticks': 16}), ('pause', {}),
                           ('response_mode', {'mode': 'LA-EVENT-OFF'}), ('restore_start', {}),
                           ('save_layout', {}), ('reopen_layout', {})], True),
    "actor_reset_retains_evolved": ([('actor_place', {'model': 'kestrel', 'x': 256, 'y': 96}),
                                     ('play', {'ticks': 16}), ('pause', {}), ('actor_reset', {}),
                                     ('actor_remove', {}), ('save_layout', {}), ('reopen_layout', {})], False),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bounded(path, limit=8 * 1024 * 1024):
    with Path(path).open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('oversized input: ' + str(path))
    return raw


def decode(raw):
    def reject(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(raw.decode('utf-8-sig'), parse_constant=reject)


def integer(value):
    return type(value) in (int, float) and 0 <= value <= 2**53 and math.isfinite(value) and value == int(value)


def source(observed):
    return {key: observed.get(key) for key in ('generation', 'revision', 'tick')}


def native_valid(native):
    return isinstance(native, dict) and all(integer(native.get(key)) for key in ('generation', 'revision', 'tick')) \
        and native.get('failed') is False and type(native.get('paused')) is bool


def construction(receipt, native):
    if not isinstance(receipt, dict) or not native_valid(native):
        return False
    values = receipt.get('canonical_bytes')
    if not isinstance(values, list) or not 52 <= len(values) <= 1048576 \
            or not all(integer(v) and v <= 255 for v in values):
        return False
    raw = bytes(map(int, values))
    return (receipt.get('kind') == 'applied_run' and integer(receipt.get('schema_version')) and receipt['schema_version'] == 1
            and integer(receipt.get('completed_tick')) and receipt['completed_tick'] == 0
            and integer(receipt.get('session_generation')) and receipt['session_generation'] == native['generation']
            and raw[:4] == struct.pack('<I', 24) and raw[4:28] == b'cybersand-run-receipt-v1'
            and struct.unpack_from('<H', raw, 28)[0] == 1
            and struct.unpack_from('<QQ', raw, 36) == (native['generation'], 0)
            and sha(raw) == receipt.get('receipt_hash'))


def authored_plane(fixture):
    if fixture.get('extent') != [512, 512] or not isinstance(fixture.get('edits'), list) or len(fixture['edits']) > 32:
        raise ValueError('outside finite authored rectangle contract')
    plane = bytearray(512 * 512 * 4)
    for entry in fixture['edits']:
        if not isinstance(entry, list) or len(entry) != 5 or not all(integer(v) for v in entry):
            raise ValueError('invalid authored rectangle')
        x, y, width, height, material = map(int, entry)
        if width <= 0 or height <= 0 or x + width > 512 or y + height > 512 or material > 131:
            raise ValueError('authored rectangle outside admitted bounds')
        segment = struct.pack('<i', material) * width
        for yy in range(y, y + height):
            start = 4 * (yy * 512 + x)
            plane[start:start + len(segment)] = segment
    return sha(plane)


def capture_valid(captured, observed):
    native = observed.get('native', {})
    if not isinstance(captured, dict) or not native_valid(native):
        return False
    receipt, admission = captured.get('native_receipt', {}), captured.get('admission', {})
    checksum = captured.get('material_sha256')
    if (not isinstance(receipt, dict) or not isinstance(admission, dict) or 'error' in captured
            or captured.get('source_matches') is not True or captured.get('count') != 262144
            or captured.get('region') != [0, 0, 512, 512] or receipt.get('region') != [0, 0, 512, 512]
            or not isinstance(checksum, str) or re.fullmatch('[0-9a-f]{64}', checksum) is None
            or observed.get('paused') is not True or native.get('paused') is not True
            or receipt.get('status') != 'completed' or receipt.get('kind') != 'capture'
            or receipt.get('backend') != 'CyberNativeCellWorld' or admission.get('status') != 'queued'
            or not integer(admission.get('operation_id')) or receipt.get('operation_id') != admission['operation_id']
            or receipt.get('observed_generation') != native['generation']):
        return False
    return all(isinstance(captured.get(side), dict) and captured[side].get('paused') is True
               and captured[side].get('failed') is False and source(captured[side]) == source(native)
               for side in ('source_before', 'source_after')) and source(receipt) == source(native)


class Audit:
    def __init__(self):
        self.checks = []
        self.cases = []
        self.identities = {}

    def check(self, key, condition, observed=None):
        row = {'id': key, 'pass': bool(condition)}
        if observed is not None:
            row['observed'] = observed
        self.checks.append(row)
        return bool(condition)

    def file(self, name, path, limit=8 * 1024 * 1024):
        raw = bounded(path, limit)
        self.identities[name] = {'path': str(Path(path).resolve()), 'bytes': len(raw), 'sha256': sha(raw)}
        return raw

    def process(self, value, log, packaged):
        if 'tests' in value:
            candidates = [r for r in value['tests'] if r.get('case') == 'goblin_authored_lineage']
            if not self.check('one_native_process_receipt', len(candidates) == 1):
                return
            value = candidates[0]
        self.check('bounded_owned_process_pass', value.get('status') == 'pass' and value.get('exit_code') == 0
                   and value.get('interrupted') is False and value.get('surviving_owned_pids') == []
                   and value.get('diagnostic_errors') == [] and value.get('process_exit_status') == 'pass', value)
        self.check('process_resource_bounds', integer(value.get('memory_limit_mib'))
                   and 256 <= value['memory_limit_mib'] <= 3072
                   and type(value.get('elapsed_seconds')) in (int, float)
                   and type(value.get('timeout_seconds')) in (int, float)
                   and 0 < value['timeout_seconds'] <= 5400
                   and 0 <= value['elapsed_seconds'] <= value['timeout_seconds'] + 5)
        if not packaged:
            self.check('fixed_native_entrypoint', SCRIPT in value.get('command', []) and value.get('timeout_seconds') == 300)
            self.check('actual_native_log_custody', value.get('log_sha256') == sha(log) and value.get('log_bytes') == len(log))
            self.check('native_completion_acknowledged', value.get('completion_observed') is True and value.get('completion_marker') == MARKER)

    def lineage(self, label, observed, state, witness):
        native = observed.get('native', {})
        if not self.check(label + ':valid_native', native_valid(native)):
            return state, witness
        if native['tick'] > 0:
            state = 'simulation_exposed'
            witness = {'kind': 'native_progress', 'source': source(native)}
        claim = observed.get('material_lineage', {})
        self.check(label + ':lineage_state_source', observed.get('adapter_version') == 3
                   and claim.get('schema') == 'cybersand-goblin-material-lineage-v1'
                   and claim.get('state') == state and claim.get('source') == source(native))
        self.check(label + ':independent_latest_witness', claim.get('witness') == witness)
        return state, witness

    def case(self, case, provenance, reader):
        name = case.get('id')
        if not self.check('known_case', name in CASES, name):
            return
        actions, applicable = CASES[name]
        actions = [{'id': key, 'args': args} for key, args in actions]
        tape = case.get('transcript', {})
        rows, header = tape.get('steps', []), tape.get('header', {})
        prefix = name + ':'
        self.check(prefix + 'raw_case_pass', case.get('status') == 'pass' and bool(case.get('checks'))
                   and all(value is True for value in case.get('checks', {}).values()))
        self.check(prefix + 'exact_header', header.get('provenance') == provenance and header.get('fixture_id') == 'conservation_cell'
                   and header.get('policy') == 'CONTROL' and header.get('seed') == 13 and header.get('pacing_ms') == 0
                   and header.get('budget') == len(actions) and header.get('evidence_kind') in ('headless_godot', 'packaged_evaluator'))
        self.check(prefix + 'exact_literal_actions', [row.get('action') for row in rows] == actions)
        self.check(prefix + 'actual_terminal', tape.get('summary', {}).get('termination') == 'budget_complete'
                   and tape.get('summary', {}).get('attempted_actions') == len(actions)
                   and tape.get('summary', {}).get('completed_actions') == len(actions))
        checked = reader.verify(tape)
        self.check(prefix + 'independent_reader', checked.get('valid') is True and not checked.get('independent_failures')
                   and not checked.get('unreported_failures') and not checked.get('summary', {}).get('failures'), checked)
        initialization = tape.get('initialization', {})
        initial = initialization.get('observation', {})
        initial_native = initial.get('native', {})
        receipt = initialization.get('native_receipt', {})
        self.check(prefix + 'actual_initial_construction', initialization.get('ok') is True
                   and initial.get('paused') is True and initial_native.get('paused') is True and initial_native.get('tick') == 0
                   and construction(receipt, initial_native) and initial.get('scene_identity') == initial.get('authored_digest')
                   and bool(initial.get('scene_identity')))
        state = 'authored_compatible'
        witness = {'kind': 'authored_construction', 'action': 'fixture_install', 'source': source(initial_native),
                   'receipt_hash': receipt.get('receipt_hash')}
        state, witness = self.lineage(prefix + 'initial', initial, state, witness)
        completed = 0
        for index, row in enumerate(rows):
            label = prefix + str(index)
            before, after = row.get('before', {}), row.get('after', {})
            first, last = before.get('native', {}), after.get('native', {})
            complete = row.get('status') == 'completed' and row.get('admission', {}).get('accepted') is True
            completed += int(complete)
            self.check(label + ':admitted_completed', complete and row.get('classification') == 'game_observation')
            self.check(label + ':runtime_assertions_clean', bool(row.get('assertions'))
                       and all(item.get('status') != 'fail' for item in row.get('assertions', [])))
            state, witness = self.lineage(label + ':before', before, state, witness)
            key = row.get('action', {}).get('id')
            if key in FRESH | RETAINING:
                acknowledgement = row.get('native_receipt', {})
                self.check(label + ':actual_replacement', complete and native_valid(first) and native_valid(last)
                           and last['generation'] > first['generation'] and last['tick'] == 0
                           and construction(acknowledgement, last))
                if key in FRESH:
                    state = 'authored_compatible'
                    witness = {'kind': 'authored_construction', 'action': key, 'source': source(last),
                               'receipt_hash': acknowledgement.get('receipt_hash')}
            state, witness = self.lineage(label + ':after', after, state, witness)
        self.cases.append({'id': name, 'attempted_actions': len(rows), 'completed_actions': completed,
                           'original_termination': tape.get('summary', {}).get('termination')})
        if len(rows) != len(actions):
            return
        saved, reopened = rows[-2:]
        first, last = saved.get('persistence_capture', {}), reopened.get('persistence_capture', {})
        a, b = saved.get('persistence', {}), reopened.get('persistence', {})
        self.check(prefix + 'whole_save_capture', capture_valid(first, saved.get('after', {})))
        self.check(prefix + 'whole_reopen_capture', capture_valid(last, reopened.get('after', {})))
        self.check(prefix + 'saved_zero_clock', a.get('saved_native_tick') == b.get('saved_native_tick') == 0
                   and saved.get('after', {}).get('native', {}).get('tick') == 0)
        self.check(prefix + 'immutable_saved_proof', b.get('saved_capture') == first
                   and a.get('saved_material_lineage') == b.get('saved_material_lineage') == saved.get('after', {}).get('material_lineage'))
        self.check(prefix + 'material_digest_custody', first.get('material_sha256') == a.get('material_sha256') == b.get('saved_material_sha256')
                   and last.get('material_sha256') == b.get('reopened_material_sha256'))
        expected_state = 'authored_compatible' if applicable else 'simulation_exposed'
        reason = 'available' if applicable else 'simulation_exposed_lineage'
        self.check(prefix + 'required_applicability', a.get('saved_material_lineage', {}).get('state') == expected_state
                   and a.get('native_material_equality_applicable') is applicable and b.get('native_material_equality_applicable') is applicable
                   and a.get('native_material_equality_reason') == b.get('native_material_equality_reason') == reason)
        assertions = [item for item in reopened.get('assertions', []) if item.get('id') == 'authored_reopen_materials']
        self.check(prefix + 'required_equality_disposition', len(assertions) == 1
                   and assertions[0].get('status') == ('pass' if applicable else 'not_applicable'))
        digest = authored_plane(tape.get('initial_authored_fixture', {}))
        self.check(prefix + 'independent_authored_plane', digest == AUTHORED_SHA == last.get('material_sha256')
                   == case.get('independent_authored_material_sha256'))
        self.check(prefix + 'actual_saved_relation', (first.get('material_sha256') == digest) is applicable)
        if name in ('retained_evolved', 'restore_authored'):
            row = rows[2]
            self.check(prefix + 'positive_before_retaining_response', row['before']['native']['tick'] >= 16
                       and row['after']['material_lineage']['state'] == 'simulation_exposed')
        if name == 'actor_reset_retains_evolved':
            reset, removal = rows[3:5]
            self.check(prefix + 'selected_reset_retains_exposure', reset['before']['native']['tick'] >= 16
                       and reset['after']['material_lineage']['state'] == 'simulation_exposed')
            self.check(prefix + 'actual_removal_capture_precondition', removal['after'].get('actor_ids') == []
                       and removal['after'].get('physical_body_count') == 0
                       and removal['after']['material_lineage']['state'] == 'simulation_exposed')
        self.cases[-1].update(saved_source=source(saved['after']['native']), reopened_source=source(reopened['after']['native']),
                              saved_material_sha256=first.get('material_sha256'), reopened_material_sha256=last.get('material_sha256'),
                              expected_applicability=applicable)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pins', type=Path, default=HERE / 'candidate-pins.json')
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--provenance', type=Path, required=True, help='source provenance or package manifest JSON')
    parser.add_argument('--process', type=Path, required=True, help='source qualification or outer extracted process JSON')
    parser.add_argument('--log', type=Path, required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--source-archive', type=Path)
    group.add_argument('--payload-root', type=Path)
    parser.add_argument('--source-snapshot', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(argv)
    audit = Audit()
    archive = None
    error = None
    try:
        pin_raw = audit.file('candidate_pins', args.pins)
        if sha(pin_raw) not in REGISTERED_PINS:
            raise ValueError('candidate pins not independently preregistered')
        pins = decode(pin_raw)
        for name, checksum in pins['reader_sha256'].items():
            if sha(bounded(HERE / name)) != checksum:
                raise ValueError('frozen independent reader source changed: ' + name)
        sys.path.insert(0, str(HERE))
        spec = importlib.util.spec_from_file_location('frozen_lineage_reader', HERE / 'verify_transcript.py')
        reader = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(reader)
        provenance_document = decode(audit.file('provenance_document', args.provenance))
        provenance = provenance_document.get('provenance', provenance_document)
        platform = provenance.get('platform')
        audit.check('exact_source_identity', provenance.get('source_commit') == pins['source_commit']
                    and provenance.get('source_tree') == pins['source_tree'] and provenance.get('source_dirty') is False)
        audit.check('pinned_runtime_identity', platform in pins['runtime'] and provenance.get('godot_version') == '4.7.stable.official.5b4e0cb0f'
                    and all(provenance.get(key) == value for key, value in pins['runtime'].get(platform, {}).items()))
        if args.source_archive:
            archive_raw = audit.file('executed_source_archive', args.source_archive, 128 * 1024 * 1024)
            archive = zipfile.ZipFile(args.source_archive)
            names = archive.namelist()
            if len(names) > 4096 or len(names) != len(set(names)) or sum(item.file_size for item in archive.infolist()) > 256 * 1024 * 1024 \
                    or any(PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts for name in names):
                raise ValueError('unsafe or unbounded source archive')
            read_source = archive.read
            snapshot = decode(audit.file('source_snapshot', args.source_snapshot))
            mapping = snapshot['files']
            computed = sha(json.dumps(mapping, sort_keys=True, separators=(',', ':')).encode())
            audit.check('project_snapshot_identity', computed == snapshot.get('project_files_sha256') == provenance.get('project_files_sha256'))
            for name in names:
                audit.check('archived_bytes:' + name, sha(read_source(name)) == mapping.get(name))
        else:
            root = args.payload_root.resolve()
            def read_source(name):
                path = (root / 'godot' / name).resolve()
                if not path.is_relative_to(root / 'godot'):
                    raise ValueError('payload member outside package')
                return bounded(path)
        for name, checksum in pins['game_sha256'].items():
            raw = read_source(name)
            # These .gd files have exact portable bytes. The separately owned
            # four Rapier descriptor normalization rule does not apply here.
            audit.check('candidate_source:' + name, sha(raw) == checksum,
                        {'raw_sha256': sha(raw), 'expected_sha256': checksum, 'normalization': 'none'})
        native_manifest = 'addons/cybersand_native/runtime-provenance.linux.json' if platform == 'linux' else 'addons/cybersand_native/runtime-provenance.json'
        native_raw = read_source(native_manifest)
        native = decode(native_raw)
        audit.check('native_provenance_identity', sha(native_raw) == provenance.get('native_provenance_sha256')
                    and native.get('sha256') == provenance.get('native_sha256'))
        for name, checksum in pins['native_contract_inputs'].items():
            audit.check('native_contract_input:' + name, native.get('source_inputs', {}).get(name) == checksum)
        log = audit.file('native_log', args.log, 16 * 1024 * 1024)
        process = decode(audit.file('process_receipt', args.process))
        audit.process(process, log, args.payload_root is not None)
        lines = log.decode('utf-8-sig', errors='replace').splitlines()
        markers = [decode(line[len(MARKER):].encode()) for line in lines if line.startswith(MARKER)]
        audit.check('one_clean_native_marker', len(markers) == 1
                    and not any(word in log.decode('utf-8-sig', errors='replace') for word in ('SCRIPT ERROR:', 'Parse Error:', 'ERROR:', 'Fatal signal', 'Segmentation fault')))
        report = decode(audit.file('native_report', args.report))
        audit.check('raw_native_report', report.get('schema') == 'cybersand-goblin-authored-lineage-test-v1'
                    and report.get('status') == 'pass' and report.get('failures') == [] and report.get('provenance') == provenance
                    and bool(report.get('checks')) and all(value is True for value in report.get('checks', {}).values()))
        audit.check('marker_matches_raw_report', len(markers) == 1 and all(markers[0].get(key) == report.get(key)
                    for key in ('status', 'failures', 'actual_actions', 'checks', 'check_count')))
        cases = report.get('native_cases', [])
        audit.check('four_distinct_cases', len(cases) == 4 and {case.get('id') for case in cases} == set(CASES))
        for case in cases:
            try:
                audit.case(case, provenance, reader)
            except (ValueError, TypeError, KeyError, AttributeError, IndexError, OverflowError) as exc:
                audit.check('malformed_or_incomplete_case', False, {'case': case.get('id'), 'error': str(exc)})
        attempted = sum(case['attempted_actions'] for case in audit.cases)
        completed = sum(case['completed_actions'] for case in audit.cases)
        audit.check('twenty_actual_actions', attempted == completed == 20
                    and report.get('actual_actions') == {'attempted': attempted, 'completed': completed})
    except (OSError, ValueError, KeyError, TypeError, AttributeError, IndexError, zipfile.BadZipFile) as exc:
        error = type(exc).__name__ + ': ' + str(exc)
        audit.check('input_or_audit_incomplete', False, error)
    finally:
        if archive is not None:
            archive.close()
    failures = [item for item in audit.checks if not item['pass']]
    result = {'schema': 'cybersand-goblin-authored-lineage-independent-native-audit-v1',
              'status': 'pass' if not failures else 'incomplete' if error else 'fail',
              'scope': 'read-only native evidence adjudication; no new game execution',
              'package_wrapper_scope': ('supplemental to C full-package custody; outer receipt retained here, '
                                        'its own log and resource peak are independently checked by C') if args.payload_root else 'not applicable: source gate',
              'production_gameplay_defect_claimed': False, 'unchanged_invariant_corrective_pass_claimed': False,
              'audit_script_sha256': sha(Path(__file__).read_bytes()), 'identities': audit.identities,
              'checks': audit.checks, 'check_count': len(audit.checks), 'failures': failures, 'cases': audit.cases}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'checks': len(audit.checks), 'failures': len(failures),
                      'cases': audit.cases, 'output': str(args.out)}, sort_keys=True))
    return 0 if result['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
