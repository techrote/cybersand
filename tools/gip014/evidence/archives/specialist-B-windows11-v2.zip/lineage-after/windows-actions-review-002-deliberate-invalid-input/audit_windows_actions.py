"""Read actual registered6f Windows native action evidence; no game execution."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_tests', type=Path)
    parser.add_argument('payload', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    checks, files, specimens, groups = [], {}, {}, {}
    def read(path):
        with path.open('rb') as stream:
            raw = stream.read(32 * 1024 * 1024 + 1)
        if len(raw) > 32 * 1024 * 1024: raise ValueError('oversized read-only input')
        files[str(path)] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        return raw
    def check(name, value): checks.append({'id': name, 'pass': bool(value)})
    pins_raw = read(HERE / 'candidate-pins-request11.json')
    assert hashlib.sha256(pins_raw).hexdigest() == 'da7a0928d89a655c4ea93ff2a5bce4c877ecb261b353800c9905cab66df217db'
    pins = json.loads(pins_raw)
    for name, expected in pins['reader_sha256'].items():
        assert hashlib.sha256(read(HERE / name)).hexdigest() == expected
    sys.path.insert(0, str(HERE))
    spec = importlib.util.spec_from_file_location('frozen_reader6f', HERE / 'verify_transcript.py')
    reader = importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    adapter = read(args.payload / 'godot/goblin/goblin_adapter.gd').decode()
    actions = read(args.payload / 'godot/goblin/goblin_gameplay_actions.gd').decode()
    assert hashlib.sha256(adapter.encode()).hexdigest() == pins['game_sha256']['goblin/goblin_adapter.gd']
    assert hashlib.sha256(actions.encode()).hexdigest() == pins['game_sha256']['goblin/goblin_gameplay_actions.gd']
    old = re.search(r'const ACTION_IDS := \[(.*?)\] \+ Gameplay.IDS', adapter, re.S).group(1)
    extra = re.search(r'const IDS := \[(.*?)\]', actions, re.S).group(1)
    supported = set(re.findall(r'"([a-z_]+)"', old + extra)); added = set(re.findall(r'"([a-z_]+)"', extra))
    check('exact_finite_vocabulary', len(supported) == 55 and len(added) == 29)
    expanded = None
    for group in ['adapter', 'expanded', 'gameplay', 'metamorphic', 'control-64', 'control-64-replay', 'builder-128', 'stateful-64', 'novelty-64', 'coverage_hunter-64']:
        root = args.source_tests / group
        provenance = json.loads(read(root / 'provenance.json'))
        check(group + ':exact_source', provenance['source_commit'] == pins['source_commit'] and provenance['source_tree'] == pins['source_tree'] and provenance['source_dirty'] is False)
        check(group + ':pinned_runtime', all(provenance[key] == expected for key, expected in pins['runtime']['windows'].items()))
        qualification = json.loads(read(root / 'qualification.json'))
        processes = qualification['tests']
        check(group + ':qualified_process', len(processes) == 1 and processes[0]['status'] == 'pass' and processes[0]['exit_code'] == 0 and processes[0]['surviving_owned_pids'] == [] and not processes[0]['interrupted'] and processes[0]['diagnostic_errors'] == [])
        log = root / ('campaign.log' if group not in ['adapter', 'expanded', 'gameplay', 'metamorphic'] else 'goblin_' + group + '.log')
        raw_log = read(log)
        check(group + ':log_custody', hashlib.sha256(raw_log).hexdigest() == processes[0]['log_sha256'] and len(raw_log) == processes[0]['log_bytes'])
        if group in ['adapter', 'expanded', 'gameplay', 'metamorphic']:
            paths = list(root.rglob(group + '-test.json'));assert len(paths) == 1
            path = paths[0];report = json.loads(read(path));rows = report['records']
            check(group + ':native_report', report['failures'] == [])
            if group == 'expanded': expanded = report
        else:
            path = root / 'transcript.json';report = json.loads(read(path));rows = report['steps']
            verified = reader.verify(report)
            check(group + ':frozen_independent_reader', verified['valid'] and not verified['independent_failures'] and not verified['unreported_failures'] and not verified['errors'])
            check(group + ':budget_complete', report['summary']['termination'] == 'budget_complete' and report['header']['provenance'] == provenance)
        check(group + ':current_observations_and_clean_assertions', all(row[side].get('adapter_version') == 3 and row[side]['native']['failed'] is False for row in rows for side in ['before', 'after'])
              and all(item['status'] != 'fail' for row in rows for item in row.get('assertions', []))
              and all(bool(row.get('assertions')) for row in rows if row['status'] == 'completed'))
        statuses = Counter(row['status'] for row in rows)
        completed_ids = set()
        for index, row in enumerate(rows):
            check(group + ':typed_action:' + str(index), reader.action_error(row['action']) is None)
            if row['status'] == 'completed' and row['admission'].get('accepted') is True:
                name = row['action']['id'];completed_ids.add(name)
                specimens.setdefault(name, {'path': str(path), 'sha256': files[str(path)]['sha256'], 'row': index, 'action': row['action']})
        groups[group] = {'attempted': len(rows), 'statuses': dict(statuses), 'completed_ids': sorted(completed_ids), 'rows_without_recorded_assertions': [{'row':i,'status':r['status'],'action':r['action']} for i,r in enumerate(rows) if 'assertions' not in r]}
    check('all55_have_actual_completed_instance', set(specimens) == supported)
    check('all29_added_complete_in_expanded', added <= set(groups['expanded']['completed_ids']))
    check('expanded_actual86_83_3', groups['expanded']['attempted'] == 86 and groups['expanded']['statuses'] == {'completed': 83, 'refused': 3})
    check('expanded_report2030_checks', expanded['checks'] == 2030)
    origin_records = expanded['actor_origin_experiments']
    checks_by_model = Counter()
    for item in origin_records:
        index = item['action_record'];row = expanded['records'][index];action = row['action'];model = item['model']
        if action['id'] not in ['actor_place', 'actor_move', 'actor_reset', 'actor_replace']: continue
        # Place/Move request an explicit authored origin. Reset/Replace use the
        # prior actual authored origin; the extra Monowheel Capture experiment
        # deliberately changes that origin and is not an idempotence promise.
        spawn = [action['args']['x'], action['args']['y']] if action['id'] in ['actor_place', 'actor_move'] else row['before']['actors'][0]['authored_spawn']
        actors = row['after']['actors']
        check('origin:' + str(index) + ':' + model + ':' + action['id'], len(actors) == 1 and actors[0]['model'] == model and row['after']['actor_tick'] == 0
              and row['status'] == 'completed' and row['admission'].get('accepted') is True
              and reader.actor_point_matches(actors[0].get('authored_spawn'), spawn)
              and reader.actor_origin_parts(actors[0], model, spawn))
        checks_by_model[model] += 1
    expected_origin_counts = Counter({name: 4 for name in reader.ACTOR_ROOT_OFFSETS});expected_origin_counts['monowheel'] += 1
    check('all6_model_origin_contracts_plus_retained_capture_observation', checks_by_model == expected_origin_counts)
    trigger = next(row for row in expanded['records'] if row['action']['id'] == 'actor_trigger' and row['status'] == 'completed')
    before = trigger['actor_delivery']['before']['observation']['equipment'];during = trigger['actor_delivery']['during']['observation']['equipment'];receipt = during['last_receipt']
    check('actual_trigger_effect', during['accepted_uses'] > before['accepted_uses'] and receipt['accepted'] is True and receipt['consumed'] is True and receipt['reason'] == 'applied' and receipt['changed_cells'] == 5)
    cancel = next(row for row in expanded['records'] if row['action']['id'] == 'preview_cancel' and row['status'] == 'completed')
    check('actual_preview_cancel_effect', cancel['before']['paint_preview']['dragging'] is True and cancel['after']['paint_preview']['dragging'] is False and cancel['before']['native'] == cancel['after']['native'])
    result = {'schema': 'cybersand-goblin-windows6f-actual-action-review-v1', 'status': 'pass' if all(x['pass'] for x in checks) else 'fail', 'source_commit': pins['source_commit'], 'source_tree': pins['source_tree'],
              'scope': 'Retrospective read-only exact6f focused/native action count and actor-origin review; no gameplay or substituted synthetic tape.',
              'audit_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'groups': groups, 'completed_union': sorted(specimens), 'specimens': specimens,
              'expanded_report_checks': expanded['checks'], 'expanded_stored_assertions': dict(Counter(a['status'] for row in expanded['records'] for a in row['assertions'])),
              'expanded_refusals': [{'action': row['action'], 'reason': row['error']} for row in expanded['records'] if row['status'] == 'refused'],
              'checks': checks, 'check_count': len(checks), 'failures': [x for x in checks if not x['pass']], 'files': files,
              'limits': 'One positive instance per ID does not establish every parameter combination or optional capability. The full5ee comparative metrics remain separate.'}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': result['status'], 'checks': len(checks), 'failures': result['failures'], 'completed_union': len(specimens), 'expanded_stored_assertions': result['expanded_stored_assertions']},sort_keys=True))
    return 0 if result['status'] == 'pass' else 1


if __name__ == '__main__': raise SystemExit(main())
