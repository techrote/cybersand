# Specialist B: actual Windows request11 read-only reviews

This passive bundle contains full actual review outputs, bounded data-only process receipts, exact executed reader versions, source pins and input selections. It has no automatic entrypoint and contains no engine binary. It is a distinct version; the prior preliminary bundle remains unchanged.

Start with bundle-index.json, then lineage-after/request11-windows-B-packet.json. Every indexed file has an exact byte count and SHA-256. The packet includes full-source1,094-check, extracted273-check and current-source731-check results. Their full raw JSON files, not merely Git blob references, are present. The exact actual package selection is retained as ordinary source and evidence files.

The original GitHub artifact ZIPs are preserved separately in the durable experimental evidence. Native source logs/reports/material captures are bound by each review; exact frozen readers can consume those retained inputs again. The package material review supplements C's complete outer-wrapper and final archive custody.

Original failed native qualifications remain failed. Earlier data-only reviewer mistakes are retained with their exact code/process/log and corrections; they are not game findings. Positive instances of55 action IDs do not establish every parameter combination, optional adapter or physical trajectory. The comparative5ee matrix remains its own53-ID dataset.

Linux request11 results are not included in this Windows closure and must be recorded separately when observed. No new gameplay was performed to build this collection.
