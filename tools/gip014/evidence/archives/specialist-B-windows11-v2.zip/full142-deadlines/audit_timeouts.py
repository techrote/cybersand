"""Independently adjudicate the three retained 5ee campaign deadlines; no gameplay."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PIN_SHA = '731d49d467e6f1d7cb2d99f20fce6cc4cb35c6c8372e7ba4929c1ab02ea876f2'
EXPECTED = {
    'long-0112-random-construction-s1701-n512': (466, 464, 614400, 674),
    'long-0114-random-construction-s1701-n1024': (570, 568, 900000, 960),
    'long-0115-coverage_hunter-construction-s1701-n1024': (662, 660, 900000, 960),
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, maximum=32 * 1024 * 1024):
    with path.open('rb') as stream:
        value = stream.read(maximum + 1)
    if len(value) > maximum:
        raise ValueError('bounded evidence input exceeded: ' + str(path))
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaign', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    pins_raw = read(HERE / 'source-pins.json')
    if digest(pins_raw) != PIN_SHA:
        raise ValueError('frozen source pins changed')
    pins = json.loads(pins_raw)
    for name, checksum in pins['files'].items():
        if digest(read(HERE / Path(name).name)) != checksum:
            raise ValueError('frozen source changed: ' + name)
    sys.path.insert(0, str(HERE))
    spec = importlib.util.spec_from_file_location('reader5ee', HERE / 'verify_transcript.py')
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    checks, cases = [], []
    def check(label, condition, actual=None):
        value = {'id': label, 'pass': bool(condition)}
        if actual is not None:
            value['actual'] = actual
        checks.append(value)
    queue_raw = read(args.campaign / 'queue.json')
    queue = json.loads(queue_raw)
    failed = [item for item in queue['episodes'] if item['status'] != 'pass']
    check('exact_three_retained_failed_episodes', {item['episode']['id'] for item in failed} == set(EXPECTED) and len(failed) == 3)
    snapshot_raw = read(args.campaign / 'source-snapshot.json')
    snapshot = json.loads(snapshot_raw)
    check('snapshot_canonical_hash', digest(json.dumps(snapshot['files'], sort_keys=True, separators=(',', ':')).encode()) == snapshot['project_files_sha256'])
    for name, checksum in pins['files'].items():
        if name.startswith('godot/'):
            check('executed_source:' + name, snapshot['files'].get(name.removeprefix('godot/')) == checksum)
    for entry in failed:
        identity = entry['episode']['id']
        prefix = identity + ':'
        folder = args.campaign / identity / 'attempt-01'
        result_raw = read(folder / 'result.json')
        result = json.loads(result_raw)
        check(prefix + 'one_original_attempt', len(entry['attempts']) == 1 and entry['attempts'][0]['number'] == 1)
        check(prefix + 'queue_result_custody', digest(result_raw) == entry['attempts'][0]['result_sha256'])
        check(prefix + 'original_status_preserved', result['status'] == entry['status'] == 'test_failure'
              and result['classification'] == 'unresolved_observation')
        path = (folder / result['transcript']).resolve()
        if not path.is_relative_to(folder.resolve()):
            raise ValueError('transcript escaped its retained attempt')
        tape_raw = read(path)
        tape = json.loads(tape_raw)
        check(prefix + 'transcript_custody', digest(tape_raw) == result['transcript_sha256'])
        check(prefix + 'exact_source_runtime', tape['header']['provenance']['source_commit'] == pins['source_commit']
              and tape['header']['provenance']['source_tree'] == pins['source_tree']
              and tape['header']['provenance']['source_dirty'] is False
              and tape['header']['provenance']['project_files_sha256'] == snapshot['project_files_sha256'])
        process_raw = read(folder / 'process.json')
        process = json.loads(process_raw)
        check(prefix + 'process_receipt_identity', process == result['process'])
        log_raw = read(folder / 'campaign.log', 16 * 1024 * 1024)
        check(prefix + 'raw_log_custody', digest(log_raw) == process['log_sha256'] and len(log_raw) == process['log_bytes'])
        log = log_raw.decode('utf-8', errors='replace')
        check(prefix + 'clean_owned_terminal', process['exit_code'] == 1 and process['status'] == 'test_failure'
              and process['process_exit_status'] == 'test_failure' and process['interrupted'] is False
              and process['surviving_owned_pids'] == [] and process['diagnostic_errors'] == []
              and result['completion_marker'] is True and 'GOBLIN_CAMPAIGN_RESULT ' in log)
        expected_attempted, expected_completed, active_bound, outer_bound = EXPECTED[identity]
        header, controller, summary, rows = tape['header'], tape['controller'], tape['summary'], tape['steps']
        observed_completed = sum(row['status'] == 'completed' and row['admission'].get('accepted') is True for row in rows)
        check(prefix + 'actual_action_counts', len(rows) == summary['attempted_actions'] == expected_attempted
              and observed_completed == summary['completed_actions'] == expected_completed)
        check(prefix + 'registered_bounded_deadline', header['campaign_timeout_msec'] == active_bound
              and active_bound == min(900000, max(150000, header['budget'] * 1200))
              and header['absolute_timeout_msec'] == active_bound + 600000
              and process['timeout_seconds'] == outer_bound == entry['episode']['timeout_seconds']
              and active_bound / 1000 <= controller['elapsed_msec'] / 1000 < process['elapsed_seconds'] < outer_bound)
        check(prefix + 'observed_active_timer_expired', controller['elapsed_msec'] - controller['decision_pause_msec'] - controller['pacing_msec'] > active_bound
              and controller['elapsed_msec'] < header['absolute_timeout_msec']
              and controller['decision_pause_msec'] == 0 and type(controller['pacing_msec']) is int and controller['pacing_msec'] >= 0
              and controller['termination'] == summary['termination'] == 'campaign_timeout'
              and controller['error'] == 'goblin reached its bounded campaign deadline'
              and controller['stop_requested'] is False)
        final = controller['final_observation']
        check(prefix + 'orderly_healthy_stop', final['paused'] is True and final['stopped'] is True
              and final['native']['paused'] is True and final['native']['failed'] is False and final['native']['busy'] is False
              and result['pending_action_retained'] is False and 'pending_action' not in tape)
        check(prefix + 'no_gameplay_assertion_failure', summary['failures'] == [] and summary['assertions']['fail'] == 0
              and all(assertion['status'] != 'fail' for row in rows for assertion in row['assertions']))
        check(prefix + 'no_failed_native_observation', all(row[side]['native']['failed'] is False for row in rows for side in ['before', 'after']))
        refusals = []
        for row in rows:
            if row['status'] == 'completed':
                continue
            check(prefix + 'refusal:' + str(row['index']), row['status'] == 'refused' and row['classification'] == 'not_applicable'
                  and row['action']['id'] == 'fill' and row['admission'].get('accepted') is not True
                  and row['error'] == 'Fill is not wholly contained in the independently captured 4096-cell budget'
                  and row['before']['paused'] is True and row['after']['paused'] is True
                  and row['before']['native'] == row['after']['native']
                  and row['before']['authored_digest'] == row['after']['authored_digest'])
            refusals.append({'index': row['index'], 'action': row['action'], 'classification': row['classification'], 'reason': row['error']})
        check(prefix + 'only_two_expected_fill_refusals', len(refusals) == 2)
        current = reader.verify(tape)
        readback_raw = read(folder / 'independent-readback.json')
        retained = json.loads(readback_raw)
        check(prefix + 'independent_readback_custody', digest(readback_raw) == result['readback_sha256'])
        check(prefix + 'exact_frozen_reader', current == retained and current['valid'] is True
              and current['independent_failures'] == current['unreported_failures'] == [] and current['errors'] == [])
        cases.append({'episode': entry['episode'], 'original_status': result['status'], 'original_classification': result['classification'],
                      'source_commit': pins['source_commit'], 'transcript_sha256': digest(tape_raw), 'transcript_bytes': len(tape_raw),
                      'result_sha256': digest(result_raw), 'process_sha256': digest(process_raw), 'log_sha256': digest(log_raw),
                      'termination': summary['termination'], 'actual_attempted': len(rows), 'actual_completed': observed_completed,
                      'controller_elapsed_msec': controller['elapsed_msec'], 'decision_pause_msec': controller['decision_pause_msec'],
                      'pacing_msec': controller['pacing_msec'], 'active_elapsed_msec': controller['elapsed_msec'] - controller['decision_pause_msec'] - controller['pacing_msec'], 'active_limit_msec': active_bound,
                      'process_elapsed_seconds': process['elapsed_seconds'], 'outer_limit_seconds': outer_bound,
                      'peak_tree_rss_bytes': process['peak_tree_rss_bytes'], 'surviving_owned_pids': process['surviving_owned_pids'],
                      'assertions': summary['assertions'], 'final_native': final['native'], 'refusals': refusals,
                      'review_disposition': 'requested action budget incomplete at the registered active campaign deadline; no observed native/gameplay invariant violation',
                      'production_defect_confirmed': False, 'harness_defect_confirmed': False})
    result = {'schema': 'cybersand-goblin-full142-deadline-adjudication-v1', 'status': 'pass' if all(x['pass'] for x in checks) else 'fail',
              'scope': 'read-only independent adjudication of retained failures, not rerun or requalification',
              'source_pins_sha256': PIN_SHA, 'audit_sha256': digest(Path(__file__).read_bytes()),
              'queue_sha256': digest(queue_raw), 'snapshot_sha256': digest(snapshot_raw),
              'source_contracts': ['5ee:godot/goblin/goblin_controller.gd active/absolute bounds and campaign_timeout branch',
                                   '5ee:tools/gip014/campaign_queue.py finite outer process caps',
                                   '5ee:godot/goblin/goblin_adapter.gd bounded Fill preflight'],
              'source_scope': 'actual executed-input manifest matched to exact published source; no campaign source archive is present in this artifact',
              'check_count': len(checks), 'checks': checks, 'failures': [x for x in checks if not x['pass']], 'episodes': cases}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': result['status'], 'checks': len(checks), 'failures': result['failures'], 'episodes': cases}, sort_keys=True))
    return 0 if result['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
