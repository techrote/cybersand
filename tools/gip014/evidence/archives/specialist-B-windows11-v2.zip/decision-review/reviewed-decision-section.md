## Comparative exploration and longer episodes

The complete second matrix ran at exact source
`5ee5dffc78d59a721f62be49fd51d24b870556c7`, before the later material-history
correction. All **142 independently identified episodes and 11,554 attempted
actions** are retained: **11,538 completed, 16 expected refusals, no partial
effects and no failed gameplay assertions**. Of142 episodes,139 completed their
attempt budgets; three longer episodes reached their configured campaign limits.
The overall Linux qualification remains failed on those incomplete budgets.

| Exact5ee cohort | Episodes | Budget complete | Attempted actions | Completed actions | Refusals |
| --- | ---: | ---: | ---: | ---: | ---: |
| Nine policies × four initial fixtures × three seeds,64slots | 108 | 108 | 6,912 | 6,909 | 3 |
| Random/Coverage Hunter,128/256/512/1024slots | 8 | 5 | 2,978 | 2,967 | 11 |
| Sixteen personalities, mixed_stress, seed605 | 16 | 16 | 1,024 | 1,022 | 2 |
| Ten scenarios, Coverage Hunter, seed2309 | 10 | 10 | 640 | 640 | 0 |

The independent reader recomputed53completed action IDs,975adjacent action
transitions,5,889state-transition keys,96material-interaction keys,69tool/material
keys,127actor/environment keys, eight lifecycle keys, three refusal keys and77
outcome keys. These are deduplicated unions over valid observed tapes, including
incomplete long episodes; no missing suffix is credited. No per-dimension map
saturated. The two absent matrix IDs, `actor_trigger` and `preview_cancel`, both
completed in the separately qualified expanded native group. The trigger has an
accepted/consumed/applied equipment receipt and five actual changed cells;
cancellation ends an observed drag through the ordinary Cancel control. Together
the matrix and focused native evidence contain completed instances of all55
contracts, without adding those focused rows to the matrix totals.

All nine matched policies have12budget-complete episodes at64attempt slots,
using construction, liquid_channel, actor_workshop and history_edges with seeds
13,605and1701. Refusals consume a slot. The following are **per-episode medians**,
not unions or paired effect estimates.

| Policy | Action IDs | Adjacent pairs | State transitions | Material interactions | Tool/material |
| --- | ---: | ---: | ---: | ---: | ---: |
| Control | 23 | 32 | 53 | 5 | 3 |
| Wanderer | 10 | 13 | 59 | 4 | 3 |
| Builder | 7 | 12 | 29 | 6 | 3 |
| Tinkerer | 14 | 16 | 64 | 8 | 4 |
| Curiosity | 35 | 52 | 64 | 9.5 | 4 |
| Seeded random | 25 | 57 | 64 | 11 | 8.5 |
| Stateful explorer | 17 | 25 | 62 | 6 | 5 |
| Novelty seeker | 23.5 | 57 | 64 | 10 | 9 |
| Coverage Hunter | 26 | 58 | 64 | 7 | 9 |

The exact paired median differences use the same12initial-fixture/seed blocks.
They must not be reconstructed by subtracting the separate policy medians.

| Candidate minus baseline | Action IDs | Adjacent pairs | State transitions | Material interactions | Tool/material |
| --- | ---: | ---: | ---: | ---: | ---: |
| Coverage Hunter minus random | +1 | 0 | 0 | −4 | +1 |
| Coverage Hunter minus novelty | +3 | +1 | 0 | −3 | −2 |
| Novelty minus random | −1 | +2 | 0 | +3 | +3 |

Coverage Hunter's material count is lower than Novelty in every block
(differences−7to−1), and never higher than Random(−7to0). It is not a universal
winner. Curiosity's broad action vocabulary and the specialized policies'
repeated interactions answer different testing questions. Material keys describe
sampled adjacency and edit variants, not verified reactions. State-transition
keys include before/after bounded gameplay projections, action ID and status;
they are not a count of physically distinct whole Worlds. Several medians reach
the64-row opportunity ceiling without establishing greater semantic breadth or
defect yield. Ordinary fixture replacement remains part of each whole strategy,
so later environment exposure is not held constant. All142matrix profiles used
fresh memory; these results do not measure cross-episode learning.

### Actual memory reuse and personality behaviour

A separate unchanged5ee experiment completed all seven64-slot episodes:
448admitted/completed actions, no refusals or failed assertions. One Control
construction episode supplied the retained corpus. Two matched seeds,65and129,
then compared fresh Coverage Hunter, imported hints and explicit prefix reuse.
The two hint-only runs changed the first action at equal initial abstract state
and matching paused native identity. Both explicit-reuse runs proposed the exact
retained four-action prefix and independently verified64cells changing from
Empty to the selected material58.

Search benefit was mixed. Hints versus fresh changed action-type coverage by−2
and+3at the two seeds, with material changes0and−2. Explicit prefix versus fresh
changed action types by−2and+2, with material changes−1and0. Imported observations
never counted as fresh coverage. One corpus and two paired seeds establish
working reuse, not a general improvement. Cultivation cost20.315seconds;
all seven game processes177.241seconds; supervisor188.633seconds with
780,333,056bytes peak sampled owned-tree RSS and no survivors.

The separately registered one-episode personality readout found concrete
behaviour differences: Builder completed20rectangles; Tinkerer28history-family
actions; Disaster Artist23rectangles and began four reservoir/breach/repair
intentions; Actor Enthusiast29actor-family and35simulation actions; Impatient
Switcher14UI and17actor-family actions. History Goblin and Obsessive Reproducer
both completed40history-family actions, but their experiment goals referred to
five versus two repeated locations. Those goal counts are not counts of spatial
edits. Alchemist completed no history-family action and skipped eight unavailable
goal steps; successful chemical reactions are not established. These signatures
come from one initial mixed_stress episode per personality at seed605, not a
human recognizability or population-reliability study.

### Long-horizon completion and cost

| Policy | Requested slots | Actual attempts | Completed actions | Terminal outcome | Game-process seconds |
| --- | ---: | ---: | ---: | --- | ---: |
| Random | 128 | 128 | 128 | Budget complete | 76.080 |
| Coverage Hunter | 128 | 128 | 128 | Budget complete | 53.215 |
| Random | 256 | 256 | 254 | Budget complete | 234.825 |
| Coverage Hunter | 256 | 256 | 255 | Budget complete | 171.637 |
| Random | 512 | 466 | 464 | Campaign timeout | 622.944 |
| Coverage Hunter | 512 | 512 | 510 | Budget complete | 573.779 |
| Random | 1024 | 570 | 568 | Campaign timeout | 909.517 |
| Coverage Hunter | 1024 | 662 | 660 | Campaign timeout | 908.820 |

There is one episode per policy/budget, so these are observed outcomes, not
reliability estimates. The three timeout tapes have completion markers, no
pending action, no failed assertion or native failure, and no surviving owned
process. Their active times616.431/901.918/902.175seconds cross configured
614.4/900/900second decision-boundary limits; the outer674/960/960second process
caps are respected. No1024completion is claimed at5ee. The independently frozen
reader passed all142tapes; B's62contract checks distinguish bounded attrition
from gameplay failure while retaining the original runner's failed/unresolved
records.

The142game processes consumed6,693.686aggregate seconds. Queue elapsed time was
6,733.147seconds within7,200; maximum sampled game-process tree RSS was
848,502,784bytes. C verified169process receipts with no survivors and20,696source,
log and archive checks. The later6f qualification has its own separately frozen
eight-long/seven-memory programme; no state-v1/state-v2 coverage is pooled.

The lead's preregistered cost supplement consumed142validated tapes and286exact
input hashes. In the five completed long episodes, later all-action quartile
medians were2.47to7.32times the early medians. Those quarters can contain different
actions and environments. **Zero** exact action/arguments/fixture/pause strata
met the preregistered minimum of three observations in each quarter, so the
adjusted comparison is empty. No threshold was relaxed after seeing results.
The three incomplete episodes are excluded from that positional comparison.
Process time includes game initialization, teardown and monitor overhead, but
excludes the separate editor import and postprocess analysis. Adapter intervals
include admission checkpoint I/O and native waits, and exclude post-return
assertion/coverage/completed-tape work. Neither measure isolates engine FPS,
causal slowdown or a memory leak. C independently recomputed898timing/custody
checks. This is a measured long-horizon cost limitation, not a discovered
production defect.

Primary analysis SHA-256 is
`49de3782a724baba68284cf9f934518efe58b5bc2d1ed45ac15cfd160269d28c`;
memory analysis is`07d5477506d0c28e9738c3ce35843e6e43b34c2124ea9ee25c72f56259ba1904`.
[Original5ee Linux evidence](https://github.com/techrote/cybersand/actions/runs/45550152509/artifacts/15000115723)
retains all raw results. Independent custody, deadline, completed-ID and cost
reviews are recorded in the machine index and durable campaign archive.

### Historical matrix retained at its actual source

The first complete registered Linux matrix ran at exact earlier source
`d849be8ef99cd9226cfc3ca0925752e42b691515`. All **142 independently identified
episodes** were attempted and retained. Their **8,394 attempted actions** comprise
**8,389 completed actions and five refusals**. Independent readers recomputed
all coverage from raw observations. Of the 142 processes, 107 passed and 35
stopped on the same subsequently repaired Monowheel origin oracle. Those stops
remain failures of that historical candidate; they are not 35 production bugs.

| Historical cohort | Episodes | Budget-complete episodes | Attempted actions | Completed actions |
| --- | ---: | ---: | ---: | ---: |
| Matched nine-policy, four-fixture, three-seed comparison at 64 | 108 | 92 | 6,486 | 6,483 |
| Random/Coverage Hunter at 128, 256, 512 and 1024 | 8 | 1 | 733 | 733 |
| Sixteen personalities in mixed_stress | 16 | 14 | 912 | 910 |
| Ten-scenario catalogue | 10 | 0 | 263 | 263 |

The observed union contained **52 action IDs, 655 adjacent action transitions,
4,362 state transitions, 75 material keys, 57 tool/material keys, 86
actor/environment keys, eight lifecycle keys, two refusal keys and 76 outcome
keys**. Missing suffixes receive no coverage credit. The three unobserved matrix
IDs, actor_actuate, actor_trigger and preview_cancel, were exercised separately
by the focused native group; those checks are not silently inserted into matrix
metrics.

Pairwise comparisons use only budget-complete matched episodes at 64 attempted slots; refusals consume slots and remain separately counted. The
historical attrition makes some pairings small or unavailable. Coverage Hunter
versus Random has four eligible blocks and median differences of plus three
action IDs, plus four adjacent transitions and minus four material keys.
Coverage Hunter versus Novelty has five blocks with median differences of zero
action IDs, minus three transitions, minus three material keys and minus two
tool/material keys. Novelty versus Random has no eligible complete pair.
Curiosity's median vocabulary count was 35, compared with 27 for Coverage Hunter
and 26.5 for Novelty; those medians use 11, nine and eight budget-complete
episodes, respectively. Coverage Hunter's pooled vocabulary union was 48 versus
Curiosity's 45 across all twelve valid observed tapes per policy, including
incomplete episodes. The pooled union and completed-episode medians therefore
have different inclusion rules.
Matched fixtures are the initial authored starts; later fixture replacement is
part of the policy behaviour and can change exposure. All 142 historical profiles
started with fresh memory and corpus_reuse=false. These observations establish
useful diversity, not a universally best policy or a causal persistent-learning
advantage.

The original long-horizon stops were assertion stops, not resource-limit
results, and each policy/budget had only one scheduled episode. The separately
reviewed5ee results above retain their own source and different attrition; the
historical failures are not overwritten or pooled with the later matrix.

The original matrix [artifact](https://github.com/techrote/cybersand/actions/runs/45538643315/artifacts/14990308987)
and [fixed-64 analysis](https://api.github.com/repos/techrote/cybersand/git/blobs/b169d11e39d6fdc8102dde243af5281891b594a5)
retain all eligible blocks, missingness and nine coverage dimensions. Sampled
process resource cost, first-50,000-frame quantiles and action interval timing
have different scopes. Per-action timing includes adapter waits and checkpoint
writes; aggregate quantiles do not establish a temporal degradation curve.
