"""Count actual admitted/completed native rows; no gameplay or source mutation."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

SOURCE = '5ee5dffc78d59a721f62be49fd51d24b870556c7'
TREE = '287795a8534c5622ede5d71710714ea467197e79'
HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, maximum=32 * 1024 * 1024):
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    if len(raw) > maximum:
        raise ValueError('bounded evidence file exceeded: ' + str(path))
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    pins_raw = read(HERE / 'source-pins.json')
    pins = json.loads(pins_raw)
    if pins['source_commit'] != SOURCE or pins['source_tree'] != TREE:
        raise ValueError('wrong registered source')
    sources = {}
    for name, checksum in pins['files'].items():
        raw = read(HERE / Path(name).name)
        if sha(raw) != checksum:
            raise ValueError('frozen source changed: ' + name)
        sources[name] = raw.decode()
    original = re.search(r'const ACTION_IDS := \[(.*?)\] \+ Gameplay.IDS', sources['godot/goblin/goblin_adapter.gd'], re.S).group(1)
    expanded = re.search(r'const IDS := \[(.*?)\]', sources['godot/goblin/goblin_gameplay_actions.gd'], re.S).group(1)
    supported = set(re.findall(r'"([a-z_]+)"', original + expanded))
    new_ids = set(re.findall(r'"([a-z_]+)"', expanded))
    checks, evidence, ledger = [], {}, {name: {'matrix': Counter(), 'focused': Counter(), 'completed_specimens': {}} for name in supported}
    def check(label, condition):
        checks.append({'id': label, 'pass': bool(condition)})
    def record(path):
        raw = read(path)
        relative = path.relative_to(args.root).as_posix()
        evidence[relative] = {'bytes': len(raw), 'sha256': sha(raw)}
        return json.loads(raw), relative
    def consume(rows, path, kind):
        counts = Counter()
        for index, row in enumerate(rows):
            name = row['action']['id']
            if name not in supported:
                raise ValueError('unsupported actual row ' + name)
            disposition = row['status']
            admitted_complete = disposition == 'completed' and row['admission'].get('accepted') is True
            healthy_observed = all(isinstance(row.get(side, {}).get('native'), dict)
                                   and row[side]['native'].get('failed') is False
                                   and type(row[side]['native'].get('generation')) in (int, float)
                                   and row[side]['native']['generation'] > 0 for side in ['before', 'after'])
            if admitted_complete and not healthy_observed:
                raise ValueError('claimed completion lacks healthy observed native state')
            if any(item['status'] == 'fail' for item in row.get('assertions', [])):
                raise ValueError('failed assertion in claimed qualified cohort')
            ledger[name][kind]['attempted'] += 1
            ledger[name][kind][disposition] += 1
            counts[disposition] += 1
            if admitted_complete:
                ledger[name][kind]['completed_admitted'] += 1
                ledger[name]['completed_specimens'].setdefault(kind, {'path': path, 'sha256': evidence[path]['sha256'], 'row': index,
                                                                      'action': row['action'], 'status': disposition, 'accepted': True})
        return dict(counts)
    queue, queue_path = record(args.root / 'campaign/queue.json')
    check('registered_55_supported_29_added', len(supported) == 55 and len(new_ids) == 29)
    check('exact_142_episode_catalogue', len(queue['episodes']) == 142)
    matrix_counts = Counter()
    observed_coverage = set()
    for entry in queue['episodes']:
        identity = entry['episode']['id']
        folder = args.root / 'campaign' / identity / 'attempt-01'
        result, result_path = record(folder / 'result.json')
        if len(entry['attempts']) != 1 or evidence[result_path]['sha256'] != entry['attempts'][0]['result_sha256']:
            raise ValueError('original result custody failed')
        tape_path = (folder / result['transcript']).resolve()
        if not tape_path.is_relative_to(folder.resolve()):
            raise ValueError('escaped transcript')
        tape, relative = record(tape_path)
        check(identity + ':exact_tape_source', evidence[relative]['sha256'] == result['transcript_sha256']
              and tape['header']['provenance']['source_commit'] == SOURCE and tape['header']['provenance']['source_tree'] == TREE
              and tape['header']['provenance']['source_dirty'] is False)
        matrix_counts.update(consume(tape['steps'], relative, 'matrix'))
        coverage, cov_path = record(folder / 'coverage.json')
        observed_coverage.update(coverage['keys']['action'])
    reports = {}
    focused_counts = {}
    for group in ['adapter', 'expanded', 'gameplay', 'metamorphic']:
        folder = args.root / 'source-tests' / group
        qualification, _ = record(folder / 'qualification.json')
        provenance, _ = record(folder / 'provenance.json')
        snapshot, _ = record(folder / 'source-snapshot.json')
        check(group + ':exact_source', provenance['source_commit'] == SOURCE and provenance['source_tree'] == TREE
              and provenance['source_dirty'] is False and qualification['provenance'] == provenance)
        check(group + ':source_bytes', all(snapshot['files'].get(name.removeprefix('godot/')) == checksum for name, checksum in pins['files'].items()))
        test = qualification['tests'][0]
        log_path = folder / ('goblin_' + group + '.log')
        log_raw = read(log_path, 16 * 1024 * 1024)
        evidence[log_path.relative_to(args.root).as_posix()] = {'bytes': len(log_raw), 'sha256': sha(log_raw)}
        check(group + ':actual_clean_process', len(qualification['tests']) == 1 and test['status'] == 'pass' and test['exit_code'] == 0
              and test['completion_observed'] is True and test['interrupted'] is False and test['surviving_owned_pids'] == []
              and test['diagnostic_errors'] == [] and sha(log_raw) == test['log_sha256'] and len(log_raw) == test['log_bytes'])
        paths = list(folder.rglob(group + '-test.json'))
        if len(paths) != 1:
            raise ValueError('ambiguous native report')
        report, relative = record(paths[0])
        check(group + ':qualified_report', report['failures'] == [])
        focused_counts[group] = consume(report['records'], relative, 'focused')
        reports[group] = (report, relative)
    matrix_union = {name for name in supported if ledger[name]['matrix']['completed_admitted'] > 0}
    focused_union = {name for name in supported if ledger[name]['focused']['completed_admitted'] > 0}
    check('matrix_raw_rows_match_53_observed_keys', matrix_union == observed_coverage and len(matrix_union) == 53)
    check('matrix_missing_exact_trigger_cancel', supported - matrix_union == {'actor_trigger', 'preview_cancel'})
    check('combined_actual_completion_covers_55', matrix_union | focused_union == supported)
    report, path = reports['expanded']
    added_complete = {row['action']['id'] for row in report['records'] if row['status'] == 'completed' and row['admission'].get('accepted') is True}
    check('all_29_added_ids_complete_in_expanded', new_ids <= added_complete)
    cancel = next(row for row in report['records'] if row['action']['id'] == 'preview_cancel' and row['status'] == 'completed')
    check('cancel_actual_pending_gesture_cleared', cancel['admission']['accepted'] is True
          and cancel['before']['paint_preview']['dragging'] is True and cancel['after']['paint_preview']['dragging'] is False
          and cancel['before']['native'] == cancel['after']['native'])
    trigger = next(row for row in report['records'] if row['action']['id'] == 'actor_trigger' and row['status'] == 'completed')
    delivery = trigger['actor_delivery']
    before = delivery['before']['observation']['equipment']
    during = delivery['during']['observation']['equipment']
    receipt = during['last_receipt']
    check('trigger_actual_controller_and_native_use', trigger['admission']['accepted'] is True
          and delivery['during']['observation']['action']['equipment']['trigger'] is True
          and during['accepted_uses'] > before['accepted_uses']
          and receipt['accepted'] is True and receipt['consumed'] is True and receipt['reason'] == 'applied' and receipt['changed_cells'] == 5
          and receipt['instance_id'] == during['instance_id'] == before['instance_id']
          and receipt['run_id'] == delivery['during']['run_id'] and receipt['epoch'] == delivery['during']['epoch'])
    output = {'schema': 'cybersand-goblin-actual-action-coverage-review-v1', 'status': 'pass' if all(x['pass'] for x in checks) else 'fail',
              'source_commit': SOURCE, 'source_tree': TREE, 'source_pins_sha256': sha(pins_raw), 'audit_sha256': sha(Path(__file__).read_bytes()),
              'scope': 'Read-only counts from actual142 campaign tapes plus four qualified native source gates at exact5ee. Later source qualification is separate.',
              'supported_action_contracts': sorted(supported), 'matrix_completed_action_ids': sorted(matrix_union),
              'matrix_missing_completed_action_ids': sorted(supported - matrix_union), 'focused_completed_action_ids': sorted(focused_union),
              'combined_completed_action_ids': sorted(matrix_union | focused_union), 'only_negative_or_preflight_ids_in_combined_evidence': sorted(supported - matrix_union - focused_union),
              'matrix_row_counts': dict(matrix_counts), 'focused_row_counts': focused_counts,
              'capability_exclusions': 'One completed ID does not establish every material/model/tool parameter, every equipment button, every source-stream state, arbitrary trajectory equivalence, or unavailable optional integrations.',
              'trigger_effect': {'accepted_uses_before': before['accepted_uses'], 'accepted_uses_during': during['accepted_uses'], 'receipt': receipt},
              'ledger': ledger, 'evidence': evidence, 'checks': checks, 'check_count': len(checks), 'failures': [x for x in checks if not x['pass']]}
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in output.items() if k in ['status','check_count','failures','matrix_row_counts','focused_row_counts','matrix_missing_completed_action_ids','only_negative_or_preflight_ids_in_combined_evidence']},sort_keys=True))
    return 0 if output['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
