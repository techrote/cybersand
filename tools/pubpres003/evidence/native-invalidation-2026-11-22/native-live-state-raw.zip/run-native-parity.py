#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, sys
ROOT=Path("/workspace/scratch/d425b9146667/pubpres003-native")
BASE=Path("/workspace/scratch/d425b9146667/pubpres003-evidence/native-column-invalidation")
F=Path("/workspace/scratch/d425b9146667/pubpres003-evidence/native-baseline/runtime-F")
sys.path.insert(0,str(ROOT/"tools/pubpres_playability_build"))
import run_regressions as run
BINARY=BASE/"test_wave_spill_runtime_v2"
SOURCE="1e912084362ea92f03f226e0409573086983d6e2"
if not BINARY.exists():
    command=["/usr/bin/g++","-std=c++20","-O2","-pthread","-I"+str(ROOT/"native/include"),str(ROOT/"native/tests/test_wave_spill.cpp"),"-L"+str(F),"-l:libcybersand_native.linux.x86_64.so","-Wl,-rpath,"+str(F),"-o",str(BINARY)]
    record=run.run(command,dict(os.environ),BASE/"native-parity-compile",120)
    record.update(source=SOURCE,test_source_sha256=run.digest(ROOT/"native/tests/test_wave_spill.cpp"),binary_sha256=run.digest(BINARY) if BINARY.exists() else None,scope="Test harness links the named exact native GDExtension module; no Godot API is called and no native implementation is rebuilt in this executable.")
    (BASE/"native-parity-compile/receipt.json").write_text(json.dumps(record,indent=2)+"\n")
    if record["returncode"]:sys.exit(1)
for label in sys.argv[1:]:
    module=BASE/("runtime-"+label)
    env=dict(os.environ,LD_LIBRARY_PATH=str(module))
    output=BASE/("native-parity-"+label)
    output.mkdir(exist_ok=False)
    manifest=json.loads((module/"PUBPRES-RUNTIME.json").read_text())
    assert run.digest(module/manifest["runtime_file"])==manifest["runtime_sha256"]
    linked=subprocess.check_output(["ldd",str(BINARY)],env=env,text=True)
    (output/"linked-modules.txt").write_text(linked)
    assert str(module/manifest["runtime_file"]) in linked
    result=run.run([str(BINARY),"--filter","wide current gameplay keeps exact parallel state"],env,output/"run",180)
    log=(output/"run/stdout.log").read_text()
    rows=[dict(zip(("workers","tick","physical","water","parcels"),m)) for m in re.findall(r"WAVE_WIDE_CHECKPOINT workers=(\d+) tick=(\d+) physical=([0-9a-f]+) water=(\d+) parcels=(\d+)",log)]
    result.update(source=SOURCE,harness_sha256=run.digest(BINARY),native_source=manifest["source_commit"],native_tree=manifest["source_tree"],native_sha256=manifest["runtime_sha256"],checkpoints=rows,passed=result["returncode"]==0 and len(rows)==24 and "WAVE_SPILL: 1 tests; 0 failures (48 registered)" in log,scope="Correctness only; runs may overlap compilation, never a timing comparison. Full live native physical-state hashes and independently scanned cell/parcel inventory, not prepared-source identity.")
    (output/"receipt.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ("native_source","native_sha256","returncode","passed")}),flush=True)
    if not result["passed"]:sys.exit(1)
