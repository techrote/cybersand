from pathlib import Path
import json,subprocess,hashlib
base=Path('/tmp/ambient-002/evidence/behaviour/closing-normalization'); inv=json.loads((base/'inventory.json').read_text()); repo=base/'isolated-git'; repo.mkdir(exist_ok=False)
records=[]
def git(*args,input=None,check=True):
 p=subprocess.run(['git','-C',str(repo),*args],input=input,capture_output=True,check=False)
 records.append({'args':list(args),'returncode':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
 if check and p.returncode:raise RuntimeError(records[-1])
 return p.stdout.decode().strip()
git('init','-q');git('config','user.name','AMBIENT evidence diagnostic');git('config','user.email','ambient-diagnostic@invalid');git('config','core.autocrlf','false');git('config','commit.gpgsign','false')
files={'.gitattributes':(base/'remote.gitattributes').read_bytes(),'.gitignore':(base/'remote.gitignore').read_bytes()}
files.update({x['path']:Path(x['local']).read_bytes() for x in inv['text_crlf']})
blobs={}
for path,data in files.items():
 sha=git('hash-object','-w','--stdin',input=data);blobs[path]=sha;git('update-index','--add','--cacheinfo','100644',sha,path)
tree=git('write-tree');commit=git('commit-tree',tree,input=b'Isolated raw evidence checkout reproduction\n');git('reset','--hard',commit)
attrs=git('check-attr','text','eol','--',*list(files)[2:]);before=git('status','--porcelain=v1','--untracked-files=all');checks=[]
for path in list(files)[2:]:
 p=repo/path;raw=p.read_bytes();clean=git('hash-object','--path='+path,str(p));checks.append({'path':path,'original_blob':blobs[path],'checkout_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'git_filtered_worktree_blob':clean,'raw_preserved':raw==files[path],'crlf':raw.count(b'\r\n')})
json_paths=[x['path'] for x in inv['text_crlf'] if x['path'].endswith('.json')]
fixed=files['.gitattributes'].rstrip()+b'\n\n# Preserve these original target-host evidence bytes.\n'+''.join(p+' -text whitespace=cr-at-eol\n' for p in json_paths).encode()
(repo/'.gitattributes').write_bytes(fixed);git('add','.gitattributes');fix=git('commit','-m','Isolated exact-path raw-evidence attributes only')
after=git('status','--porcelain=v1','--untracked-files=all');changed=git('diff','HEAD~1','--name-only');raw_unchanged=all(git('rev-parse','HEAD:'+p)==blobs[p] and (repo/p).read_bytes()==files[p] for p in list(files)[2:])
result={'scope':'isolated Git reproduction only; no production mutation','git_version':git('--version'),'source_head':'62a05adf12dfddb744a1e043c2bb4581c7b334e7','attributes_blob':blobs['.gitattributes'],'gitignore_blob':blobs['.gitignore'],'raw_input_count':len(files)-2,'original_status':before,'original_attrs':attrs,'checks':checks,'candidate_exact_path_exceptions':json_paths,'after_exception_status':after,'candidate_changed_paths':changed,'all_original_evidence_bytes_and_blob_ids_unchanged':raw_unchanged}
(base/'reproduction.json').write_text(json.dumps(result,indent=2)+'\n');(base/'commands.json').write_text(json.dumps(records,indent=2)+'\n');(base/'candidate-attributes-only.patch').write_text(git('diff','HEAD~1','HEAD','--','.gitattributes')+'\n')
print(json.dumps(result,indent=2))
assert len(before.splitlines())==5 and all(' M '+p in before for p in json_paths)
assert not after and changed=='.gitattributes' and raw_unchanged
