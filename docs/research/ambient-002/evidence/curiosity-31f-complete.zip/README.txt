AMBIENT-002 supplementary curiosity contrast

Application: a7250e15495667b2fcf564cbed1eaa8dea217c45.
External preregistered diagnostic:31f8ecf8b6d8821740b545e046501f90c86e06f3.
Recovery helper:e003dff2193063e4d42f6bd7a44e91ff5816f8e3.
Independent reader:6eb97a5f70aa8d75b3908ff6b637399a3b0b2f76.

Six completed physical conditions, plus one separately retained incomplete SIGKILL attempt. Original/ contains the unchanged five successful first reports and the failed sixth receipt; retry/ contains only the exact missing case. These are supplementary and not part of the primary194 registry.

The two Git bundles contain exact diagnostic/history heads with known published prerequisite83a3db6ffb207761df999abedac77eb1401604a8. In an existing clone, fetch that prerequisite and verify the bundle before importing its branch to a distinct local ref. Then create separate detached worktrees for the a725 application and31f diagnostic. Native/runtime dependencies retain the hashes in custody.json.

Original registry and physical commands are in execution.json files. The initial driver log retains its failure; recovery-runner.log retains successful completion. Post-run plots and readback do not execute actors. The primary protocol source and all post-run tools are preserved under sources/.
