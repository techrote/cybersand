# Independent AMBIENT-002 physical readback

Source `a7250e15495667b2fcf564cbed1eaa8dea217c45`: 194 actual actor episodes in 122 fresh World clusters; 16 actors are auxiliary companions.

Independently checked 2910 reduced metric values and 67200 copied peer samples against the original raw trajectories.

## Matched seed differences

Values are median paired stateful-minus-comparator differences across the three declared seeds. They are descriptive differences, not significance tests.

| Rig | Comparator | Stable bins | X range | Net movement | Selection-label changes | Active stall fraction |
|---|---|---:|---:|---:|---:|---:|
| 4ly_trainer | coarse_only | +0.000 | -2.297 | -0.799 | +1.000 | +0.000 |
| 4ly_trainer | legacy | +5.000 | +61.437 | +90.031 | +3.000 | -0.122 |
| 4ly_trainer | no_memory | +0.000 | +0.000 | +0.000 | +0.000 | -0.002 |
| 4ly_trainer | no_traits | +0.000 | -1.101 | -1.041 | +0.000 | +0.007 |
| 4ly_trainer | random | +11.000 | +41.999 | +69.684 | +9.000 | -0.061 |
| 4ly_trainer | random_hold | -3.000 | -14.263 | +11.822 | +9.000 | -0.011 |
| 4ly_trainer | scripted | +11.000 | +58.553 | +83.645 | +9.000 | -0.019 |
| monowheel | coarse_only | +0.000 | +4.046 | -18.853 | +5.000 | -0.010 |
| monowheel | legacy | +1.000 | +14.904 | -23.552 | +3.000 | -0.170 |
| monowheel | no_memory | +0.000 | +0.074 | -11.352 | +0.000 | -0.066 |
| monowheel | no_traits | +1.000 | +15.859 | -4.328 | +7.000 | +0.036 |
| monowheel | random | +2.000 | +27.648 | +2.181 | +13.000 | -0.173 |
| monowheel | random_hold | -1.000 | -13.534 | -8.585 | +13.000 | -0.055 |
| monowheel | scripted | -3.000 | -47.274 | -49.870 | +13.000 | -0.033 |
| runner | coarse_only | +0.000 | +1.196 | +9.715 | +8.000 | -0.025 |
| runner | legacy | +1.000 | +12.003 | +13.142 | +4.000 | -0.147 |
| runner | no_memory | +0.000 | +0.313 | -5.149 | +4.000 | -0.010 |
| runner | no_traits | +0.000 | +0.230 | -5.468 | +4.000 | -0.038 |
| runner | random | +1.000 | +2.983 | -1.269 | +15.000 | -0.165 |
| runner | random_hold | -1.000 | -18.025 | -0.976 | +15.000 | -0.091 |
| runner | scripted | -1.000 | -16.126 | -5.817 | +15.000 | -0.020 |

## Descriptive catalogue episodes

One 30-second treatment per editable profile, each with a real passive compatible companion. These are examples under one condition, not a replicated ranking.

| Profile | Rig | Stable bins | X range | Net movement | Selection-label changes | Intentional idle seconds |
|---|---|---:|---:|---:|---:|---:|
| boundary_grazer | 4ly_trainer | 16 | 97.67 | 34.42 | 11 | 0.0 |
| cautious_flyer | 4ly_trainer | 18 | 147.72 | 123.42 | 16 | 3.1 |
| curious_surveyor | runner | 4 | 54.78 | 25.41 | 16 | 6.2 |
| drifting_flyer | 4ly_trainer | 9 | 52.22 | 6.30 | 7 | 1.6 |
| homebody_keeper | runner | 3 | 36.87 | 15.57 | 14 | 8.4 |
| idle_mechanic | runner | 4 | 49.40 | 3.08 | 10 | 12.8 |
| independent_wanderer | runner | 4 | 42.89 | 1.76 | 22 | 0.1 |
| oil_moth | runner | 3 | 35.20 | 5.98 | 11 | 0.0 |
| persistent_scavenger | runner | 3 | 43.73 | 14.49 | 18 | 5.1 |
| restless_explorer | runner | 5 | 65.79 | 19.61 | 16 | 2.9 |
| routine_patrol | runner | 3 | 22.67 | 11.98 | 23 | 1.4 |
| shy_crawler | runner | 3 | 34.52 | 0.08 | 17 | 2.6 |
| social_drifter | runner | 3 | 28.76 | 20.19 | 76 | 7.8 |
| social_roamer | runner | 3 | 26.15 | 12.16 | 128 | 0.1 |
| territorial_watcher | runner | 3 | 36.21 | 9.22 | 10 | 12.2 |
| timid_follower | runner | 2 | 17.89 | 9.61 | 56 | 15.5 |

## Limits and retained negative observations

- Metrics are observations, not automatic scores of intelligence or entertainment.
- Stable bins include the starting bin. Small horizontal oscillation at a grid boundary can populate two bins; pair occupancy with range and net displacement.
- Bin count times bin width/area is nominal occupied-grid measure, not exact traversed extent.
- Paired differences are stateful minus comparator for matching seeds. Three World pairs do not establish general superiority.
- The legacy field intention_transitions counts changes of recorded selection labels. Blend-label changes can reflect contributor changes; separate phase counts are reported. No goal_key was recorded, so new goal-instance counts are unavailable.
- A zero geometric home-return count is not a failed homeward attempt when no home rule was authored or selected, or when no qualifying departure occurred.
- Social/population actors share Worlds. Auxiliary companions are physical actors but not independent personality subjects.
- No-traits jointly disables personality modifiers and accumulated drives; separate contributions are not identified.
- Intentional inactivity and neutral commands permit real momentum and drift.
- Headless trajectories do not qualify graphical presentation or owner NVIDIA playfeel.

Outside-canvas centre observations occurred in 0 actor episodes; exact episode IDs and every-step sample counts are retained in the JSON readback.
