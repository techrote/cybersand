from pathlib import Path
from datetime import datetime, timezone
import contextlib
import dataclasses
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/workspace/scratch/2e90cf7b4aa3/cybersand-product')
SOURCE = sys.argv[1]
OUT = Path(sys.argv[2]).resolve()
ENGINE = Path('/workspace/scratch/2e90cf7b4aa3/deps/godot-4.7/Godot_v4.7-stable_linux.x86_64')
sys.path[:0] = [str(ROOT/'tools'),str(ROOT/'tools/ci')]
import qualify_ambient_living as custody
import run_godot_regressions as regressions

OUT.mkdir(parents=True,exist_ok=False)
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def identity():
    source = custody.source_identity()
    runtime = custody.verify_runtime_identity()
    engine = custody.engine_identity(ENGINE)
    version = subprocess.check_output([str(ENGINE),'--version'],text=True).strip()
    assert version == custody.GODOT_VERSION
    engine['version'] = version
    project = custody.project_identity(ROOT/'godot',source,runtime)
    supplemental = {}
    for name in custody.git('ls-files','-z','--','examples/worldgen','godot/.godot').decode().split('\0'):
        if name:
            actual = (ROOT/name).read_bytes()
            assert actual == custody.git('show','HEAD:'+name), 'Changed supplemental input: '+name
            supplemental[name] = hashlib.sha256(actual).hexdigest()
    return {'source':source,'runtime':runtime,'engine':engine,'loaded_project':project,'supplemental_inputs':supplemental}

plan = [
    ('default_off','test_ambient_default_off_integration',(),None),
    ('living_group_integration','test_ambient_living_group_integration',(),None),
    ('living_group','test_ambient_group_transaction',(),'living_group'),
    ('living_editor','test_ambient_living_editor',(),'living_editor'),
    ('living_engine','test_ambient_living_engine',(),'living_engine'),
    ('living_spatial','test_ambient2_spatial',(),'living_spatial'),
    ('living_examples','test_ambient_living_examples_native',(),'living_examples'),
    ('living_authoring_save','test_ambient_living_authoring',('--save','ambient-mergedown-qualified'),'living_authoring_save'),
    ('living_authoring_reopen','test_ambient_living_authoring',('--reopen','ambient-mergedown-qualified'),'living_authoring_reopen'),
    ('legacy_session','test_workbench_actor_composition_session',(),'legacy_session'),
    ('legacy_physical','test_physical_actor_session',(),'legacy_physical'),
]
before = identity()
assert before['source']['source_commit'] == SOURCE
write('before-identity.json',before)
cases = {c.name:c for c in regressions.discover_cases()}
write('campaign-plan.json',{'source':SOURCE,'created_utc':datetime.now(timezone.utc).isoformat(),
      'purpose':'Actual AMBIENT002/foundation resulting-source mixed-control isolation, atomic group application, ordinary native examples, authored persistence and existing actor ownership; no physical/graphical/Windows owner acceptance',
      'cases':plan,'existing_watchdogs_unchanged':True,'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
results=[]
for alias,name,args,terminal in plan:
    output=OUT/alias;output.mkdir()
    case=cases[name]
    if args:case=dataclasses.replace(case,flags=(*case.flags,'--',*args))
    profile=OUT/('authored-profile' if alias.startswith('living_authoring_') else alias+'-profile')
    env=dict(os.environ,XDG_DATA_HOME=str(profile),XDG_CONFIG_HOME=str(profile/'config'),GODOT_SILENCE_ROOT_WARNING='1',CYBERSAND_SOURCE_REVISION=SOURCE)
    if alias in custody.REPORTS:env[custody.REPORTS[alias]]=str(output/'fixture-report.json')
    with (output/'runner.txt').open('w') as stream,contextlib.redirect_stdout(stream):
        result,failed=regressions.run_case(str(ENGINE),case,output,'primary',env=env)
    result['qualification_name']=alias
    if not failed:
        try:
            if terminal:
                result['completion']=custody.completion(terminal,output/result['log'])
            else:
                marker='AMBIENT_DEFAULT_OFF ' if alias=='default_off' else 'AMBIENT_LIVING_GROUP_INTEGRATION '
                lines=[s[len(marker):] for s in (output/result['log']).read_text().splitlines() if s.startswith(marker)]
                assert len(lines)==1
                result['completion']=json.loads(lines[0])
                assert result['completion']['checks']>0 and result['completion']['failures'] in (0,[])
        except Exception as error:
            result['completion_error']=f'{type(error).__name__}: {error}'
            result['status']='failed';failed=True
    result['fail_boolean']=failed
    results.append(result);write('results.json',results)
    print(json.dumps({'case':alias,'status':result['status'],'seconds':result['seconds'],
          'checks':result.get('completion',{}).get('checks'),'completion_error':result.get('completion_error')}),flush=True)
after=identity();write('after-identity.json',after)
unchanged=before==after
write('summary.json',{'source':SOURCE,'tree':before['source']['source_tree'],
      'cases':len(results),'passed':sum(not x['fail_boolean'] for x in results),
      'checks':sum(x.get('completion',{}).get('checks',0) for x in results),
      'seconds':round(sum(x['seconds'] for x in results),3),
      'source_runtime_project_engine_unchanged':unchanged,
      'status':'PASS' if unchanged and not any(x['fail_boolean'] for x in results) else 'FAIL',
      'completed_utc':datetime.now(timezone.utc).isoformat(),
      'scope':'Actual Linux Godot4.7 native/Rapier; eight-actor admission unchanged; no Actor Capacity or physical owner acceptance'})
assert unchanged,'Source/runtime/project/engine moved during qualification'
sys.exit(1 if any(x['fail_boolean'] for x in results) else 0)
