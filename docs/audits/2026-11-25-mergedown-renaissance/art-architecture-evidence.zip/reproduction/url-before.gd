extends SceneTree
const P = preload("res://scripts/art_provider.gd")
func _initialize() -> void: run.call_deferred()
func run() -> void:
 var p := P.new(); root.add_child(p)
 for endpoint: String in ["http://localhost:abc", "http://:80", "http://[", "http://[::1]:abc", "http://127.0.0.1:65536", "http://127.0.0.1:0"]:
  var accepted := P._has_http_endpoint(P.request_url("LM Studio",endpoint))
  var outcome := p.send("LM Studio",endpoint,"invalid-url-fixture","","Test invalid endpoint","No native authority",16,1)
  print("URL_ADMISSION ",JSON.stringify({"endpoint":endpoint,"guard":accepted,"error":outcome,"active":p.active}))
  p.cancel("Probe cleanup")
  await process_frame
 p.queue_free(); await process_frame
 quit()
