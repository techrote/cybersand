#!/usr/bin/env python3
"""Independent synthetic late-finalization and receipt-protocol probes.

This reuses the producer fixture only to supply synthetic Git/LFS object bytes;
it does not contact GitHub, install native runtimes, or qualify an application.
"""
from pathlib import Path
import hashlib
import json
import sys
from unittest import mock

source = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
assert not output.exists(), "Preserve earlier original probe receipts"
helper = source / "tools/ci/lfs_runtime_artifact.py"
fixture_file = source / "tools/ci/test_lfs_runtime_artifact.py"
before = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in (helper, fixture_file)}
sys.path.insert(0, str(source / "tools/ci"))
import lfs_runtime_artifact as transport
from test_lfs_runtime_artifact import RuntimeArtifact

rows = []
fixture = RuntimeArtifact()
fixture.setUp()
try:
    fixture.staged()
    path = fixture.artifact / "acquisition/receipt.json"
    receipt = json.loads(path.read_text())
    receipt["schema"] = "unrecognized-acquisition-v99"
    path.write_text(json.dumps(receipt))
    fixture.reseal()
    try:
        result = fixture.installed()
        rows.append({"control": "wrong-acquisition-receipt-schema", "accepted": True,
                     "status": result["status"]})
    except Exception as error:
        rows.append({"control": "wrong-acquisition-receipt-schema", "accepted": False,
                     "error": str(error)})
finally:
    fixture.tearDown()

fixture = RuntimeArtifact()
fixture.setUp()
try:
    clock = [100.0]
    original_write = transport.write

    def delayed_manifest(path, value):
        original_write(path, value)
        if path.name == transport.MANIFEST:
            clock[0] += 601.0

    with mock.patch.object(transport.time, "monotonic", side_effect=lambda: clock[0]), \
            mock.patch.object(transport.materialize_lfs, "materialize", side_effect=fixture.acquire), \
            mock.patch.object(transport, "write", side_effect=delayed_manifest):
        try:
            result = transport.stage(fixture.repo, fixture.available, fixture.source,
                                     fixture.run_id, fixture.attempt, fixture.artifact, 600)
            row = {"control": "producer-final-seal-deadline-overrun", "accepted": True,
                   "status": result["status"]}
        except Exception as error:
            row = {"control": "producer-final-seal-deadline-overrun", "accepted": False,
                   "error": str(error)}
        row.update(elapsed_seconds=clock[0] - 100,
                   usable_manifest=(fixture.artifact / transport.MANIFEST).exists(),
                   failed_manifest_retained=(fixture.artifact / "failed-manifest.json").exists())
        rows.append(row)
finally:
    fixture.tearDown()

fixture = RuntimeArtifact()
fixture.setUp()
try:
    fixture.staged()
    clock = [100.0]
    original_write = transport.write
    once = [False]

    def delayed_receipt(path, value):
        original_write(path, value)
        if path.name.startswith("install-") and not once[0]:
            once[0] = True
            clock[0] += 301.0

    with mock.patch.object(transport.time, "monotonic", side_effect=lambda: clock[0]), \
            mock.patch.object(transport, "write", side_effect=delayed_receipt):
        try:
            result = fixture.installed()
            row = {"control": "consumer-final-receipt-deadline-overrun", "accepted": True,
                   "status": result["status"]}
        except Exception as error:
            row = {"control": "consumer-final-receipt-deadline-overrun", "accepted": False,
                   "error": str(error)}
        receipt = json.loads((fixture.root / "install-1.json").read_text())
        row.update(elapsed_seconds=clock[0] - 100, canonical_receipt_status=receipt["status"],
                   failed_original_retained=(fixture.root / "install-1.json.failed-seal.json").exists())
        rows.append(row)
finally:
    fixture.tearDown()

after = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in (helper, fixture_file)}
report = {"scope": "Independent synthetic receipt/deadline controls; no native runtime proof",
          "inputs_before": before, "inputs_after": after, "inputs_unchanged": before == after,
          "rows": rows}
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
