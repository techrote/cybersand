from pathlib import Path
import contextlib
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
import types
from datetime import datetime, timezone

BASE = Path('/workspace/scratch/2e90cf7b4aa3')
CANDIDATE = BASE / 'art-storage-integration'
ENGINE = BASE / 'deps/godot-4.7/Godot_v4.7-stable_linux.x86_64'
MODE = sys.argv[1]
assert MODE in ('baseline', 'repaired')
ROOT = BASE / 'cybersand-ambient' if MODE == 'baseline' else CANDIDATE
EXPECTED = '97585a0af02f1534eb254adf2d2fbe9036a281b2' if MODE == 'baseline' else '368292fe99485e6ea928325f9e8d000d829a4407'
OUT = BASE / 'art-storage-qualification' / MODE
OUT.mkdir(exist_ok=False)
sys.path[:0] = [str(CANDIDATE / 'tools'), str(CANDIDATE / 'tools/ci')]
import qualify_workbench_landscapes as custody
import run_art_storage_qualification as storage
import run_godot_regressions as regressions

custody.ROOT = ROOT


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def identity():
    source = custody.source_identity()
    assert source['source_commit'] == EXPECTED
    runtime = custody.verify_runtime_identity()
    project = custody.project_identity(ROOT / 'godot', source, runtime)
    supplemental = {}
    for path in custody.git('ls-files', '-z', '--', 'examples/worldgen', 'godot/.godot').decode().split('\0'):
        if not path:
            continue
        actual = (ROOT / path).read_bytes()
        assert actual == custody.git('show', 'HEAD:' + path), path
        supplemental[path] = hashlib.sha256(actual).hexdigest()
    version = subprocess.check_output([str(ENGINE), '--version'], text=True).strip()
    assert version == '4.7.stable.official.5b4e0cb0f'
    engine_sha = custody.sha(ENGINE)
    assert engine_sha == 'f85bbc6b15e22416c7d797cd60b63286dd67b9cb13498847056c18520ae55a75'
    overlay = {}
    for path in ('godot/tests/art_storage_fault_child.gd', 'tools/ci/run_art_storage_qualification.py',
                 'tools/ci/windows_file_lock.py'):
        overlay[path] = custody.sha(CANDIDATE / path)
    return {'source': source, 'runtime': runtime, 'loaded_project': project,
            'supplemental_inputs': supplemental, 'external_fixture_inputs': overlay,
            'engine': {'version': version, 'sha256': engine_sha, 'bytes': ENGINE.stat().st_size}}


before = identity()
write('before-identity.json', before)
matrix = [(operation, fault) for operation in ('export', 'new-event', 'append')
          for fault in ('none', 'short-write')]
matrix += [('settings', fault) for fault in ('none', 'short-write', 'directory-permission-denied')]
matrix += [('pending-history', fault) for fault in ('none', 'existing-receipt', 'short-write', 'directory-permission-denied')]
assert len(matrix) == 13
write('campaign-plan.json', {
    'mode': MODE, 'application_source': EXPECTED,
    'fixture_source': '368292fe99485e6ea928325f9e8d000d829a4407',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'matrix': matrix, 'fixture_driver_seconds': 40, 'fixture_child_gate_seconds': 15,
    'scope': 'Linux real OS faults with private profiles; no Windows or physical acceptance',
    'script_sha256': custody.sha(Path(__file__)),
    'baseline_authority': 'Expected failures remain failed, including original diagnostics. The absolute child fixture is an explicit overlay, not a modified base application.'
})

# The external SceneTree fixture resolves res:// against the selected unchanged
# application. This does not install or replace any file in that project.
if MODE == 'baseline':
    original_popen = subprocess.Popen

    def launch(command, *args, **kwargs):
        assert command[-1] == 'res://tests/art_storage_fault_child.gd'
        command[-1] = str(CANDIDATE / 'godot/tests/art_storage_fault_child.gd')
        return original_popen(command, *args, **kwargs)

    storage.subprocess = types.SimpleNamespace(Popen=launch, PIPE=subprocess.PIPE, STDOUT=subprocess.STDOUT)

rows = []
for operation, fault in matrix:
    started = time.monotonic()
    row = storage.run_case(ENGINE, ROOT / 'godot', OUT / (operation + '-' + fault), operation, fault)
    row['seconds'] = round(time.monotonic() - started, 3)
    rows.append(row)
    write('results.json', rows)
    print(json.dumps({'mode': MODE, 'operation': operation, 'fault': fault,
                      'passed': row['passed'], 'engine_error': row['engine_error_detected'],
                      'seconds': row['seconds']}), flush=True)

after = identity()
write('after-identity.json', after)
assert before == after, 'Source/runtime/project or external fixture moved during execution'
write('summary.json', {
    'source': EXPECTED, 'tree': before['source']['source_tree'],
    'mode': MODE, 'source_runtime_project_engine_unchanged': True,
    'cases': len(rows), 'passed': sum(row['passed'] for row in rows),
    'failed': sum(not row['passed'] for row in rows),
    'seconds': round(sum(row['seconds'] for row in rows), 3),
    'status': 'PASS' if all(row['passed'] for row in rows) else 'FAIL',
    'meaning': 'Qualification of repaired source' if MODE == 'repaired' else 'Explicit original application failure reproduction; FAIL is preserved failure evidence',
    'completed_utc': datetime.now(timezone.utc).isoformat()
})
sys.exit(0 if MODE == 'baseline' or all(row['passed'] for row in rows) else 1)
