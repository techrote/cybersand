# Retrieval contexts for independent answer review

Source-backed expected facts and the complete top-five contexts follow. A canonical route hit alone is not an answer pass.

## ART-STORAGE-001: When does Art export verify its closed output, and can I still cancel before replacing the destination?

Canonical rank: 1

Expected facts:

- The unmerged candidate verifies closed staging length and SHA-256 cooperatively before native atomic replacement.
- Stop and Cancel remain effective during verification; refusal does not publish that export and source aliases are checked again at commit.
- This is not a power-loss or fsync guarantee.

### Rank 1: systems/workbench-art-providers.md — Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate

Document: Art workbench provider connection, WB-ART-002 Stage 2
Path: systems/workbench-art-providers.md
authority: current-documentation
document-kind: contract
status: Current
scope: Art providers, same-session collaboration, failure lifecycle, consolidated Draft UI and qualification
canonical-for: [workbench-art-providers]
last-reviewed: 2026-11-26
Section: Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate
The unmerged Art/Architecture integration verifies closed output before acknowledging a stored event, completed export, preference update or retained private history receipt. `art_provider.gd::_store_event` verifies the exact new record region against the submitted buffers, without rereading the previous archive. An interrupted append leaves prior complete records readable and makes that session writer read-only; it does not claim to roll back an incomplete tail or repeat an already completed native edit. Export closes its staging file and cooperatively verifies its exact length and SHA-256 before the existing native atomic replacement. Traffic displays the verification phase; Stop and Cancel still interrupt it. Refusal or cancellation does not publish that export. The destination/source alias guard is checked again at commit. This remains a bounded streaming export, independent of model context and native painting authority. `art_batch_panel.gd::_save_settings` uses the shared bounded-text `workbench_file_transaction.gd` helper: complete closed-byte verification followed by the accepted native sibling-file replacement. Existing unchanged preferences keep their no-write cache. A failed write retains the earlier cache and file; only verified success updates the cache. Successful retry or reversion to the committed settings clears only the save-owned error. The profile's 1 MiB bound and prior-profile admission refusal remain authoritative. The retained private `_persist_history_receipt` method similarly verifies the closed payload before publication and before advancing receipt identity/order. Its existing schema, frozen projection, epoch and capacity checks remain. This does not activate old-journal restoration in ordinary Art sessions. Neither helper promises `fsync`, power-loss recovery, a multi-file transaction, or a cross-process editing lock; complete concurrent replacements remain last-writer-wins. The direct `test_workbench_file_transaction.gd` and `test_art_storage_integrity.gd` regressions exercise verification and refusal. `tools/ci/run_art_storage_qualification.py` runs disposable actual OS faults and retry, with a shared Windows sharing-lock fixture in `windows_file_lock.py`. The [registered mergedown campaign](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md) separates inherited failure evidence, resulting-source execution and pending Windows/owner acceptance. These source changes do not establish physical acceptance or change native runtime inputs.


### Rank 2: tools/world-art-preview.md — World Art interactive viewer > Output and limits

Document: World Art interactive viewer
Path: tools/world-art-preview.md
authority: current-documentation
document-kind: guide
status: Current
scope: Standalone Godot World Art inspection, navigation, comparison and export controls
canonical-for: [world-art-interactive-viewer]
last-reviewed: 2026-11-20
Section: World Art interactive viewer > Output and limits
Each export creates a unique directory under `user://world-art-preview/captures/` containing its PNG, `metadata.json` and `status.json`. Use `--export-root=/absolute/output` to choose a destination. The isolated project is named **CyberSand World Art Preview**; on Windows its default data directory is below `%APPDATA%\Godot\app_userdata\CyberSand World Art Preview\`. Existing images are never overwritten. Source directories and uncertain symlink/junction aliases are refused as output locations. Partial output remains incomplete on failure. Metadata records the actual source, dimensions, camera, settings, source RG8 hash, renderer identity and PNG hash. Art sources support up to **16,384 cells per axis / 16,777,216 cells total**. Interactive full-image exports stop at **50,000,000 output pixels**. The pixel cost is shown before export. For larger exports, use the same renderer through [unattended capture with `--stream-large`](world-art-capture.md#optional-bounded-streamed-full-png-above-50-million-pixels), with a **100,000,000-pixel / 65,536-per-output-axis** limit. There is no automatic crop, distortion or source resizing to evade these limits. The art adapter's dimensions do not change native World, gameplay, production import or saved-world limits. Transparent/empty material cells reveal the presentation background; PNG exports are the composited opaque framebuffer, not an RGBA cutout of a native world.


### Rank 3: tools/world-art-capture.md — World Art unattended capture — real Godot PNGs and manifests > Optional bounded streamed full PNG above 50 million pixels

Document: World Art unattended capture
Path: tools/world-art-capture.md
authority: current-documentation
document-kind: guide
status: Current
scope: Production Godot framebuffer capture, streamed PNG transport, provenance and publication safety
canonical-for: [world-art-unattended-capture]
last-reviewed: 2026-11-20
Section: World Art unattended capture — real Godot PNGs and manifests > Optional bounded streamed full PNG above 50 million pixels
The standard Godot `Image` full export is limited to 50,000,000 output pixels. **Explicitly** add `--stream-large` to `--capture` to allow an authored composition to export at up to **100,000,000 output pixels and 65,536 pixels per output axis** without allocating a world-sized output `Image`. The source art adapter still requires at most 16,777,216 native material cells and 16,384 cells per input side. For example, an authored 1024×4096 map at 4× requests a real 4096×16384 (67,108,864-pixel) PNG: ~~~bash python3 tools/world_art_preview_launcher.py --capture --godot=godot \ --pack=/absolute/your/pack.json --shots=full --scale=4 --stream-large \ --output-dir=/absolute/captures/streamed-001 ~~~ Godot renders the original RG8 production shaders into 512-native-cell tiles with a 32-cell halo, writes each exact cropped RGB8 framebuffer tile with SHA-256, then the trusted Python transport verifies and assembles those pixels by scanline with `zlib` into a final RGB PNG. The manifest is marked complete **only after** tile coverage, byte counts and SHA-256, PNG CRC/deflate, pixel length, output dimensions, source identity and source-immutability checks pass. Intermediate RGB files are deleted on success; failed evidence is retained with a failure status. This is streamed PNG *transport*, not a second material renderer. The CLI `--verify-bundle` also validates PNGs in bounded memory. Ordinary capture, viewer screenshots and all `--shots=viewport,detail` remain unchanged. The interactive **Save full** button retains its stricter 50M bound; use this CLI when a truly larger whole-map PNG is required. **No native playable World size, physics or save/load compatibility is inferred from art preview dimensions.**


### Rank 4: tools/world-art-capture.md — World Art unattended capture — real Godot PNGs and manifests > Output bundle > Re-verify and compare

Document: World Art unattended capture
Path: tools/world-art-capture.md
authority: current-documentation
document-kind: guide
status: Current
scope: Production Godot framebuffer capture, streamed PNG transport, provenance and publication safety
canonical-for: [world-art-unattended-capture]
last-reviewed: 2026-11-20
Section: World Art unattended capture — real Godot PNGs and manifests > Output bundle > Re-verify and compare
~~~bash python3 tools/world_art_preview_launcher.py --verify-bundle /abs/captures/lumen-fault-before python3 tools/world_art_preview_launcher.py --compare-bundles /abs/captures/before /abs/captures/after ~~~ `--verify-bundle` binds the batch image list exactly to verified child manifests, rejects escaping/linked paths and malformed structures, validates PNG headers, filters and chunk order, and re-hashes every PNG and manifest and re-hashes the packs if they still exist (reporting source edits made after capture). `--compare-bundles` reports per collection/shot whether the framing was equivalent and whether the pack, the RG8 cells and the PNG changed. **Before/after recipe:** capture the unedited pack, edit a writable copy, capture again with the *identical* flags, then compare. Fit framing depends on the map size, so for pixel-aligned comparisons of resized maps pass an explicit `--view` or `--zoom/--center` and `--resolution`.


### Rank 5: operations/art-workbench-final-evaluation.md — Art Workbench final evaluation > Short owner checklist

Document: Art Workbench final evaluation
Path: operations/art-workbench-final-evaluation.md
authority: current-documentation
document-kind: guide
status: Current
scope: Draft/HOLD Art integration, Windows evaluator, no-server responsiveness checks and evidence boundaries
canonical-for: [art-workbench-final-evaluation]
last-reviewed: 2026-11-24
Section: Art Workbench final evaluation > Short owner checklist
1. Completely stop LM Studio. Confirm there is no listener on the configured local API endpoint, normally `127.0.0.1:1234`. Select **LM Studio → Model prompt** and leave **Image** off. Press **Send**, then immediately click Art's ordinary **X**. Repeat three times, reopening through **Art batches** between attempts. Check mouse, camera and painting responsiveness; record any pause and whether it begins on Send, X or recovery. Repeat separately with the Image setting used during the original freeze. 2. Compare the same absent-server request with Art left visible, and with **Stop** followed by X. Try reopening while a request is pending. X hides Art; Stop explicitly cancels activity. A failed connection leaves Send usable. 3. Open **Conversation… → + Note**. Use long text at a 1280×720 and 1920×1080 window, and at your normal Windows display scale. Scroll the contents, click Apply, reopen and verify the edit. Cancel a second edit and verify that it was not applied. Apply/Cancel should remain reachable at a small Art window size; a short Note should gain editing height when the Conversation window is taller. Messages over 4,096 characters use **Previous/Next** parts; Apply retains the complete message, including edits made in other parts. Use the part-number field and Enter to jump directly without applying. Moving between parts or pasting across parts resets local text Undo; Cancel still discards the whole draft. Ordinary small-note Undo remains available. 4. Inspect both provider preset lists, enter a custom model and endpoint, switch provider and return. Check that saved custom choices remain. **Key… / Key ✓** belongs to the provider named when its dialog opened and is held only in process memory. A dummy key suffices to check the dialog without inference. 5. Draw manually and with **Direct JSON → Draw**; Stop a large batch after a visible prefix. Wait for its confirmed result, pause through **Play / Pause [P]**, then Undo/Redo. **Save start [Ctrl+S] / Load start** should retain the authored start so painting can continue. A new Workbench game session starts with an empty conversation and a new audit; hiding Art within one game session preserves that session's conversation. Save a Ctrl+F12 checkpoint after a freeze, then exit normally. Report the source commit, Windows display scale, endpoint category (default numeric loopback, localhost or a custom local address), listener absence and which comparison reproduced the delay. Timing evidence does not require sharing a private profile.

## ART-STORAGE-002: Do verified Art preference saves rewrite unchanged settings or lose the previous cache after a failed write?

Canonical rank: 1

Expected facts:

- The existing unchanged-settings cache avoids rewriting the committed configuration.
- A failed write preserves the previous file and cache; only verified success updates the cache.
- Successful retry or reversion clears only the save-owned error, with the profile size and admission guards preserved.

### Rank 1: systems/workbench-art-providers.md — Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate

Document: Art workbench provider connection, WB-ART-002 Stage 2
Path: systems/workbench-art-providers.md
authority: current-documentation
document-kind: contract
status: Current
scope: Art providers, same-session collaboration, failure lifecycle, consolidated Draft UI and qualification
canonical-for: [workbench-art-providers]
last-reviewed: 2026-11-26
Section: Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate
The unmerged Art/Architecture integration verifies closed output before acknowledging a stored event, completed export, preference update or retained private history receipt. `art_provider.gd::_store_event` verifies the exact new record region against the submitted buffers, without rereading the previous archive. An interrupted append leaves prior complete records readable and makes that session writer read-only; it does not claim to roll back an incomplete tail or repeat an already completed native edit. Export closes its staging file and cooperatively verifies its exact length and SHA-256 before the existing native atomic replacement. Traffic displays the verification phase; Stop and Cancel still interrupt it. Refusal or cancellation does not publish that export. The destination/source alias guard is checked again at commit. This remains a bounded streaming export, independent of model context and native painting authority. `art_batch_panel.gd::_save_settings` uses the shared bounded-text `workbench_file_transaction.gd` helper: complete closed-byte verification followed by the accepted native sibling-file replacement. Existing unchanged preferences keep their no-write cache. A failed write retains the earlier cache and file; only verified success updates the cache. Successful retry or reversion to the committed settings clears only the save-owned error. The profile's 1 MiB bound and prior-profile admission refusal remain authoritative. The retained private `_persist_history_receipt` method similarly verifies the closed payload before publication and before advancing receipt identity/order. Its existing schema, frozen projection, epoch and capacity checks remain. This does not activate old-journal restoration in ordinary Art sessions. Neither helper promises `fsync`, power-loss recovery, a multi-file transaction, or a cross-process editing lock; complete concurrent replacements remain last-writer-wins. The direct `test_workbench_file_transaction.gd` and `test_art_storage_integrity.gd` regressions exercise verification and refusal. `tools/ci/run_art_storage_qualification.py` runs disposable actual OS faults and retry, with a shared Windows sharing-lock fixture in `windows_file_lock.py`. The [registered mergedown campaign](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md) separates inherited failure evidence, resulting-source execution and pending Windows/owner acceptance. These source changes do not establish physical acceptance or change native runtime inputs.


### Rank 2: operations/cybersand-codex-development-handover.md — Development handover > Art storage mergedown — 2026-11-26

Document: Development handover
Path: operations/cybersand-codex-development-handover.md
authority: current-documentation
document-kind: guide
status: Current
scope: Short onboarding sequence and checkpoint protocol; product intent, source identity and contracts have canonical homes
canonical-for: [development-onboarding]
last-reviewed: 2026-11-20
Section: Development handover > Art storage mergedown — 2026-11-26
The [registered storage integration](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md) adapts only the reviewed ULTIMA Art export/event, preference and private-receipt repairs to the combined Art/Architecture candidate. Preserve the current settings no-op cache, lazy UI, asynchronous value preparation and owned Architecture dispatch. The protected ULTIMA programme and its separate CI acquisition helper are not imported. The [canonical storage boundary](../systems/workbench-art-providers.md#verified-closed-storage-in-the-mergedown-candidate) distinguishes closed-byte verification from power-loss or physical acceptance.


### Rank 3: tools/world-art-evaluation.md — World Art Windows evaluation > Inspecting the artwork

Document: World Art Windows evaluation
Path: tools/world-art-evaluation.md
authority: current-documentation
document-kind: guide
status: Current
scope: Portable owner evaluation of the standalone World Art viewer, capture tools and verified gallery
canonical-for: [world-art-windows-evaluation]
last-reviewed: 2026-11-21
Section: World Art Windows evaluation > Inspecting the artwork
Choose a collection in the left sidebar. The scene selector offers its combined composition and reusable features, with authored variants where present. | Task | Control | | --- | --- | | Fit every authored cell | **F** or Fit | | Fit width or height | **W** / **H** | | One screen pixel per source cell | **1** | | Zoom around the pointer | Mouse wheel over the image | | Pan | Middle/right drag or arrow keys | | Jump to a region | Click/drag the aspect-correct minimap | | Reload an edited working copy | **R** or Reload | | Pin the current framebuffer | **P** or Pin | | Compare the pin with the current view | **B** or Show before / Show after | | Save the visible viewport | **Ctrl+S** | For before/after work, make a separate writable copy of `pack.json`. Pin the original view, edit that copy, reload and toggle the comparison. Failed parsing retains the last good view. The original source packs in the package are the qualification reference; keep those unchanged when evaluating source identity. To inspect additional artwork, use **Choose directory** or the world-design root field. A directory contains one subdirectory per collection, each with `pack.json`. These are provisional World Art JSON packs, not native CyberSand save files. The package does not convert arbitrary images, native saves or other import formats into art packs. For a single external pack, open PowerShell in the extracted package folder: ```powershell .\dependencies\python\python.exe -B .\tools\world_art_preview_launcher.py ` --godot .\Godot_v4.7-stable_win64_console.exe --rendering-driver opengl3_angle ` --pack "C:\MyArt\working-copy\pack.json" ```


### Rank 4: reference/status-and-roadmap.md — Status and foundational roadmap > Art storage integration candidate — 2026-11-26

Document: Status and foundational roadmap
Path: reference/status-and-roadmap.md
authority: current-documentation
document-kind: reference
status: Current
scope: Current implementation map, unresolved correctness and policy decisions, and bounded next checkpoints
canonical-for: [implementation-status, foundational-priorities, open-decisions]
last-reviewed: 2026-11-21
Section: Status and foundational roadmap > Art storage integration candidate — 2026-11-26
The mergedown's unmerged Art/Architecture source adopts the narrowly reviewed closed-file verification repair for exports, new/appended events, preferences and retained private receipts. The [provider contract](../systems/workbench-art-providers.md#verified-closed-storage-in-the-mergedown-candidate) preserves settings-cache isolation, session-only conversation behavior and native Architecture authority. Its [registered campaign](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md) records exact donor boundaries and the required resulting-source fault and authoring tests. ULTIMA remains protected; its unrelated CI and other consumer changes are excluded. Windows storage, creative and physical acceptance remain separate gates.


### Rank 5: systems/art-native-context-proposals.md — Art native context and typed proposals > Compilation, revision and zero-write preview

Document: Art native context and typed proposals
Path: systems/art-native-context-proposals.md
authority: current-documentation
document-kind: contract
status: Current
scope: Draft collaborative Art value schema, bounded native context, no-write preview, source policy, knowledge and deterministic fixture evidence
canonical-for: [art-native-context-proposals]
last-reviewed: 2026-11-25
Section: Art native context and typed proposals > Compilation, revision and zero-write preview
`compile(raw, context, policy, previous={})` returns normalized geometry, finite stages, source/policy/context identities, conservative budgets and an understandable error or warnings. It does not own a World or invoke a provider. A revision records its parent proposal digest and identifies added, changed and removed stage IDs. The model cannot weaken the separate pinned policy. The host retains previous proposals and must decide whether a new request is a revision, a separate proposal or a replan after native work. `art_authoring_preview.gd` uses the existing lazy `art_batch_plan.gd` raster against a private copied material plane. `configure(compiled,context)` binds the exact compiled source. Each `poll()` advances at most one ordinary 4,096-cell chunk; the existing raster also yields over sparse misses. Cancel retires the preview without native mutation. The preview checks actual emitted points, not only bounding rectangles. It refuses any requested cell outside scope, in a protected rectangle, outside the palette, on a source material other than 0/58, or requiring destruction without permission. A conservative bounding overlap is shown during compilation; only a real raster conflict causes the final refusal. A successful preview supplies per-stage requested, predicted changed and unchanged counts, introduced/removed material counts, and before/after material-plane hashes. At most 32 conflict samples are displayed, with the complete conflict count and explicit omitted count. Later stages use the predicted result of earlier stages, so a later attempt to repaint newly introduced protected Metal also refuses. These values are predictions, never native receipts. `zero_native_writes` describes this preview's authority; it does not claim that another system or the owner could not change the World while the preview was being prepared.

## ART-STORAGE-003: Does verifying a private pending Art history receipt restore old conversations or change native Undo authority?

Canonical rank: 3

Expected facts:

- Receipt identity and order advance only after complete closed-byte verification and publication.
- The retained private writer does not activate old-journal restoration in ordinary session-only Art.
- Native history and Architecture execution retain their existing owners; Windows and physical acceptance require distinct evidence.

### Rank 1: systems/workbench-direct-art-batches.md — Direct art batches — WB-ART-002 Stage 1 > Shared Undo and Redo

Document: Direct art batches, WB-ART-002 Stage 1
Path: systems/workbench-direct-art-batches.md
authority: current-documentation
document-kind: contract
status: Current
scope: Unmerged desktop direct drawing candidate, stored-native completion, Stop, shared PAINT ordering and Undo/Redo, authored-start persistence
canonical-for: [workbench-direct-art-batches]
last-reviewed: 2026-11-12
Section: Direct art batches — WB-ART-002 Stage 1 > Shared Undo and Redo
The Art batches Undo/Redo buttons and PAINT's buttons and shortcuts operate on one chronological history. Only confirmed stored-material changes enter it. Adjacent bounded parts of one direct batch or model drawing submission share an action: one Undo reverses the retained parts, and Redo reapplies them in order. A human edit between chunks closes that group and has its own entry. Undo never jumps over later manual work to target an earlier agent action. Use Stop and wait for batch execution, native receipts, deferred human edits, image capture, provider activity and any scheduled follow-up turn to settle. An idle native chunk boundary alone does not enable Undo. After retirement, Undo can reverse the confirmed applied prefix of a stopped drawing; cancelled or unacknowledged suffixes never enter history. The operation uses PAINT's bounded native preflight and receipt path. Its trusted human inverse can restore the recorded materials without granting ordinary agent submissions broader material, source, protected-region or work-area permissions. History retains at most 32 parts and 1,048,576 edit cells, with at most 262,144 cells per part. The UI labels a partially retained group **Agent drawing (retained tail)** and explains when its older part is no longer undoable. No-change agent receipts preserve the existing Redo branch. Simulation, World replacement or another mutation outside the recorded timeline still invalidate history through its generation/revision/tick fence. History is session-local. Confirmed history results append a human canvas-result turn and durable `history_result` event, with applied counts and continuation/refusal status. They do not rewrite earlier model receipts or automatically request another model turn. The chosen conversation/context mode still governs future requests. The existing persistence limits also apply to history replay. Agent streaming does not preflight the entire authored recipe, so a highly fragmented result can exceed 32,768 stamps or the 1 MiB save envelope. Save then refuses, and Undo/Redo can also refuse a target part before writing if its intermediate authored recipe exceeds those limits, even when the eventual group baseline would be compact. The UI reports the actual confirmed progress and refusal; there is no promise of unbounded or atomic rollback for arbitrary agent output.


### Rank 2: systems/workbench-direct-art-batches.md — Direct art batches — WB-ART-002 Stage 1 > Stop, replacement and ordinary painting

Document: Direct art batches, WB-ART-002 Stage 1
Path: systems/workbench-direct-art-batches.md
authority: current-documentation
document-kind: contract
status: Current
scope: Unmerged desktop direct drawing candidate, stored-native completion, Stop, shared PAINT ordering and Undo/Redo, authored-start persistence
canonical-for: [workbench-direct-art-batches]
last-reviewed: 2026-11-12
Section: Direct art batches — WB-ART-002 Stage 1 > Stop, replacement and ordinary painting
Stop increments the worker epoch and cancels a not-started chunk. An executing chunk can finish; the executor consumes its receipt and reports its actual prefix before becoming inactive. Old-epoch submissions are refused. No uncertain replay or rollback is attempted. A new batch is accepted only after retirement. New/Load/Restore discard stale callbacks from the old authored recipe and use the existing native replacement transaction. A retained settings/actor transition while drawing requests Stop and asks for retry after the current acknowledgment; this prevents transferring live cells without their recorded authored prefix. Geometry/settings rejection before replacement admission does not interrupt a batch. A later native-preparation rejection retains the old World and its confirmed authored prefix after the request-time Stop. Human strokes during a chunk are delivered before the next chunk and recorded in that same order with their original brush radius. Their pending queue reuses the existing worker command capacity; a full queue explicitly refuses further strokes until the chunk finishes. Ordinary camera/zoom, physics and paint controls remain owned by the existing workbench.


### Rank 3: systems/workbench-art-providers.md — Art workbench provider connection — Stage 2 > Diagnostics and retention > Session-scoped, write-only Art traffic — 22 November 2026

Document: Art workbench provider connection, WB-ART-002 Stage 2
Path: systems/workbench-art-providers.md
authority: current-documentation
document-kind: contract
status: Current
scope: Art providers, same-session collaboration, failure lifecycle, consolidated Draft UI and qualification
canonical-for: [workbench-art-providers]
last-reviewed: 2026-11-26
Section: Art workbench provider connection — Stage 2 > Diagnostics and retention > Session-scoped, write-only Art traffic — 22 November 2026
Each **new Workbench game session begins with an empty in-memory Art conversation**. The Send, Conversation and direct drawing controls never reopen, link, scan or copy traffic from a previous process or Workbench scene. The user can maintain multi-turn context *within the current session*; closing the session discards the in-memory conversation. Model/provider/endpoint/control preferences may still persist in `user://art-provider.cfg`, but no `traffic_path` is read or published. The obsolete profile pointer is removed on the next successful preferences save. On the first Art log event, the existing bounded writer creates **one new root JSONL** under `user://art-traffic/`. All following requests, provider responses, native results and in-session conversation changes append to that same file until the Workbench session ends. Hiding and reopening the Art window within the same Workbench does not create a second log. There is no automatic replay, linked predecessor, history-resume gate or full-history duplication. An unavailable, corrupt or deleted older log cannot prevent Send. Each model request writes a redacted `request_parameters` event containing the provider/model/endpoint, prompt, guidance, requested work rectangle, allowed materials, protected areas, enabled tools, token/time/turn limits and relevant image/context settings. The normal request/response/native receipt events follow. Direct JSON painting records `manual_program`, `manual_admission` and terminal `manual_result`. This provides the values needed for manual re-entry later; it does **not** promise to reproduce an evolving World from prompts alone or retain exact unlogged source World state. `Traffic…` displays the current session file path and can explicitly export it. Existing legacy and linked archives remain **unchanged** on disk, but are never attached to a new game session. The legacy archive parser remains available for standalone read-only diagnostics and old evidence tests; it is not part of the normal UI lifecycle. No automatic migration, deletion or cleanup is performed. PAINT's native authoritative Undo/Redo is independent of Art. When an Art window exists, confirmed Undo/Redo events may be appended to its current session log. Without an Art session, native editing does not force the Art panel or create a cross-session receipt journal. Old `user://art-pending-history` records are preserved as historical data and never injected into a new session. Disk logging failures remain visible, but must not retroactively repeat a native edit. **Scope boundary:** This is session-local authoring history, not a durable conversation database. Save/Open for the authored World and PAINT's own material history retain their existing independent contracts. New model requests must never trust a stale previous-session continuation pointer.


### Rank 4: systems/workbench-art-providers.md — Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate

Document: Art workbench provider connection, WB-ART-002 Stage 2
Path: systems/workbench-art-providers.md
authority: current-documentation
document-kind: contract
status: Current
scope: Art providers, same-session collaboration, failure lifecycle, consolidated Draft UI and qualification
canonical-for: [workbench-art-providers]
last-reviewed: 2026-11-26
Section: Art workbench provider connection — Stage 2 > Diagnostics and retention > Verified closed storage in the mergedown candidate
The unmerged Art/Architecture integration verifies closed output before acknowledging a stored event, completed export, preference update or retained private history receipt. `art_provider.gd::_store_event` verifies the exact new record region against the submitted buffers, without rereading the previous archive. An interrupted append leaves prior complete records readable and makes that session writer read-only; it does not claim to roll back an incomplete tail or repeat an already completed native edit. Export closes its staging file and cooperatively verifies its exact length and SHA-256 before the existing native atomic replacement. Traffic displays the verification phase; Stop and Cancel still interrupt it. Refusal or cancellation does not publish that export. The destination/source alias guard is checked again at commit. This remains a bounded streaming export, independent of model context and native painting authority. `art_batch_panel.gd::_save_settings` uses the shared bounded-text `workbench_file_transaction.gd` helper: complete closed-byte verification followed by the accepted native sibling-file replacement. Existing unchanged preferences keep their no-write cache. A failed write retains the earlier cache and file; only verified success updates the cache. Successful retry or reversion to the committed settings clears only the save-owned error. The profile's 1 MiB bound and prior-profile admission refusal remain authoritative. The retained private `_persist_history_receipt` method similarly verifies the closed payload before publication and before advancing receipt identity/order. Its existing schema, frozen projection, epoch and capacity checks remain. This does not activate old-journal restoration in ordinary Art sessions. Neither helper promises `fsync`, power-loss recovery, a multi-file transaction, or a cross-process editing lock; complete concurrent replacements remain last-writer-wins. The direct `test_workbench_file_transaction.gd` and `test_art_storage_integrity.gd` regressions exercise verification and refusal. `tools/ci/run_art_storage_qualification.py` runs disposable actual OS faults and retry, with a shared Windows sharing-lock fixture in `windows_file_lock.py`. The [registered mergedown campaign](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md) separates inherited failure evidence, resulting-source execution and pending Windows/owner acceptance. These source changes do not establish physical acceptance or change native runtime inputs.


### Rank 5: systems/workbench-art-providers.md — Art workbench provider connection — Stage 2 > Responsive conversation editor and Apply/Cancel

Document: Art workbench provider connection, WB-ART-002 Stage 2
Path: systems/workbench-art-providers.md
authority: current-documentation
document-kind: contract
status: Current
scope: Art providers, same-session collaboration, failure lifecycle, consolidated Draft UI and qualification
canonical-for: [workbench-art-providers]
last-reviewed: 2026-11-26
Section: Art workbench provider connection — Stage 2 > Responsive conversation editor and Apply/Cancel
The long Art conversation editor keeps its standard **Apply/Cancel** footer outside a scrolling body. Note text and unusually long conversation entries cannot grow the dialog beyond its parent. Art-owned window minimum sizes and bounds account for their content scaling; 720p/1080p and 100/125/150 percent geometry are checked separately from physical Windows display acceptance. The message list fills in slices of at most 128 entries or 2 ms per frame. Cancel/reopen invalidates outstanding slices. Apply uses the complete draft even while its list is loading. Draft entries copy on edit; cancelling cannot mutate the live conversation. Per-frame stale-edit detection checks a revision and count, and Apply checks the full baseline again before committing, including out-of-band changes. Long captions read a bounded prefix while typing. Individual messages longer than 4,096 characters use **Previous/Next** parts, with a part-number field for direct navigation. Only the current part is assigned to the visible text widget. Changing parts retains pending edits; Apply joins all parts and preserves the original image reference. Cancel/reopen restores the live conversation. Normal-sized notes keep the ordinary single editor. This is a display/editing bound, not truncation of the stored conversation or an increased replay capacity. Large clipboard insertions are divided before the visible widget shapes them; ordinary Copy/Cut/Paste retain the pinned native editing rules. Part navigation and paste spanning parts reset this text editor's local Undo history, as the page-control tooltip explains. Cancel still discards the complete draft. Native World Undo/Redo remains an independent, unchanged operation. Conversations with at least 262,144 characters prepare their complete redacted value and audit encoding in a bounded Provider-owned worker. The editor shows preparation progress and keeps Cancel available; text-changing actions and another Apply wait. Small edits retain the immediate path. Cancel, Stop, closing the editor, changed conversation/World/credentials, or a retiring owner refuses uncommitted work. Read-only navigation and Copy remain available. A queued panel, editor, Workbench or host is already retiring before deferred deletion. The owner thread still performs the complete durable journal append. Only a successful append adopts the redacted live conversation, before traffic observers run. Failed or cancelled preparation never adopts a partial draft. Native World history remains separate. Direct and collaborative requests, context refresh and stage approval wait for this pending Apply or its Cancel. Conversation remains available for persistent collaboration within the current Workbench session. Hiding and reopening Art preserves it. A new game session starts empty under accepted #727; World Save/Open is a separate native contract.
