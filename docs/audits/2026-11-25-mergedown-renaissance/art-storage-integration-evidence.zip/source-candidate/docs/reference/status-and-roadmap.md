---
title: Status and foundational roadmap
status: Current
document-kind: reference
scope: Current implementation map, unresolved correctness and policy decisions, and bounded next checkpoints
canonical-for: [implementation-status, foundational-priorities, open-decisions]
last-reviewed: 2026-11-21
related-documents: [validation-evidence.md, invariants.md, ../operations/documentation-maintenance.md, ../operations/architecture-programme-water-feel-addendum.md, ../operations/microscenarios-programme.md, ../operations/development-claims-remediation-programme.md, ../operations/water-hybrid-pressure-extension-programme.md, ../operations/github-development-and-release.md, ../audits/2026-09-24-cybersand-recovery-audit.md, ../architecture/pressure-optimization.md]
---

# Status and foundational roadmap

## Art storage integration candidate — 2026-11-26

The mergedown's unmerged Art/Architecture source adopts the narrowly reviewed
closed-file verification repair for exports, new/appended events, preferences
and retained private receipts. The
[provider contract](../systems/workbench-art-providers.md#verified-closed-storage-in-the-mergedown-candidate)
preserves settings-cache isolation, session-only conversation behavior and
native Architecture authority. Its
[registered campaign](../audits/2026-11-25-mergedown-renaissance/art-storage-integration-registration.md)
records exact donor boundaries and the required resulting-source fault and
authoring tests. ULTIMA remains protected; its unrelated CI and other consumer
changes are excluded. Windows storage, creative and physical acceptance remain
separate gates.

## Collaborative Art candidate — 2026-11-25

ART-WORKBENCH-COLLABORATIVE-002 / #780 is a Draft/HOLD successor with one owned
provider consumer per request, prose discussion, proposal revision, bounded
native/context disclosure, zero-write preview and finite native construction.
Each stage has fresh approval and actual readback. The
[owner guide](../operations/art-workbench-collaborative-evaluation.md) explains
the controls and limits; the [mission ledger](../audits/2026-11-25-art-workbench-collaborative-002/README.md)
owns exact source/platform/package outcomes, recovery and retained failures.
Fixture evidence is separate from genuine model creativity. Architecture
validation/execution stays with #777; no production default, merge, Ready
promotion or automatic model dispatch is authorized.

## WORLD-STEER-BATCH-M3-M5-001 — Draft/HOLD, 24 November 2026

The [architectural Workbench successor](../operations/world-steer-architecture.md) reconciles the preserved #720 Batch Lab with accepted main `00cdb02f103265b6dc5224c68283e9a0c8cb449f`. It adds native module harvesting/replay, 25 source-bound GOLDMAPS design cards, bounded retrieval, finite staged native construction, six examples and a registered 30-attempt contextual comparison. The [integration ledger](../audits/2026-11-24-world-steer-m3-m5/integration-ledger.md) preserves original campaign custody and successor qualification. Typed offline construction is independently executable; the separate Art successor owns conversational integration. Actual model quality, physical owner acceptance and any M6/M7 training remain unqualified. No merge or Ready promotion is authorized.

## WORLD-STEER-BATCH-001 M0–M2 — Draft/HOLD

The [Native Batch Lab guide](../operations/world-steer-batch-lab.md) owns optional independent native construction, comparative inspection, retained attempts and bounded experiments on the dedicated branch from accepted `846fe0533b3170e7b01f690518da49fc40cc24d1`. Qualification artifacts distinguish actual native/control outcomes, protocol fixtures, pending real model comparisons and physical owner acceptance. The subsequent M3–M5 authorization is scoped above; this original record grants no merge, production default, paid call or schedule.

## AMBIENT-001 modular procedural actors — 24 November 2026

**Opt-in implementation candidate, Draft/HOLD:** the
[ambient actor contract](../systems/ambient-actors.md) and
[owner guide](../operations/ambient-workbench.md) describe eleven reusable modules,
six profiles, five ordinary authored scenes and a staged per-actor profile editor.
The existing policy producer, issued observations, leases, native material
publications and physical movement mechanisms remain authoritative. Accepted
population capacity stays eight. The [mission ledger](../research/ambient-001/mission-ledger.md)
owns exact source/platform qualification, independent findings and remaining
Windows/visual/owner acceptance. Global pathfinding, arbitrary script execution,
physical immunity, inferred capabilities and exact physical-state continuation
are outside this candidate.

## CI-OPT-003 worldgen showcase execution — 2026-11-21

The [bounded showcase scheduling change](../operations/ci-execution-and-performance.md#parallel-worldgen-showcase-execution)
runs seven independent worldgen showcases through the existing two-job Make
budget. All seven remain required before the nine principal tests. The original
compiler flags, scientific fixtures, sixteen executables and sanitizer coverage
remain. Raw per-showcase output is retained before grouped replay, including
flushed partial output from hung or cancelled peers; source/run/attempt checks
reject stale or incomplete log inventories. The
dedicated CI-only PR records source-matched execution, controlled performance
and independent review before any merge or turnaround claim.

## CI-OPT-003 soliding compilation reuse — 2026-11-21

The [soliding build change](../operations/ci-execution-and-performance.md#soliding-compilation-reuse)
removes 30 repeated translation-unit compilations per complete normal or
sanitized target while retaining the original eight executables and test order.
Compiler/configuration/source identity guards local object reuse; interrupted
compilations cannot publish partial objects. Full Native and Windows/Linux
regression admission remains required. The dedicated CI-only PR records exact
source qualification and controlled timings before any merge or speed claim.

## Floating Oil in Wave Water

The [impingement tank replay](../audits/2026-11-20-wave-oil-impinge.md) tests whether Water waves can lift and lower a floating Oil slick. In the previous build the Water–Oil boundary remained fixed through 900 ticks of observation.

The [thick Oil and Lava evaluation](../audits/2026-11-19-wave-oil-lava.md) covers a radius-24 Oil brush on the owner’s ramp and Lava quenching compressed Wave Water. On one dedicated runner, the updated six-worker native tick cost 0.992 ms more on the Waterwall map and 0.775 ms more in the thick Oil tank at the median. The audit records p95, host differences and the source-matched Windows and Linux publication.

The [Oil tank evaluation](../audits/wave-oil-buoyancy-2026-11-19/evaluation.md) measures a buried slick, falling Sand and a fresh wave in the Windows Workbench. The longer-term [per-material solver and tuning target](../architecture/liquid-solver-family-policy.md#status) is Planned.

## Full-face Water release

The [full-face evaluation](../audits/2026-11-19-wave-water-face-004.md) tests outward spray throughout an exposed wall at fall speed 3 and tracks abrupt ramp crests against the motion of the Water.

## Water ramp and player defaults

The owner selected Wave Flow with spill and ballistic release for new player sessions. The [water ramp experiment](../audits/2026-11-19-wave-water-ramp-003.md) measures floor-attached spread and returning waves against #676.

## Wave Waterwall 002 owner evaluation

The [Waterwall 002 candidate](../audits/2026-11-19-wave-waterwall-002.md) adds optional Wave settings for ledge sheets, crest flight and deep-water slosh. The [Water Lab](../operations/workbench-water-lab.md#try-the-waterwall-002-candidate) stages both bundles. The owner approved the combined gameplay profile after the [Oil impingement playtest](../audits/2026-11-20-wave-oil-impinge.md).

## Unified World Art pipeline — 2026-11-20

**Implementation candidate, Draft/HOLD:** the [unified art contract](../tools/art-pipeline-unification.md)
provides one shared Godot RG8 renderer, interactive viewer, unattended capture,
verified offline gallery and portable Windows evaluator for fifteen collections
and 120 features. Art-only bounds are 16,384 cells per axis and 16,777,216 cells
in total; ordinary full export is limited to 50M pixels and opt-in streamed
export to 100M pixels / 65,536 per output axis. Native simulation/import limits
are unchanged. The [capture guide](../tools/world-art-capture.md) owns explicit
failure/no-takeover semantics; the [evaluation guide](../tools/world-art-evaluation.md)
owns owner usage. Exact-source qualification and independent review are recorded
in PR #685. Hosted ANGLE is separate from owner Windows/NVIDIA acceptance.

## Shared Workbench actor composition / #589 — 2026-11-20

**Implementation candidate, Draft/HOLD; no merge authorization.** The owner
advanced #589's earlier planning boundary through WB-ACTOR-COMPOSE-001. The
[composition contract](../systems/workbench-actor-composition.md) exposes 59 existing
physical model identities through one prepared Workbench session: eight flyers,
46 physical rigs, four 4LY profiles and the passive barrel. Per-instance Human,
Scripted NPC, External Policy and Passive sources retain existing producer,
issued-observation, lease and equipment admission. Live takeover preserves the
body graph and resources. Inspection and painting do not take NPC control.

The [Mixed Actor Workshop](../operations/workbench-actor-composition.md) uses six
actors with different mechanisms, three compatible tools and an actual leased
policy fixture in a material-cell canvas. Setup-v2 gains a strictly validated
optional control-v1 extension; authored Save remains separate from live physics.
Sampled arenas, oracle/tag combat, NCA training and model services remain outside
this integration. A bounded adapter reuses Thunderbowl's pure local steering
helper without importing its simulation owner. The
[dated evidence](../audits/2026-11-20-workbench-actor-composition.md) owns exact
source/runtime identities, platform results, failures and remaining owner checks.

## Experimental Gentek catalogue integration — Draft/HOLD, 2026-11-17

The stacked [GENTEK-SHOWCASE-INTEGRATION-001 #671](https://github.com/techrote/cybersand/pull/671)
collects all eight independent advanced showcase PRs (#663–#670) onto the frozen
72-module [CLASSIC #624](https://github.com/techrote/cybersand/pull/624).
The combined source-matched native and Linux/Godot material qualification passes
for an **80-module candidate** and two mixed five-style maps; the
[research integration record](../operations/gentek-showcase-integration-001.md)
owns exact source/PNG provenance, remaining review and owner approval.
Both PRs remain **Draft/HOLD; not accepted main, not Ready, not merge-authorized**.

## GENTEK-80 integration candidate — 20 November 2026

A fresh Draft/HOLD branch from accepted `de109d01` reconciles all 72 repaired
CLASSIC samplers and eight advanced showcases through the existing Architectural
Generator. See the [source reconciliation](../research/gentek-80-integration-001.md)
and [evaluation procedure](../operations/gentek80-evaluation.md). The 80 additions
coexist with 13 accepted presets; catalogue counts do not remove legacy choices.
Compiler cache identity, complete native visual evidence, target-OS Workbench
persistence and source-qualified Windows packaging are mandatory admission gates.
Exact results remain in dated evidence. Owner merge approval remains required.

## GEN-008 Flatten / Bake History — 2026-11-13

**Implementation candidate, Draft/HOLD:** issue #548 starts independently from
accepted `ac0d9fb944cb` (#564/#565). Its [canonical contract](../architecture/shared-workbench-authoring-data.md#flatten-and-storage-compatibility)
captures complete native stored IDs into a uint16 little-endian authored baseline,
retires old construction/history, and leaves the live World, tick and physical
state unchanged. Explicit Save/Load uses standalone material-baseline v1 with
legacy Setup-v2/generated-start-v1 compatibility. The [qualification runbook](../operations/gen008-flatten-qualification.md)
links source-matched execution and Owner acceptance; no merge is authorized.
The 11 November revised issue supersedes the former reset/respawn/rollback proposal.

## Architectural Generator Phase A/B + owner-refined v2 — 2026-11-15

**PR #582 remains unmerged under explicit owner hold.** The
[architectural generator specification](../systems/architectural-generator.md)
describes thirteen composable presets, five simultaneous style columns,
global automatic tunnel/door/window controls and per-preset native material
parameters, deterministic finite zone quotas, versioned Skyline Terraces,
Cellular Hive and Arched Viaduct algorithms, and generated-start replay.
The [owner walkthrough](../operations/architectural-generator-playtest.md)
covers graphical preview, installation and save/reopen; owner assessment
accepted the distinctive geometries while identifying future per-style
palette and aperture authoring improvements. Arched Viaduct v2 remains the
owner-accepted fixed reference. Source-matched Linux/Windows graphical and
Windows packaged-copy qualification includes the integrated GEN-008 Flatten
author/reopen and failure-recovery cases.

The [runtime completion record](../audits/2026-11-15-gen007-runtime-completion.md)
binds qualified source `6d6e2cd6` to actual four-file publication `99d7bd2b` on
the existing PR branch. Linux/Windows native, graphical, multistyle, Flatten and
extracted Windows package replay passed; the materialized Git LFS libraries and
both provenance manifests pass strict current source/runtime verification.
Final-head Documentation/provenance, palette and broad CI are recorded in
PR #582 after the final documentation follow-up; this dated publication result
does not substitute for those checks.
The [strict publication contract](../systems/architectural-generator.md#retained-runtime-publication)
supersedes the previous source-only merge proposal. Routine native/Godot
architecture tests and bounded publisher guards continue on accepted-main CI
after integration; the full graphical/package campaign stays explicit.
**Ready-for-review is a CI state; no merge is authorised.**

## Materials Lab v1 — 2026-11-11

Separate [PR #563](https://github.com/techrote/cybersand/pull/563) replaces the
two native hard/granular predicates with canonical generated capability maps.
The [source and native proof](../audits/2026-11-11-material-native-capability-cutover.md)
preserve all values, IDs and policy/save identities; the frozen lock remains
unchanged. This is one bounded #353-B consumer, not the wider catalogue cutover
or #384's display-name route. Runtime publication and platform gates are separate.

**Merged in #562 on 2026-11-13.** The
[Materials Lab](../operations/materials-lab-authoring.md) mounts in the existing
desktop launcher/Workbench and provides native effective-property inspection,
structured candidate editing, strict preset round-trips, compiled native pair
tests, source-matched candidate/reference World comparisons and reproducible
existing-material MicroScenarios. Review fixes cover source-custody races,
complete reaction comparisons, preset path aliases, cancellable subprocesses,
imported controls and incremental reference replay. The
[qualification record](../audits/2026-11-11-materials-lab-v1.md) states executed
platforms and limits. This advances #353/#355/#356 under the owner's new bounded
implementation authorization; broad #352–356 remain open. Production has its
unchanged 132 slots, reserved10, 56 pair rules and legacy World authority.
Synthetic132 is descriptor-test-only. Existing-ID density/RGBA, admitted viscosity
and pair edits execute in isolated compiled Worlds with native cell/quantity,
repeat, one/four-worker and same-build persistence checks. Capability/projection
edits are refused by that World backend. Candidate tests do not install a
material in the running application.
The implemented review adds explicit effects v2 for retained non-Water endpoints and
declared Metal/Combustible state-B writes in external Worlds, plus source-bound
recipe save/import. Failed native receipts, changed executable/generated bytes
and mismatched exports are refused; Windows staging uses portable source paths.
The [completion continuation](../audits/2026-11-11-materials-lab-completion.md)
adds copied native contact/mask/core-window diagnostics, Windows process lifetime
ownership, source-matched runtime publication and a self-contained Windows
authoring package. Actual automated platform results remain source-qualified;
human acceptance is not inferred. The bounded #353-B hard/granular generated
consumer is reviewed separately in #563.
The Windows evaluation continuation repairs the current Git distribution's
portable layout, readable small-window overflow, pending numeric input and stale
resolver diagnostics. The completion audit retains each campaign's actual
source/package result; a failed package stage is not a delivered executable.
The Workbench Lab also uses an independent native desktop window where supported,
with physical-pixel scaling and local input; embedded fallback remains available.
Its client and frame are admitted within the usable work area; insufficient
desktop capacity is reported explicitly. Failed request8 remains recorded.
The final Windows evaluation exposes the existing native PressureFlow reference
solver in **Try originals** and restores it from source-matched experiment cases.
The [merge and package evidence](https://github.com/techrote/cybersand/pull/562)
records the tested source and runtime identity.
The owner explicitly
excluded MoltenGlass H1 from this continuation; it is not a Lab delivery gate.
Historical liveness evidence and production thermal/rest behavior remain
unchanged. Older dated boundaries below retain their historical scope.

## WB-ART-002 direct drawing — 2026-11-10

**Accepted session contract, #727:** every new Workbench game session starts
with an empty Art conversation and writes one lazy root JSONL. No historical
conversation is restored. Same-session collaboration survives Art Hide/reopen.

**24 November finisher, Draft/HOLD:** the
[Art evaluation guide](../operations/art-workbench-final-evaluation.md) owns
consolidation of #763/#756/#765/#766, provider failure lifecycle, long-history
responsiveness and physical no-server acceptance. Native/source and runtime
qualification are separate from the owner's Windows hardware verdict.

**Unmerged integrated candidate, 2026-11-11:** the [PAINT + agent runbook](../operations/wb-art-paint-integrated-candidate.md) records the preserved current #544/#560 heads, generator packaging repair, stored-material readback and one native edit/receipt boundary. The full multi-material PAINT editor and agent providers, conversation/context, scanlines, multiple turns and diagnostics are implemented together. Existing Setup/generated-start formats and PAINT capacity/recovery rules apply. Keep Draft; combined Windows/Linux qualification and owner acceptance remain distinct from earlier separate-branch passes. #531 remains reference only.

**2026-11-12 hardening:** the same candidate closes queued-Save, late Fill-Cancel,
adaptive large-Fill capture, failed-replacement receipt-retirement and overwritten
native installation acknowledgement defects.
Installed qualification now exercises 1024² maps and same-session equipment,
simulation and fresh-process authored-start reconstruction. The runbook and
#564 distinguish actual resulting-source results from the earlier package;
retained-runtime publication and owner acceptance remain separate merge gates.


## Workbench liquid equipment (#361) — 2026-11-09

**Accepted through #553 at `d8588716`; no default changed.** The shared workbench gains an
opt-in [valves, drain, pumped nozzle and the liquid-lab / reservoir-lab starts](../systems/workbench-liquid-equipment.md)
authored in an optional Setup-v2 `equipment` block and run by a worker-owned device
owner through ordinary booked native edits and the #406 ballistic owner. No native or
GDExtension source changed. [Dated evidence](../audits/2026-11-09-in-tools-361-workbench-equipment.md)
records local Windows and WSL Linux 1/4-worker runs across the inertial, pressure,
whole-cell and Current Water families with exact native ledger closure. Those historical runs remain separate from the [integrated PAINT and agent
candidate](../operations/wb-art-paint-integrated-candidate.md), which preserves
the accepted equipment code and qualifies the resulting source together. Human
feel and physical-actor usable acceptance are not implied by automated passes.

## EXPLORE-001 generated playable maps — 2026-11-08

**Review candidate, not accepted main:** [PR #542](https://github.com/techrote/cybersand/pull/542)
connects the native GEN-007 final play plane to the ordinary Shared Workbench's
prepared World, existing flyer/camera/brush controls and authored-start save/reopen.
The [contract](../systems/explore001-generated-playable-maps.md) owns its finite
limits and unchanged Setup-v2 wrapper. [Independent QA](../audits/2026-11-08-explore001-integration-qa.md)
found and corrected a repeated chunk-preview cursor defect. Exact-head native,
desktop and retained publication gates remain separately required; the
[Windows playtest](../operations/explore001-desktop-playtest.md) requires a human
verdict. On 2026-11-08 the owner authorized recording the
[shared authoring data contract and convergence plan](../architecture/shared-workbench-authoring-data.md),
then #542 Ready promotion and resulting-head checks, **without merge**.
Converge admitted desktop/painting/agent/remote work incrementally into main,
preserving active owners and qualifying each join. #548 material-only Flatten
was an Approved semantic successor at that dated checkpoint; the 13 November
GEN-008 candidate above now implements the revised contract independently of #542.

## Wave flow Water solver (WAVE-MT-001) — 2026-11-15

**Waterwall stack review remediation, 2026-11-18:** the posted #672 review
identified wet-destination diagonal leakage, overflow before automatic spill's
coordinate admission, unapplied focused Water Lab text, rollback of other-liquid
policy when changing Water law, and launch reaction bypassing Body push.
The [remediation record](../audits/2026-11-18-waterwall-review-remediation.md)
tracks the focused repairs and resulting-source qualification separately from
the earlier green runs. Repairs belong to #672 only; #661/#631 stay unchanged.
That checkpoint held merge and used default-off behavior. The original surface-crest crash and
physical Windows/NVIDIA owner acceptance remain separate unresolved evidence.

**Waterwall provisional crash containment, 2026-11-18:** Draft #672 retains the
opt-in spill/ballistic/blobs candidate above unchanged #661/#631. Its owner now
authorizes extensive testing and a provisional fix. Native Godot boundaries
quarantine unexpected exceptions, preserve the first diagnosis and prevent
failed edits or observations from becoming healthy Workbench publications.
Body-occupancy diagnostics record stage/body/source/target without changing the
Water law. The Waterwall publisher requires native boundary stress and actual
Godot failed-world/publication/recovery regressions on Linux and Windows. The
original surface-crest trigger remains unconfirmed; platform execution results
and package identity are maintained in the PR ledger. Keep Draft/HOLD, original
spill-off golden hashes and default parcels/tick 256. Human acceptance, Ready
and merging remain separate owner decisions.

**Shared Workbench continuation, 2026-11-16:** the owner now evaluates Wave in
the ordinary Workbench using `Open Workbench.cmd`, editable Water comparison
scenes and bounded tuning. The [finisher record](../audits/2026-11-16-wave-workbench-631-finisher.md)
retains the two activation/readback failures at `3889cdd5`, the exact Baseline
transport admission repair and the requirement for actual native ticks and
positive replacement receipts. Earlier dedicated-evaluator qualification does
not qualify this integration. Final source, runtime publication, full CI and
independent review are recorded on PR #631; owner evaluation and merge remain
separate gates.

**Experimental PR #631 candidate inherited from #618, not on main; no default changed.** The
[wave flow reference](../architecture/wave-flow-v1.md) adds an opt-in bulk
strip-parallel Water law (`WorldConfig::wave_flow`, `wave_flow_v1`) with a
retained per-face flux. It has no pressure head field, flood fill or gas state.
PR #618 adds [Godot selection and a Windows evaluation route](../operations/wave-flow-evaluation.md),
real Rapier/Needle fixture coverage, region pause/reentry, full retained-state
identity, explicit save/restore refusal, uint16 mass readback and regressions
for thin films, edits, capacity and worker seams. It is **not** a
`LiquidSolverPolicy` family. Water-owned chemistry/coherence, lighter-fluid
exchange, full buoyancy and physical persistence remain unsupported.

The [completion ledger](../audits/2026-11-15-wave-mt-001-completion.md)
owns the exact-source/runtime/CI/performance/review evidence and remaining
acceptance for #618. [PR #631's takeover record](../audits/2026-11-15-wave-mt-001-astra-takeover.md)
and its PR ledger now own resulting-source qualification and independent review;
the predecessor branches remain unchanged. The [original #617 evidence](../audits/2026-11-15-wave-mt-001-wave-flow.md)
does not qualify later source. Policy-family/default promotion and human
Windows/GPU acceptance remain separate owner decisions. Merge is not authorised.

## Ballistic Water, IN-B1 and workbench spray (#362) — 2026-11-05

**Experimental draft, not on main; no default changed.** The
[ballistic Water reference](../architecture/ballistic-water-v1.md) adds an opt-in
native parcel owner (BW-001 `ballistic_water_v1`) that moves exact Water quantity
between any bulk family and ballistic flight, an opt-in signed-vertical IN law
(IN-B1), and a workbench impact-spray/jet law. The
[dated evidence](../audits/2026-11-05-wcx-ballistic-water.md) shows identical
Water trajectories across LA-SA/LA/events-off/RFT in pure Water, an exact
closed-system Water total during real Rapier splashes in four families, and a
≈52–55-row crown splash. Human gameplay acceptance, platform CI, runtime
publication, reviewed protected-source transitions and independent review remain open.

## MAT-AUTH reviewed per-file transitions — 2026-11-04

The owner approved a narrow way to admit a reviewed, behaviour-preserving edit
to one protected legacy consumer without refreshing the compatibility lock
([decision record](../audits/2026-11-04-mat-auth-reviewed-transitions.md),
[rules](../operations/material-catalogue-shadow.md#reviewed-per-file-transitions)).
Entries are code-pinned, authenticated against retained Git history and a
committed record, and refused for identity inputs. The table starts empty;
the lock, baseline and digests are unchanged. #382 (#201 P1) is the first PR
to add an entry, together with its source change.

## PressureFlow desktop region flip (#201) — 2026-11-04

The [region-flip record](../audits/2026-11-04-lcb201-region-flip.md) fixes a
desktop worker ordering that discarded the PressureFlow cache twice per step in
fixed-interest scenarios. In the real host on main's runtime, the cached quiet
pool improves from ≈36 ms to ≈10 ms per worker step and reaches the 60 Hz cap;
reference and FreeMass are unchanged. The camera-only follow-up is implemented on PR #405 (pending final-head
qualification); see [the current-main source audit](../audits/2026-11-07-pr405-current-main-reconciliation.md).

## PressureFlow idle cost (#201) — 2026-11-04

The [#201 idle-cost record](../audits/2026-11-04-lcb201-pressure-idle-cost.md)
measures accepted main `3da7e7be` natively, and is consistent with draft #370's
≈30 ms quiet-pool PressureFlow tick.
The pool's Water sleeps; the cost is serial reference preparation over the 1.64M
cells that the prepared 1024² route makes resident. Same-law cached and
cached_dormant variants cut quiet cost from ≈31–41 ms to ≈9–12 ms per native tick (FreeMass ≈0.02 ms). They are not
idle-free: a per-tick wake scan remains, and gas-input edits or moving body
masks restore roughly reference cost.
**Task outcome B** (not #26's): residual cost is excessive at this scale. Two bounded
cached-only proposals (P1 wake-summary elision, P2 narrowed gas revocation) are
**Planned, not implemented**. No production code, default or host changed; #201
stays open, and a full-host cohort remains the next practical-cost experiment.
An [experimental P1 draft](../audits/2026-11-04-lcb201-p1-wake-summaries.md),
not accepted and not on main, cuts the quiet cached tick to ≈0.32 ms with exact
parity. It shows a small cost under continuous index churn. In the real desktop
host, a per-step simulation-region flip erased the gain (cached ≈34 ms); with
the flip fixed on main (above), the committed in-app cached step is ≈0.9 ms at 60 Hz.

## Material shadow foundation and integration — 2026-11-04

[#357 is merged](https://github.com/techrote/cybersand/pull/357#issuecomment-6619591556)
and the [corrected architecture is owner-adopted as Planned](../architecture/material-authoring-catalogue-plan.md#12-owner-adoption-and-shadow-compiler-handover--2026-11-04).
[#353-A's shadow compiler](../operations/material-catalogue-shadow.md) merged in
#371 at accepted main `7ef4856e225a2cc2a6e5c36ca33a2dab40e123f1`.
It provides deterministic candidate metadata,
independent native parity and frozen source/identity guards; it does not replace
production material authority. The [current boundary](../architecture/material-authoring-catalogue-plan.md#14-material-liveness-phase-a-and-production-admission--2026-11-04)
and [#371 ledger](https://github.com/techrote/cybersand/pull/371) separate code,
resulting-head acceptance and actual merge status.

| Programme slice | Current disposition |
|---|---|
| #357 architecture | Owner-adopted Planned baseline, documentation merged |
| #353-A / #371 | Merged shadow tooling and 27-source guard; legacy production definitions remain authoritative |
| #353-B | Separate consumer-migration admission required; no production switch authorized |
| #354 / #377 | Phase A evidence-only current-main reconciliation and guarded integration authorized, subject to [fresh final-candidate gates](../operations/material-liveness-investigation.md#which-gates-control-phase-a-integration); H1 remains unrepaired, H2/H3 preserved, production admission pending and issue open |
| #355 | Separate endpoint-effects implementation programme; serialize any overlapping World/quantity writes |
| #356 | Separate inspector/editing work; effective controls need actual native consumers and applied readback |
| #358 | Independent experimental material work;132–137 not integrated here |

Broad #353 and parent #352 remain open. The original implementation receipts
retain their tested source; no metadata or source-byte comparison by itself
establishes fallback simulation, new physics or human gameplay acceptance.

The [liveness guide](../operations/material-liveness-investigation.md) routes
reproduction and the [ranked correction design](../audits/2026-11-04-mat354-correction-admission.md).
No scheduler or physical-law patch is part of Phase A. Source-qualified execution,
retained failures, actual worker participation and unexecuted platform gates remain
in the [findings](../audits/2026-11-04-mat354-findings.md) and live PR ledger.

## Material authoring Planned adoption — 2026-11-04

**Historical documentation-adoption scope.** The assignment statements below
precede reconciliation of the separately implemented #371 candidate. The
current A-only status is recorded above; the original adoption remains intact.

The [corrected MAT-AUTH architecture is owner-adopted as Planned](../architecture/material-authoring-catalogue-plan.md#12-owner-adoption-and-shadow-compiler-handover--2026-11-04).
The owner approved documentation-only guarded integration of #357 after final
checks; the [PR ledger](https://github.com/techrote/cybersand/pull/357) records
actual integration status. This supersedes only the adoption hold in the dated
review below. Runtime material behavior and backend/source-byte identities remain
unchanged, and #353-A implementation is still a separate, unstarted assignment.

Use the [bounded shadow-compiler handover](https://github.com/techrote/cybersand/issues/353#issuecomment-6619162661)
before that assignment. Keep the #353 → (#354/#355) → #356 chain and all separate
consumer-cutover, semantics and runtime-editing decisions; parent #352 stays open.

## Material authoring review — 2026-11-03

**Historical checkpoint:** the [4 November adoption](../architecture/material-authoring-catalogue-plan.md#12-owner-adoption-and-shadow-compiler-handover--2026-11-04)
supersedes the adoption hold below; the later [A-only integration boundary](../architecture/material-authoring-catalogue-plan.md#13-bounded-compatibility-tooling-and-adopted-main-reconciliation--2026-11-04) supersedes its unstarted-assignment status. The retained review describes its original date.

The [MAT-AUTH proposal](../architecture/material-authoring-catalogue-plan.md#11-current-main-review-and-implementation-admission--2026-11-03)
has a source-qualified **ACCEPT WITH CORRECTIONS** recommendation, not owner
adoption. #357 stays draft/unmerged. The recommended first #353 checkpoint
generates shadow metadata while preserving native/fallback behavior, header-byte
LCB identities and positional quantity ledgers. Production cutover and new
semantics remain separately gated. #354/#355 serialize shared kernel writes;
#356 exposes only real consumers. The [review](../audits/2026-11-03-mat-auth-000-architecture-review.md)
preserves #162/#358/#347/#370 and GCR ownership and the original intake.

## LCB current-main reassessment — 2026-11-03

The [#359 source-qualified audit](../audits/2026-11-03-lcb-reassessment.md)
verifies main `89020b9eb6d540383a5bb64b58dcd29a87592c32`, including merged #332.
Four liquid families are implemented: FreeMass, CellularYield, PressureFlow and
InertialCellular. Water admits all four; Brine admits CY/IN; the other nine
liquids admit CY. Pressure reference/cached/cached+dormant are one family.
Ordinary application presets and shared PLAY exercise real native/Rapier owners;
actual native task participation is observable. This is execution capability,
not a completed fair four-family performance or human-feel comparison.

IN retains momentum but constrains downward-positive vertical velocity to
nonnegative values; apparent bubbles do not establish gas pressure, and body
overlap relocation preserves existing liquid motion without injecting impact
velocity. Source-qualified worker, pressure timing, memory, Windows/Linux and
historical Web evidence is inventoried without rerunning expensive campaigns.
The [canonical policy](../architecture/liquid-solver-family-policy.md) and
[comparison runbook](../operations/lcb-manual-comparison-ux.md) now describe
landed work separately from dated pre-merge checkpoints.

Minimum remaining work is #360's bounded fixture/receipt integration and actual
playable comparison, reusing parked #258/#259; #361 supplies narrowly scoped
gameplay tools; #362 investigates impacts/upward spray after baseline reuse;
#363 makes the evidence-based decision. No kernel/default/runtime/CI change or
implementation merge is part of #359. Original LCB issues stay open. Coordinate
shared host changes with PLAY and native contact changes with #347.

## Stopped PLAY recovery — 2026-11-02

[PR #332](https://github.com/techrote/cybersand/pull/332) preserves the reviewed
fresh-owner Restart implementation on accepted shader/render-copy main
`a8f08a67`. The [canonical contract](../systems/player-control-playground.md#stopped-composed-session-recovery)
distinguishes accepted recipe/settings from pending edits, whole-owner retirement,
paused tick-zero reconstruction and launcher cancellation. Its
[reconciliation audit](../audits/2026-10-31-play-stopped-session-recovery.md)
preserves original failures and identifies the necessary Windows helper-control
oracle correction. The PR ledger owns exact-head CI, independent review and
guarded-merge status; this source description alone is not a qualification pass.
PACE004 (#334 merged as apparatus-only main `070c7a22`; its exact-head hosted campaign remains Planned) and the physical/device/display/human acceptance areas remain separate.

The 2026-11-01 [CI scheduling qualification](../audits/2026-11-01-ci-scheduling-qualification.md) and [repository-wide workflow audit](../audits/2026-11-01-ci-workflow-audit.md) separate expected shard cost, generous individual watchdogs and aggregate hosted safety. Eight jobs per platform bound GDExtension fan-out; superseded PR checks cancel while explicit qualification keeps distinct run groups. The owner authorized final review and conditional integration; [PR #340](https://github.com/techrote/cybersand/pull/340) records exact-head and post-merge gates. Historical draft qualification remains distinct from final integration acceptance.

## Current owner policy and accepted baseline — 2026-10-31

The owner supersedes the earlier shader deferral and short immutable deadline
restrictions below. Integrate and qualify #326 on accepted main `adaaa37`; use the
[shared execution watchdog and advisory performance policy](../operations/ci-execution-and-performance.md).
Its original attempt-1 post-merge Docs41204873388, scope41204873081,
Native41204873121 and Godot41204873192 all passed. #269 is closed;
#268/#270/#263 still require their remaining actual acceptance evidence.
#324/#325 were already included and are administratively closed.

The focused timeout/telemetry source requires fresh full CI and independent
review. Shader integration and the source-preserving Windows crash diagnostic
remain separate work packages. Historical failures keep their original status.
The physical/human packet still has 51 untested rows. Scheduswarm stays paused;
[#305](https://github.com/techrote/cybersand/issues/305) owns current coordination.
Earlier dated checkpoints below describe their original restrictions and source,
not today's superseding owner decision.


## PLAY desktop continuation — 2026-10-31

The [INPUT010 correction](../audits/2026-10-31-play-input010-pause-transitions.md)
revokes queued input immediately at pause transitions and supplies shared
P/Escape/selected-pad Start parity. It is accepted through #318 at
`afa8185c8dc57405ef54765a6cdf71cb7bfbf6e4` after its complete exact-head matrix
and independent review. Post-merge checks remain separately recorded. The
earlier #317 post-merge Native run41175310972 failed the unchanged worldgen
sanitizer build/run deadline with its ninth test incomplete; that original
failure remains visible while a bounded build-scheduling correction is reviewed.
[UI007](../audits/2026-10-31-play-ui007-desktop-readiness.md)
adds authored checkpoint targets, source-bound optional worker participation
details and a visible Return to launcher route. The
[manual packet](../operations/play-desktop-manual-qualification.md) authenticates
source, all retained runtime objects and the official engine before preparing
51 untested physical/display/human rows. These are implementation capabilities;
the respective PR ledgers own exact-head CI, review and merged-state claims.
UI007's first ordinary matrix is not qualified: an original Windows
post-summary access violation and separate incomplete TSan timeout remain
failed. The subsequent read-only empty-publication correction addresses its
own independently reproduced defect, without claiming to cure either failure.

Preserve the accepted 50-real-lifetimes-per-platform baseline and original
failures. The separate 40-event PACE004 successor remains a qualification lane,
not a release claim. First cold Linux shared-Main graphical attempts exceeded
the existing 30-second acknowledgement bound; headless native/Rapier results
and overlay-only pixels do not erase those failures. #268/#269/#270/#263 remain
open until their actual remaining contracts are reviewed. Physical devices,
real OS focus, actual display pacing and human feel remain unqualified.

Owner holds remain: no shader compilation/cache/decomposition work; #308/#310
held, #312/#316 frozen and unmerged; Scheduswarm paused. Follow the current
#305 manual ownership ledger before assigning successor source owners.

## Production CI parallelism — 2026-10-31

**Implemented in this integration source; resulting-head qualification remains
separate:** six independent Native families with original command limits and a
complete `native` aggregate; four Windows Godot shards with independent coverage
that fails on an admitted failed/missing matrix; unchanged Linux and scientific
coverage. The conservative Native scope report authorizes no skips. The
[dated audit](../audits/2026-10-31-ci-parallel-production-integration.md) preserves
the actual predecessor timing, five rejected deadline expansions, adverse tests
and exact [qualification/integration ledger](https://github.com/techrote/cybersand/issues/305#issuecomment-6537154140).
Faster CI cannot satisfy the separately red #309/#308 graphical contract.

## PLAY composable desktop checkpoint — 2026-10-30

**Current owner boundary:** [decision 6522029843](https://github.com/techrote/cybersand/issues/263#issuecomment-6522029843)
accepts merged #302 (`8d2dd843`) for the mandatory native-busy responsiveness,
outstanding-job shutdown and resource-ordering gate. Optional #304 remains
non-blocking and its failed run41046902349 remains failed. The critical path is
#268 integrated product → #269 remaining meaningful stress/measurement → #270
physical-device/human-feel/promotion → #263. #266, #267 and #273 were reverified
closed; #265 remains Not Planned, #271 deferred and #272 conditional fallback.

**Current implementation candidate:** [PLAY-UI-005](../systems/player-control-playground.md#integrated-playable-session-selection-and-device-rearm)
adds one real shared-host selector for course, five rigs, controls, lap/free-play,
solver policy and camera, plus selected-controller-change cancellation/rearm.
The [dated record](../audits/2026-10-30-play-ui005-integrated-session.md) separates
focused local evidence from required exact-head hosted CI and unexecuted manual
gates. It changes no native solver/default or simulation owner.

**Current accepted slices:** existing-host feasibility #273, five-rig and
construction-time solver composition #267, shared controls/camera/lap/gamepad
event slices of #268, normal lifecycle PR #284 (`8288e580`), and native
participation/reference measurements PR #285 (`1a7f9dd5`), solver reconstruction
PR #287 (`e50a7db3`), temporary-publisher retirement PR #288 (`37da3c6c`),
prepared-construction shutdown PR #289 (`91778603`), populated control/lap
retirement PR #291 (`5374a343`) and actual Main/reference-Rapier native failure
and ordinary recovery PR #293 (`4b6ca055`).
The [player contract](../systems/player-control-playground.md#accepted-normal-desktop-lifecycle-qualification)
owns exact source/CI/review identities and the 50-real-lifetime-per-OS result.
The same contract records the bounded solver-construction/refusal regression
and its 335/0 Windows and Linux Godot result, with [PR #287](https://github.com/techrote/cybersand/pull/287)
owning the final CI/review/accepted-tree receipt.
**Open:** final #268 integrated selection/device/pacing qualification,
#269 broader course/failure/stale-delivery and effect stress where not already
covered, and #270 representative rendered pacing and desktop/manual acceptance.
The mandatory native-busy requirement is satisfied by #302. Configured capacity, actual task participation,
concurrent execution, reference timing and human feel remain distinct claims.
The accepted shared `CyberSimulationWorker` plus main-thread Rapier remains
the implementation path; #265 is closed Not Planned and #271 stays deferred.

**Prepared-construction regression:** the
[LIFE003 player-contract section](../systems/player-control-playground.md#actual-host-prepared-construction-teardown-regression)
records a test-only actual-host precommit shutdown fixture and its source-bound
local Windows 150/0 combined-source result. PR #289 subsequently accepted final
source92e0 after exact-head Windows/Linux150/0, Native/Docs and distinct review;
main91778603 has separate passing push runs. The linked audit preserves all
source-specific receipts and original failures; the fixture supplies
no slow-native-job, native-thread trace or release claim.

**Accepted populated retirement:** the
[LIFE004 contract](../systems/player-control-playground.md#populated-command-and-lap-retirement-regression)
adds all-five-rig actual-host queued-input/lap reconstruction and reset checks.
Source d3ad passed its own exact-head checks and distinct source/execution
reviews before merge5374. Windows/Linux335/0 is bounded to those populated
construction/reset cases; broader stale delivery/effect, native-busy, failure
and release gates remain open.

**Accepted bounded failure/recovery:** the
[LIFE005 contract](../systems/player-control-playground.md#actual-main-native-failure-and-ordinary-recovery-regression)
adds an actual Main/reference-Rapier native capacity-fault and ordinary reset
regression. Source385 passed exact-head Windows/Linux30/0, Native/Docs and
distinct reviews before merge4b6c. This qualifies the three-reference-body
ordinary reset boundary; it does not qualify SetP course recovery, prepared
liquid recovery or native-busy shutdown. #270 also retains representative
gameplay/frame/snapshot timing, device/focus and human-feel gates.

## Trial successor correction after accepted App — 2026-10-25

App #256 is merged as main56422c05 after all four exact-dc2 required gates.
The [Trial correction record](../audits/2026-10-25-lcb003-trial-body-constructors.md#failed-full-matrix-and-unsupported-rig-correction--2026-10-25)
preserves the actual ff2 Windows/Linux failed obsolete barrel-refusal assertion,
the catalog-unsupported negative with unchanged old-owner/no-queue fences and
fresh actual E3 Windows sampled71/Trial117/default86 successful assertions.
Native80/compiled139 and runtime bytes remain exact; historical535 has seven
explicit script/test differences. Corrected-head CI/review remain required;
local proof does not close other constructors, full-host/scientific or #203
qualification. Older preparation/pending-App sections retain their source
snapshots. Further Web testing is owner-deferred until after the epic.

## Current Trial consumption of corrected App — preparation only

This Trial branch consumes exact Appdc2eee94 (sourcefix152a5074), retaining all
ten f65f3de9 Trial files and the two incoming identity-test hashes. Native80 and
compiled139 remain exact. The historical535 build set now has six changed
entries (four Trial plus two App tests), other529 exact, and six new Trial
paths give current541. The following App-only two-test/533-entry statements
retain that narrower source scope; they do not describe the combined Trial set.

The [combined-source qualification](../audits/2026-10-25-lcb003-trial-body-constructors.md#corrected-app-consumption--preparation-only--2026-10-25)
keeps actual117/86 proof at ad3 and actual corrected38/29 App cohorts separate.
This merge has no engine execution. Root's corrected #256 is ready for fresh
gates/review; #257 Trial remains draft/downstream. Earlier ea96 gate greens do
not cover either successor. Runtimes/profiles/requests stay inherited; Web deferred.

## Post-publication identity-test correction

**Current bounded test overlay, new final-head gates pending:** actual Linux
run40232042725 at ea96/checkout56bd fails only the two identity expectations
that unconditionally demand a mismatch after published02ea now matches. The
[correction evidence](../audits/2026-10-25-lcb003-runtime-publication.md#post-publication-identity-test-correction--2026-10-25)
retains both failures and fresh published-e3/development46a Windows import/
host38/owner29 passes. Correct real equality remains distinct from unverified
loaded-module/scripts and full-host=false. This is no physics/law/default
change: Native80/compiled139 stay exact, historical build535 changes exactly
two tests and no paths are added. No runtime/manifest rewrite or Native rebuild
is required. Older72-process/source5f02/a704 evidence stays scoped; #256 remains
draft for fresh final-head CI/review and #257 is downstream. Old ea96 Docs/#49
greens are not successor greens. Additional Web work remains owner-deferred.

## Consumed App publication — source5f02 and checkpoint ea96 — 2026-10-25

The [actual003 publication](../audits/2026-10-25-lcb003-runtime-publication.md#actual-sequence1-windowslinux-publication--2026-10-25) now binds source
`5f02d089ee4cff8b34421cc4ca58bb4ef50dd92c`, run40226343524 and four-path bot
`0c9b197754d57e1eb579a52d745a1ca8fd0d2b32`. Windows runtimee3f17363
(4,824,064 bytes) and Linux02ea0661 (4,222,304 bytes) each pass import plus
all35 strict host/control cases:72 actual processes total, with matched
native80/build535 input ledgers and642 policy assertions per OS. The
earlier eight App provenance comparisons describe pre-publication inputs;
the new manifests cover all80 current native inputs.

The six approval-held bot follow-ups are not validation greens. Final
exact-head CI/review, remaining constructors and complete host/scientific/
manual qualification stay open; #202 and #203 are not complete. The owner
defers additional Web/browser/shader work until after this epic. Historical
Web functional success and rendering failure are retained; no rendering
pass or fallback is claimed. All non-Web requirements remain in force.

PR #254 is now accepted on main
`06451f8ac9e8ac9b23a105d2fe22393375dc2d6b`, after its exact02c Documentation,
Native, GDExtension/Godot and #49 gates and bounded reviews passed. The
[publication ledger](../audits/2026-10-25-lcb003-runtime-publication.md#accepted-water-main-and-content-identical-integration--2026-10-25)
binds those receipts. Local normal mergea704ce50 consumes that main with the
unchanged bot0c9 tree; all615 publication inputs and139 compiled inputs remain
exact. This does not substitute Water's gates for the application's final
exact-head CI or close #202/#203.

## Integrated desktop Trial successor — 2026-10-25

This unmerged Trial successor now consumes App checkpoint
`ea96d4851621c4bed37d5e6997a0320215450f79`, including the actual source5f02/
bot0c9 publication and accepted main06451f8a. The ten Trial source files remain
exactly sourcef65f3de9; its recorded Windows executions are not relabeled as
tests of this merged head. All80 native manifest inputs and139 recorded native
build inputs still match. The original535-entry build/execution ledger has
four changed GDScript/test entries and omits six new Trial source paths; it
retains its original5f02 execution identity. Those historical build-input changes
are separate from native-source provenance, not eight native rebuild errors.
The [dated Trial integration record](../audits/2026-10-25-lcb003-trial-body-constructors.md#app-publication-integration-preparation-only--2026-10-25)
owns the exact drift and remaining fresh acceptance. No new engine test, request,
profile, runtime publication or Web work occurs in this merge.

The original separate `codex/lcb003-trial-body` worktree started from5f02d089 and added
bounded desktop barrel8×14/Ripper18×8 preparation. Its ten-file overlay leaves
native139 and the publishing final-integration branch untouched. Apply retains
exact actual server motion; Restart/F5 stage authored fresh state. One-body
epoch/mask/readiness guards and candidate-only F5 preferences preserve the old
World/graph/receipt/input on refusal. The default PF gas-capacity refusal remains.

The [dated source/runtime/failure ledger](../audits/2026-10-25-lcb003-trial-body-constructors.md) binds final
source mapb4eae1ba, developmentDLL46a, focused117/0, prior retained regressions
and Root's independently executed published-runtime117/0 at the preceding
test-leaf snapshot. This is local Windows host proof, not another platform,
scientific acceptance, all-constructor or full-host claim. No publication
request/runtime files are changed in this slice. The inherited parent request
stays unchanged across the later App merge; the old runtime/test proof keeps
its original source identity. Further Web/browser/
shader work remains owner-deferred until after the epic.

## Historical preparation and Water-artifact consumption

The earlier source-bound records below retain their original unarmed,
runtime-mismatch and pending-publication statements. They do not describe
the actual003 publication above or relabel older executions.

The application branch now normally consumes reviewed Water source/publication
checkpoint02c33341 through merge108b84d1, including actual sequence2 sourceaa8af247,
run40220697738 and bot03cccd8f. Merge1d376fb3 also consumes the separately reviewed
Web evidencec8bd9623. All139 inputs of the development DLL46a remain equal to
compiled18d/tested3d. The local164 native/39 sanitizer/import-plus35-host results
retain those source identities. Relative to the696-source executed snapshot,
691 entries stay exact; four published runtime/provenance paths and Water's
sequence2 request are explicit later exceptions, with no native or host-code
change. This is not a fresh host execution at the new merge head.

Fresh proper-companion provenance reports eight remaining App input mismatches,
four per OS: cyber_demo_bridge.hpp, cyber_native_cell_world.cpp/.hpp and
prepared_world.hpp. The published kernel clears the earlier world.cpp pair;
no mismatch is waived. The [runtime-consumption record](../audits/2026-10-25-lcb003-final-integration.md#published-water-sequence2-consumption--2026-10-25)
binds the source/artifact exceptions and six passing cheap gates.003 remains
unarmed/request absent with no push. Its source-matched Windows/Linux runtime
publication and fresh35-case execution, final exact-head gates, remaining host
constructors and scientific/feel acceptance remain required. The consumed
[Web evidence](../audits/2026-10-25-lcb003-web-common-water.md) retains77/76 functional success and the rendering failure;
minimal-palette diagnostics do not qualify full appearance or manual play.

## Qualified Water sequence2 publication — 2026-10-25

PR #254's [actual sequence2 publication](../audits/2026-10-25-water-inertial-publication.md#actual-sequence2-windowslinux-publication--2026-10-25) qualifies source
`aa8af2473a59ab92cc81dfff1dda17be0f41a46d`, run40220697738 and four-path bot
`03cccd8fd133b505c6fad7911d3cb8d528ef5f22`. Both target OSes pass15 real
processes,642 policy assertions and the strict Water-IN motion/refusal/continuation
proof. Independent artifact/source/LFS/lease/floor review
`d2da3ffd58c319347b8add077a09ea315e7b87d370e899dbc0d55df509211cfc`
has no actionable bounded finding. All18 LFS payloads match their committed
pointer hashes/sizes. Source Native tree remains the reviewed c97 pool/activity
repair; the earlier race, timeout, constructor hang and sequence1 evidence remain
preserved in the dated ledgers.

This scoped publication does not establish full final ready-head CI/review,
common-Water scientific screens, full normal host/Web/rendered/manual acceptance
or #203 completion. The five bot03 approval-held follow-ups have no jobs and are
not greens. Current defaults, protected fixtures and all117 registered campaign
classifications remain unchanged. Earlier checkpoint sections below retain their
own source/date/acceptance scope.

**Earlier source-bound application evidence, before this Water artifact merge:**

Local application preparation now normally integrates reviewed Water c97f68ec
at18d20740, then commits only the sampled-test helper extraction at3d338356.
Fresh DLL46a8b4d9, compiled18d with all139 inputs equal at tested3d, passes164
ordinary native groups, seven receipt-byte oracles and39 focused ASan/UBSan
groups. Fresh import plus all35 host cases pass:36 exit0 processes with696
source files,646 post-import project inputs and139 native inputs held. The
[packed storage/startup preparation](../audits/2026-10-25-lcb003-final-integration.md#packed-worker-storage-and-startup-local-preparation--2026-10-25)
records receiptbbbea760 and preserves the failed first matrix, old-DLL A/B
crash and exact helper-only correction. Normal merge1371a250 adds reviewed
Water documentation34e0979b without changing those compiled/executed inputs.
Earlier dd00/f34 and source4948 browser proof remain source-qualified; actual
18d browser functional checks do not clear the observed shader/black-viewport
visual failure. Final Water sequence2 bot/docs and combined publication remain
required;003 stays unarmed, with ten real C9 source/runtime blockers and no
local push or runtime/manifest commit.

The [complete local host matrix](../audits/2026-10-25-lcb003-final-integration.md#complete-local-host-matrix-and-actual-web-result)
now passes36 Windows processes on the unchanged combined DLL. Separate
[source-bound actual Web terminal execution](../audits/2026-10-25-lcb003-web-common-water.md)
passes77 compat/76 threaded checks, six common-Water arms and four mixed arms.
Ordinary rendered/manual Web play remains open. Neither clears the eight stale
desktop runtime source comparisons, final publication/exact-head CI, remaining
constructors or scientific/full-host gates;003 remains unarmed.

The unmerged [final #202 integration source](../architecture/liquid-prepared-setup-and-receipts.md#final-application-source-union)
now includes reviewed desktop native-default adoption/capacity refusal and
published Water IN. The [dated checkpoint](../audits/2026-10-25-lcb003-final-integration.md)
records fresh local native163/receipt-oracle and38 focused sanitizer results,
the exact Current default identity namespace and actual CY/IN future-source
refusal. The00335-case profile stays unarmed. Remaining constructor/host identity,
combined Windows/Linux publication, exact-head CI, actual Web/visual and common
Water scientific/feel gates remain open; this does not complete #202 or #203.

The later unmerged [synchronous supported-body Water Feel checkpoint](../audits/2026-10-25-lcb003-synchronous-water-reference-body.md)
at source45b6ed9d retains exact original y90 poses/recipe/actions/player and
actual quality in the existing private frozen transaction. Eight native
Windows processes pass656 assertions, including91 Water and73 corrected
Physics Pit checks with actual native family/variant/hash readback. Earlier
label-only arm evidence does not establish distinct-family execution. Final
native/default/Water-IN union, source-matched publication/full exact-head
gates, remaining constructors and actual Web/visual work stay open.

The subsequent unmerged [normal level-import checkpoint](../architecture/liquid-prepared-setup-and-receipts.md#explicit-ordinary-level-import-and-retained-restart)
adds explicit Exploratory next-import selection and actual menu adoption of
ordinary body-free CYSD payloads, metadata and sampled owner. Refusal retains
World/player/receipt/record; Restart reconstructs accepted input. Its [Windows
proof](../audits/2026-10-25-lcb003-level-import-host.md) reuses the verified unchanged
135-input development DLL and passes eight affected processes. Physical/Tower/
showcase imports, remaining constructors, complete host identity and final
source-matched platform/visual gates remain open; Current imports stay default.
The later sourcecccae86f explicitly refuses unsupported inherited interaction/
diagnostic-law and independent transport settings before preparation. Its73
import assertions include retired-generation/private-Baseline controls; the
earlier44/eight-process proof remains Baseline-only historical evidence.

The subsequent unmerged [desktop Water Feel reference-body slice](../architecture/liquid-prepared-setup-and-receipts.md#prepared-water-feel-reference-bodies)
stages the unchanged three reference rectangles and terrain with actual frozen
poses, retains old World/graph/receipts on refusal and proves normal unpaused
pressure reference/cached/dormant/FM feedback. Its [fresh local proof](../audits/2026-10-25-lcb003-water-reference-body.md)
also preserves the native retired-gas-label defect exposed by play and its narrow
repair. Remaining physical constructors, host-mask continuation,
complete host identity and matching publication remain open.

The #202 application branch's [combined local checkpoint](../audits/2026-10-25-lcb003-combined-host-web-prerequisite.md)
integrates exact released pressure/IN union `713ee3ab` as `871fba33` and passes
sixteen fresh Windows native/headless processes. Follow-up `3b4db1dd` adds an
explicit synchronous Web-owner apparatus (33 native prerequisite checks),
truthful build/export identity and actual Rapier PF/worker applied-feedback
parity (3589 assertions). This is bounded local qualification: complete host
identity, remaining constructors, source-matched publication/full exact-head
gates, actual compat/threaded browsers and ordinary visual walkthrough remain
open. Water IN remains unsupported; Brine IN does not meet the fourth Water
model requirement.

The [local Water main refresh](../audits/2026-10-25-water-inertial-publication.md#main-flight-lease-refresh-and-native-binary-reuse--2026-10-25)
consumes accepted main9935d569 without native or artifact changes. Its two Flight
Godot inputs have fresh published-Water import/8,284-assertion proof, while the
old491 execution ledger remains historical. The existing native-input reuse
rule permits the retained libraries; full fresh exact-head gates remain required
and that GDScript-only change did not itself require a new publication. Later
native repairs receive sequence2 above, without final #212/#203 acceptance.

## Accepted parent and qualified Water publication — 2026-10-25

**Historical sequence1 checkpoint:** the following records the accepted parent
and first Water publication, before the native repairs and sequence2 above.

Parent PR #250 accepts exactd7681a5c after all required exact-head gates and
independent review, merged as main `dc915f2b2cc1261501058d0e967a98f32ecdee9d`.
All three Water PF variants and Brine IN/reference are now accepted native main
scope; full application/Web and programme completion remain separate.

The isolated Water successor, PR #254, has [actual source-matched Windows/Linux publication](../audits/2026-10-25-water-inertial-publication.md#actual-sequence1-windowslinux-publication--2026-10-25)
at source4b588279/run40166210470, four-path botC9e52b52. Both OSes pass15 real
processes/642 policy assertions, strict original sections and the Water proof.
Independent artifact/source/LFS/lease/floor review `b15ea7cb` has no actionable
bounded finding. Normal main merge8e586b17 preserves the complete C9 tree; all18
LFS payloads are materialized. Full ready exact-head Documentation/provenance,
Native/Godot/49 and final review remain pending. Bot follow-ups marked
action_required await maintainer approval with zero jobs; they are not greens.

Common-Water FM/CY/PF/IN scientific campaigns, full normal host/Web/rendered/manual
qualification and #203 packaging stay open. Water-IN/Oil-CY/Brine-IN is a
two-family control; actual three-family contact uses Water-FM (and separately
PF)/Oil-CY/Brine-IN in one World. Current defaults, protected fixtures,117
registry classifications, old measured ledgers and historical failures remain
unchanged. Sections below retain earlier checkpoint scope where stated.


## Isolated Water IN native successor - 2026-10-25

**Current on `codex/lcb005-water-inertial`, publication qualified, final acceptance pending:**
Water/reference now executes the retained-momentum IN law with its own whole-cell
coherence/carrying adapter. Complete original-owner read3/write2 guards and
explicit actual-carrier continuation preserve two successive pickups. Shared
whole-Water refusal and setup-only normalization retain native receipts/ledger.
[Source contract](../architecture/inertial-cellular-v1.md#water-in-native-successor--2026-10-25)
and [dated native evidence](../audits/2026-10-25-water-inertial-native.md) distinguish
local proof and its later activity/storage/pool repairs from sequence2 sourceaa8af247
qualified target artifacts. C64-E8, defaults,
Brine law, IN sidecar/codec and explicit Current2/IN3 geometry remain intact.
Original162/37 native/sanitizer proof and later c97 full163/focused23 repairs retain
their distinct source scopes;124 Python groups pass. The original fresh
non-release Windows DLL passes import plus14 strict scoped Godot cases. Native
and tooling reviews have no open bounded findings. Source-matched Windows/Linux
publication and independent artifact review now pass as above. Full exact-head
gates/integrated review and common-Water scientific/host/Web qualification remain
pending. This does not close #212/#203.


## Desktop native-default owner checkpoint — 2026-10-25

Unmerged native705a2e2d and owner66bf30f8 now stage the authoritative default
recipe through exclusive worker, private sampled player and original permanent
body graph. R retains selection; F6/F7/PENV refusal/adoption is transactional.
The original default PF scene exceeds1024 initial gas compartments, so all three
pressure variants now refuse natively before replacement, preserving the healthy
World and actual attempt receipt. FM/CY actual body cohorts retain exact Water628320.
The [dated checkpoint](../audits/2026-10-25-lcb003-desktop-native-default-host.md)
records46 focused native/ASan+UBSan assertions, seven affected1078 assertions,
final86-assertion host execution, independent review and every rejected shutdown
experiment. Separate preloaded test resources remove the inner-class ownership
context; definitive upstream cause, integrated native union, final Linux/Web,
full host identity and matching runtime publication remain open.


## Native default-demo constructor — 2026-10-25

Unmerged source `afe19c2d` shares the original native ordered demo recipe with
explicit prepared compilation, retains Water/transport and restores production
reset/lifecycle semantics. Native constructor origin binds actual generation and
retires on other replacements. The [dated API proof](../audits/2026-10-25-lcb003-native-default-demo-preparation.md)
records old-DLL tuple controls, the preserved diagnostic-lifecycle failure,
its original Windows167/493/72 and independent review. The later owner/capacity
checkpoint above supersedes its pending Main/worker scope; repaired IN union
and final platforms/publication remain open.


The subsequent unmerged [normal level-import checkpoint](../architecture/liquid-prepared-setup-and-receipts.md#explicit-ordinary-level-import-and-retained-restart)
adds explicit Exploratory next-import selection and actual menu adoption of
ordinary body-free CYSD payloads, metadata and sampled owner. Refusal retains
World/player/receipt/record; Restart reconstructs accepted input. Its [Windows
proof](../audits/2026-10-25-lcb003-level-import-host.md) reuses the verified unchanged
135-input development DLL and passes eight affected processes. Physical/Tower/
showcase imports, remaining constructors, complete host identity and final
source-matched platform/visual gates remain open; Current imports stay default.
The later sourcecccae86f explicitly refuses unsupported inherited interaction/
diagnostic-law and independent transport settings before preparation. Its73
import assertions include retired-generation/private-Baseline controls; the
earlier44/eight-process proof remains Baseline-only historical evidence.

The subsequent unmerged [desktop Water Feel reference-body slice](../architecture/liquid-prepared-setup-and-receipts.md#prepared-water-feel-reference-bodies)
stages the unchanged three reference rectangles and terrain with actual frozen
poses, retains old World/graph/receipts on refusal and proves normal unpaused
pressure reference/cached/dormant/FM feedback. Its [fresh local proof](../audits/2026-10-25-lcb003-water-reference-body.md)
also preserves the native retired-gas-label defect exposed by play and its narrow
repair. Synchronous bodies, remaining constructors, host-mask continuation,
complete host identity and matching publication remain open.

The #202 application branch's [combined local checkpoint](../audits/2026-10-25-lcb003-combined-host-web-prerequisite.md)
integrates exact released pressure/IN union `713ee3ab` as `871fba33` and passes
sixteen fresh Windows native/headless processes. Follow-up `3b4db1dd` adds an
explicit synchronous Web-owner apparatus (33 native prerequisite checks),
truthful build/export identity and actual Rapier PF/worker applied-feedback
parity (3589 assertions). This is bounded local qualification: complete host
identity, remaining constructors, source-matched publication/full exact-head
gates, actual compat/threaded browsers and ordinary visual walkthrough remain
open. Water IN remains unsupported; Brine IN does not meet the fourth Water
model requirement.

## Corrected Brine IN runtime publication — 2026-10-25

Sequence3 [actual Windows/Linux publication](../audits/2026-10-25-lcb005-pressure-union-integration.md#actual-sequence3-publication-of-the-contact-repair)
passes all six jobs in run `40160900817` at exact source `c11983c2`, followed
by verified four-path bot append `fcf0e9b6`. Each OS executes import plus14
cases, including IN10192/six strict sections and the new resting-contact
regression. Fresh non-author verification checks all76/485 input blobs,
artifacts, actual OS execution and the Linux runtime floor. The corrected
runtime publication blocker was resolved at that checkpoint; later PR #250
passes all exact-head gates and merges as main dc915f2b. Prior omitted-contact and moving-mask failures below
retain their exact source scope. Water-IN, complete host/Web and #203 remain
separate.

## Brine IN body-contact blocker — 2026-10-25

Fresh independent review of `98595ac8` finds that resting Brine IN omits
body-mask contact feedback even when its material update executes. The narrow
[contact correction](../architecture/inertial-cellular-v1.md#mandatory-resting-body-contact-correction--2026-10-25)
preserves the numerical law and adds target/normal-specific shared contact
observation. LLVM154/focused sanitizer29 and fresh local Windows import plus six
selected Godot cases pass at `68f74906`. At that checkpoint PR #250 was Draft;
sequence2 runtime proof remains historical to the omitting source. Later corrected
sequence3 publication/full gates pass and #250 merges as above.
Water IN, full application/Web and owner-feel qualification remain separate.

## LCB-003 thermal level preparation — 2026-10-25

The unmerged [native CYSD preparation slice](../architecture/liquid-prepared-setup-and-receipts.md#imported-cysd-payload-preparation)
adds copied thermal tuples, actual payload identity, explicit normalization and
the existing one-use native transaction. [Local Windows evidence](../audits/2026-10-25-lcb003-thermal-level-preparation.md)
passes493 new assertions and seven retained scripts plus import. No native codec,
physics law, dependency, Current default or legacy importer changes. The later
bounded ordinary route above follows separately; physical importer/complete
host adoption and final platform qualification remain #202 ownership.

## LCB-005 native Brine checkpoint — 2026-10-24
**Current on the isolated LCB-005 branch only:** [Brine IN reference](../architecture/inertial-cellular-v1.md) selectively ports the genuine fixed-point law onto the shared quantity/prepared-state foundation, including an optional versioned native damping numerator0..16 over16(default1). [Native evidence](../audits/2026-10-24-lcb005-native-brine-checkpoint.md) qualifies its stated source/platform scope. Default behavior remains retained. The later [standalone Godot adapter](../architecture/inertial-cellular-v1.md#standalone-godot-readback-and-explicit-geometry) adds actual instance readback and explicit radius3 with [local Windows proof](../audits/2026-10-25-lcb005-standalone-adapter.md). Water IN, full application integration, source-matched runtime publication, owner feel and full #212 completion remain unqualified here. No Cell-carrier migration or generic Rapier force follows.

Later normal merge `4a594db5` integrates the reviewed moving-mask pressure
gas-label repair while retaining the IN law/damping/codec and all fourteen
scoped publisher cases. The [union repair ledger](../audits/2026-10-25-lcb005-pressure-union-integration.md#moving-mask-repair-integration-and-second-publication--2026-10-25)
separates fresh combined native proof and actual sequence2 target-OS publication
at `661a96ae`/run `40157525237`/bot `a9f1b875` from the historical `52ee560a`
runtimes. Import plus14 cases perOS pass. Final #201 head `096b7eeb` is now
integrated without changing native/build inputs or replacing IN runtimes.
Fresh full ready-PR and independent IN assessment remain required. The separately
qualified pressure body trajectory does not complete application/host, Water-IN
or Web qualification.

The later [combined #201/#212 integration](../audits/2026-10-25-lcb005-pressure-union-integration.md)
at `713ee3ab` passes fresh152-group LLVM/MSVC ordinary execution, seven full
receipt oracles per compiler, a132-input Windows DLL/import and all14 scoped
Godot cases. All PF variants coexist with Brine IN; a separate90-child
pressure cost repeat retains slower churn/fallback results. This local source
proof is separate from either parent's evidence. Later combined Windows/Linux
scoped publication `40153980594` passes actual import plus14 cases perOS at
`bc0bfed9`, followed by runtime-only bot `52ee560a`; full ready-PR CI and
host/Web/owner acceptance remain pending.

**Current on main through accepted PR #250:** [Brine IN reference](../architecture/inertial-cellular-v1.md) selectively ports the genuine fixed-point law onto the shared quantity/prepared-state foundation, including optional native damping numerator0..16 over16(default1). [Native evidence](../audits/2026-10-24-lcb005-native-brine-checkpoint.md) keeps its stated scope; the [standalone adapter](../architecture/inertial-cellular-v1.md#standalone-godot-readback-and-explicit-geometry) and [combined publication](../audits/2026-10-25-lcb005-pressure-union-integration.md#actual-windowslinux-union-publication--2026-10-25) record later actual instance/radius/platform proof. Defaults remain unchanged. The isolated Water successor has qualified native and source-matched runtime proof; its final ready-PR, scientific/full-application, owner-feel and full #212 completion remain unqualified. No Cell-carrier migration or generic Rapier force follows.

## Moving-body pressure gas blocker — 2026-10-25
Ordinary Main/worker reference-body Water play exposed a native retired gas
label beneath a moving body mask around completed tick45–47. The World
quarantines even though Water quantity and the gas ledger remain exact.
A compact native control reproduces the failure in all three pressure
variants with configured1/4 workers. The repair is under qualification;
PRs #253 and #250 are draft and must receive fresh source-matched
Windows/Linux runtimes and exact-head gates before merging. Earlier
scoped/full greens retain their original source and coverage. See the
[dated failure and repair record](../audits/2026-10-25-pressure-moving-mask-gas-retirement.md).

Ordinary moving reference bodies exposed retired gas labels beneath masks;
the failing World quarantines despite closing Water/gas ledgers. Repair commit
`7ebcd0e9` adds the six-arm native regression and retains still-live identities.
Local LLVM/MSVC141, focused sanitizer16 and actual application body tests pass.
Fresh #201 Windows/Linux scoped publication `40157133977` passes at source
`eebd0c98`, with four-path bot append `65f1f3b5`. The updated90-child total-cost
campaign also passes exact parity and preserves slower churn/fallback results.
At that finding PRs #253/#250 returned to draft. Their later source-matched
exact-head gates and independent review pass; accepted main merges are66051129
anddc915f2b respectively. Earlier
greens retain their original scope. See the
[dated failure and repair record](../audits/2026-10-25-pressure-moving-mask-gas-retirement.md).

## Physical actor regression hangs — 2026-10-23

**Current qualified desktop repair, 2026-10-24:** #234 adopts
[PR #236](https://github.com/techrote/cybersand/pull/236)'s cooperative deferred-BVH
join repair and exact qualified Windows/Linux x86_64 artifacts on current main.
Other architectures/Web retain release libraries. The
[stack and paired evidence](../audits/2026-10-24-physical-actor-bvh-validation.md)
confirms the deferred receive/outer latch blocking path; the exact scheduler race
remains unproven. Same-host run 40056501226 qualified 300 candidate trials with
zero timeouts while retaining six Windows control timeouts.

The [#234 integration ledger](../audits/2026-10-24-issue-234-physical-hang-repair.md)
separates that prior comparison from the integrated PR #236 head
`330ded5aa0937b4a46ea0b5f270583a8e0375931`, which passed exact-head ordinary
gates and merged as `13b8e631f3e8fbaa2176ed41afc02c434b11e558`. Fresh standard
600-attempt serial/parallel campaign `40129364630` at that source completed
600/600 physical passes, 0/600 timeouts, zero other failures and twenty passing
imports, with 50/50 passes in every OS/mode/test stratum. This qualifies the
registered Windows/Linux x86_64 workload and exact artifacts; native-worker
count was not varied and other loads/platforms remain outside that result. The
[build guide](../operations/local-build-and-validation.md#physical-actor-timeout-investigation)
owns invocation; the [timeout procedure](../operations/testing-validation-and-replay.md#physical-regression-timeout-diagnostics)
owns the independent 30s capture / 45s idle failure guard, fixture-only 120s
observer and unchanged 180s outer limit. No retries, skips, physics/worker-count
changes or broad scheduler-fix claim follow from the selected backport.

## 4LY shared physical free-flight — 2026-10-22

**Current experimental source, 4LY-001 / #205:** the
[free-flight contract](../systems/physical-free-flight.md) adds a shared single
rectangular Rapier chassis, validated versioned profile schema and two-output
desired-velocity controller. Gravity compensation, response/slew and braking
share finite thrust authority; attitude assistance has its own bounded torque.
The stabilizer has no goal, terrain or evaluator input. Authorized neutral
brakes/hovers; cancellation and expiry select explicit passive fallback.

The four stable `4ly_*` IDs retain one actual collider each with no automatic
equipment body. **4LY-002 candidate implementation (#206)** adds distinct
Trainer/Hauler/Drifter/Dart mass/footprint, speed, brake, response, thrust and
drag profiles. Ordinary F5 selection now appends a named `set4LY` after the
original eight sets: the existing 46 actor IDs and SetP positions are untouched.
The same human/script/policy owner and two-axis actuator path is reused, with
visible assistance/identity and actual-Rapier handling tests. On tested source
`f7721a1...` the [measured handling record](../audits/2026-10-23-4ly002-measured-handling-qualification.md)
shows all prospective manoeuvre thresholds passed on GitHub-hosted Linux
and Windows, as well as full Godot/Native and documentation/provenance checks.
The original failed Windows attempt was retained; its 121/121-case rerun passed.
The source field remains `candidate_4ly002` to preserve these measured hashes;
final revised-head validation, descriptive gameplay footage and human owner-feel
approval remain separate. Learning or unmeasured Web/target-PC qualification
must not be inferred from these measurements.

4LY-002 [#206](https://github.com/techrote/cybersand/issues/206) now has
passing source-bound physical manoeuvre envelopes and profile hashes, but
owner-feel and final changed-head reconciliation are still not accepted.
The [4LY-003 flight-lab implementation](../systems/physical-flight-lab.md)
adds native/Rapier gameplay/headless episodes, 54-channel observations and
a frozen scripted teacher. Its [physical final-score audit](../audits/2026-10-24-4ly003-final-qualification.md)
reports 224 source-bound traces, 157/160 scored navigations/recoveries,
all per-profile family gates met and zero authority/physics faults.
The [earlier implementation ledger](../audits/2026-10-23-4ly003-checkpoint.md)
remains historical. [4LY-003 #207](https://github.com/techrote/cybersand/issues/207)
still requires distinct external suite custody/reviewer admission before
claiming fully independent qualification; its tested host and frozen
4LY-002 profiles cannot be silently generalized. Companion 4LY-004/005 own Trainer-first and family learning,
with a passing Trainer result required before family learning. Parent #132 and
generic physical/Jolt/morphology gates remain separate.

## GEN-007 authoring and qualification — 2026-10-21

**Current implementation with scoped qualification:** [Generation Workbench 2](../systems/generation-workbench-2.md) adds native provenance replay and true stages, transactional visual authoring, graph/hierarchy/plane diagnostics, undo/redo and bounded seed/recipe comparison. The [procedural qualification scene](../operations/procedural-qualification.md) supplies one compact 1024 × 1024 four-plane map: four declared seeds pass final-raster structural and equivalence checks, eight paired-plane native exhibits pass mechanism controls, and retained display captures receive a qualified visual pass for approaching Deepworks. Broad negative spaces, repeated service cabinets and less varied fine machinery remain explicit. Source-matched Linux and Windows publication passed; the [dated ledger](../audits/2026-10-21-gen007-workbench-qualification.md) retains source/runtime identities, the revised 4 GiB graphical envelope and observed authoring hitches. [PR #198](https://github.com/techrote/cybersand/pull/198) records final exact-head repository acceptance and merge verification. GEN-006 remains the subsequent streaming/persistence owner.

## Player control playground — 2026-10-20

**Current experimental source:** the [player playground](../systems/player-control-playground.md)
adds seven human movement presets and a dedicated course. Five mechanical
presets form F5 SetP, bringing the physical catalogue to 46 rigs across eight
sets; dry Sand and liquid Water remain separate native material-field modes.
Acrobat chains, sprung vehicles, damped lander flight and strong barrel torque
use the shared leased physical owner. Circular wheels keep conservative square
native material masks. The material lane relocates bounded local native cells
without repainting or changing Water kernels.

The [original evidence](../audits/2026-10-20-player-control-playground.md) preserves
local Linux execution and desktop builds. The
[PR #189 completion record](../audits/2026-10-21-player-playground-pr189-completion.md)
records original-head hosted success, including actual Windows headless
execution of 107/107 applicable cases. Integration with GEN-003 main and the
quick-tap course-clock correction require combined-source runtimes and fresh
final-head gates. That record owns their status and routes exact final-head
outcomes to PR #189's description and Checks. Physical gamepad/window
interaction, target-PC human feel, complete timed routes and new browser
execution remain separate qualifications. Generic granular, soliding and Water
successor work retains its own gates.

## Exploratory actor integration and physical migration — 2026-10-18

**Current experimental desktop source, ACT-004:** F5 selects all 29 existing
actor identities as articulated Rapier rigs, plus twelve SetX mechanisms, with
keyboard, scripted-demo and external-policy producers. Physical is the default
actor route; sampled references remain explicit choices. Applying restores the
selected map and R retains the actor. Controlled apparatus and Benchmark mode
remain protected. See the [physical actor contract](../systems/physical-actor-rigs.md)
and [programme](../operations/physical-actor-programme.md).

The shared owner provides bounded rotary/slide/spring mechanics, gyro assistance,
compliant play, part-matched polygons, mounts/recoil and held-part lifecycle.
The native coupling budget is 64 body IDs. Physical Thunderbowl v2 is a separate
owner from the retained sampled v1 experiment. Learned policies, global planning,
Windows/browser feel qualification and broad granular acceptance remain outside
this implementation result.

## Is the foundation ready to extend?

**Current documentation is organized for foundational work; the simulation has
known correctness and policy gaps.** The [source checkpoint](../operations/source-checkpoint-and-recovery.md)
secures existing work locally. Resolve the relevant issues below before building
new physics on assumptions that the current implementation does not guarantee.
The [validation ledger](validation-evidence.md) separates dated runtime results
from inspected code. No documentation status is a blanket platform acceptance.

## Recovery / current CI checkpoint — 2026-09-24

The [final recovery audit](../audits/2026-09-24-cybersand-recovery-audit.md)
closes the 2026-09-20 through 2026-09-22 CI / Stage-3B recovery programme.
The inspected pre-REC-008 main is
`0405cdfe35a855e8287215a71d1165e3107fd1d6`.

Routine active CI is GitHub-hosted and machine-checkably rejects obsolete
Avrea/Sengi/CircleCI routing, self-hosted/custom runner labels and
`*_RUNNER` indirection. #65 is merged and fully verified; Stage-3B's next
dependency-ready package is **#66**, followed by #67, #68 and #70. Stage 4 remains
blocked. PR #105/#94 is recovered but remains draft research pending its separate
disposition.

Remote `main` remains unprotected with no repository ruleset. The owner-side
minimal protection action is explicitly documented; do not report it as installed.

## Development-claims remediation checkpoint — 2026-09-20

The [canonical remediation programme](../operations/development-claims-remediation-programme.md)
governs F01-F19 and issues #79-#87. It separates Implemented, Integrated, Verified,
Accepted and Dispositioned instead of using issue closure as a proxy for all five.

Current tracker truth is deliberately conservative: #8 remains open; #9 retains
its scoped characterization; #10 retains its bounded policy/fixture evidence but
broad player/granular acceptance is open under #82; #11 retains its bounded
historical repair evidence but that repair is absent from audited current main,
so #81 owns integration and #83 owns later broad body/granular acceptance. #12 is
an independent scalable-soliding programme, not the sole remaining reason for #8.

#10/#11 are evidence/objective anchors, not duplicate implementation lanes.
Historical completion records remain immutable.

## Current implementation map

**Layered exhibition source, 2026-10-20:**
[Deepworks](../operations/deepworks-exhibition.md) adds one 1024 × 1024
composition with sixteen districts, 32 foreground/rear native exhibits and all
51 MAT-002 building materials. Four independent full-size worlds run at
30/20/15/0 Hz; the true distant background is frozen. Finite reaction sources
preserve products, while the camera/painting viewer supports whole-map reset,
apparatus focus and a guided tour. It does not install an ordinary actor session.
The shared [depth APIs](../systems/depth-layers-and-parallax.md) now admit each
axis from 8 through 1024, including non-square worlds, while preserving Strata
Theatre's 640 × 360 default. Native ABI and material rules are unchanged.
Runtime and actual rendered acceptance remain separately scoped by the
[dated exhibition audit](../audits/2026-10-20-deepworks-exhibition.md).

**Connected scene content, 2026-10-18:**
[Blacksite Nine](../operations/blacksite-nine-demo.md) composes nine 320 × 320
districts into one 960 × 960 native region: a surface laboratory between two
wastelands, above six dense underground industrial districts. Twelve reciprocal
ports and a common final passage carve connect the whole map. Shift+F11 and the
Web demo menu install the complex; the 3×3 map, atlas and following views change
only the camera, while R resets all nine districts together. Its fixed interest
region and world-coordinate presentation preserve continuity without introducing
a streaming subsystem. The [dated scene audit](../audits/2026-10-18-blacksite-nine.md)
owns recipe, runtime and visual evidence; physics programmes retain their gates.

**Scene content, 2026-10-18:** [Neon Reliquary](../operations/neon-reliquary-demo.md)
adds an ornate machine-cathedral demo and the three tiles beneath it: Middle
Cyberberbia, Sewertech Alley and Industrial Underswamp. They use the shared native
MicroScenario host, with desktop/Web entry points, five views per tile, Above/Below
navigation and themed distant scenery. District changes load original layouts.
It is an aesthetic showcase; existing physics programmes retain their own gates.

| Area | Implemented scope and canonical contract |
|---|---|
| Cellular authority and platform owners | Native World; asynchronous desktop GDScript owner, synchronous Web callbacks with optional internal pool; [threading](../architecture/simulation-tick-and-threading.md) |
| Scheduler and storage | Sparse chunks, phased in-place jobs, explicit capacities and activity sleep; [chunk/tile model](../architecture/chunk-tile-and-buffer-model.md), [storage](../systems/world-storage-and-interest-region.md) |
| Procedural generation candidates | Opt-in Strata, Flow Network and District Grammar; theme/brush/override/module recipes plus bounded scalar fields, masked context guidance and aggregate materials; copied chunk proposals and explicit fresh-chunk admission; [generation contract](../systems/procedural-world-generation.md), [field/modifier contract](../systems/procedural-generation-fields-and-modifiers.md) |
| Materials | Bounded adapted kernels, mass-conserving native Water, discrete fallback, secondary interaction lanes; 51 MAT-002 building materials (IDs 81–131) with combustion and 42 versioned pair reactions; [materials](../systems/materials-and-rule-kernels.md), [building catalogue](../systems/building-material-catalogue.md), [Water](../systems/water-design.md). Source/runtime publication and completed-test scope are recorded in the [MAT-002 review](../audits/2026-10-19-mat002-review-and-validation.md). |
| Field storage and events | Optional temperature storage and bounded explosions; no general heat/pressure/wind solver; [field roadmap](../systems/smoke-heat-pressure-roadmap.md) |
| Bodies and character | Main-thread Rapier, 64-ID rectangular native coupling, static terrain packets, 46 articulated [physical actors](../systems/physical-actor-rigs.md), shared keyboard/demo/policy control and usables; SetP circles retain conservative square native masks; sampled and single-hull references remain available |
| Human movement playground | Seven [player presets](../systems/player-control-playground.md), keyboard/gamepad sampler, acrobat chains and separate leased native Sand/Water fields; course checkpoints and focused tests are not human feel or route-completion acceptance |
| Assisted physical free flight | Internal [4LY single-chassis family](../systems/physical-free-flight.md), strict two-output velocity profile, bounded goal-blind assistance and passive revocation; initial Trainer conformance numbers only, with normal selection and differentiated handling owned by 4LY-002 |
| Actor control and battle experiments | Separate physical Thunderbowl v2 plus retained sampled [Thunderbowl v1](../systems/thunderbowl-control-reference.md); physical wire control does not silently inherit sampled metal/NCA/message semantics; trained policies and general actor damage remain Planned |
| Rendering | Immutable native snapshots, chunk-run RG8 copy candidate with unchanged dirty/ACK policy, full finite GPU texture update and derived material appearance; [bridges](../architecture/rendering-and-gameplay-bridges.md), [current-main qualification](../audits/2026-11-01-render-copy-production-reconciliation.md) |
| Persistence | Fixed CYSD1 demo levels; complete resumed replay absent; [save contract](level-saves-and-replay.md) |
| Runtime availability | All 18 required LFS payloads materialized; current execution scope is platform-specific; [build](../operations/local-build-and-validation.md) and [evidence](validation-evidence.md) |

## Procedural generation candidate checkpoint — 2026-10-18

**Current source, GEN-001 / [#163](https://github.com/techrote/cybersand/issues/163):**
three deterministic native candidates share hierarchical theme selections,
weighted blends, spatial brushstrokes, guide paths, fine parameters, hard
overrides and a registry of prepared structure modules. Flow Network and
District Grammar reserve a shared macro route skeleton across independently
requested chunks; explicit hard material overrides can block those routes.
The [canonical generation contract](../systems/procedural-world-generation.md)
owns exact precedence, bounds, identity and module responsibilities.

The opt-in Godot workbench generates and caches copied material previews. Native
`World::install_generated_chunk` supplies a separate exclusive-owner primitive
that accepts only absent storage chunks. A production caller must still bind
results to its current World/reset session before admission. General world
loading, resident-chunk eviction and modified-world persistence remain
**Deferred/Planned in their existing scope**. This source checkpoint does not
claim a merged release or platform acceptance; use the
[dated GEN-001 evidence](../audits/2026-10-18-gen001-procedural-generation.md).

## Procedural fields and aggregate checkpoint — 2026-10-18

**Current source, GEN-002 / [#171](https://github.com/techrote/cybersand/issues/171):**
named fields add finite Hilbert/Morton ranks, structured noise, analytic masks,
scalar sidechains and immutable initial-material/surface/route context. Masked
modifiers guide themes/parameters or carve/paint ordinary materials and aggregate
mixtures; registered feature instances accept the same application/exclusion
controls. The workbench edits these recipes and previews paced diagnostic masks.
The [field/modifier contract](../systems/procedural-generation-fields-and-modifiers.md)
owns finite-curve scope, fixed context, hard/exclusion authority and budgets.

These are generation controls. They do not add live World sculpting, new material
physics, optional simulation field storage or inter-tile Hilbert connectivity.
Schema remains 1 and generator algorithm identity advances to 2; retained legacy
material hashes cover the three old candidates without the new controls. Exact
source/runtime results and remaining publication/platform gates belong to the
[GEN-002 evidence](../audits/2026-10-18-gen002-fields-and-aggregates.md), independently
of the older GEN-001 checkpoint.

## Typed spatial generation checkpoint — 2026-10-20

**Current source implementation, GEN-003 / [#190](https://github.com/techrote/cybersand/issues/190):**
explicit schema 2 adds signed scalar/distance, vector, exact category and boolean
fields; affine/polar/repeat/warp resampling; analytical finite-difference
derivatives; ternary Peano and bounded Voronoi/Delaunay/Poisson controls; immutable
route/feature geometry; a bounded finite adjacency solver; reusable typed
subgraphs; and absolute-world multiresolution sampling with caller-owned cache.
The [typed contract](../systems/procedural-typed-spatial-fields.md) and
[operator inventory](procedural-spatial-operators.md) own types, units, numerical
qualifications and declared costs. Schema 1 retains generator algorithm 2;
schema 2 uses generator algorithm 3/spatial algorithm 1. Source/runtime execution
and completion remain distinct gates.

The Workbench offers minimal typed JSON authoring, catalogue metadata, raw typed
inspection and executable profiles. This is the native field/interface stage,
not completion of hierarchical places or runtime streaming. The approved order
continues with [GEN-004 #191](https://github.com/techrote/cybersand/issues/191),
[GEN-005 #192](https://github.com/techrote/cybersand/issues/192),
[GEN-007 #193](https://github.com/techrote/cybersand/issues/193), then
[GEN-006 #194](https://github.com/techrote/cybersand/issues/194). GEN-004 reuses
the immutable geometry/assignment interfaces and the existing bounded solver.

## Hierarchical places checkpoint — 2026-10-21

**Current source implementation, GEN-004 / [#191](https://github.com/techrote/cybersand/issues/191):**
schema 3 adds a finite canonical regional hierarchy with stable rule/slot IDs,
bounded candidate placement, exact multiplicities and occupancy ranges,
support/neighbor/family requirements, matched sockets, shared boundary ports,
explicit loops/service trunks and finite-curve structural tours. Geometry exports
feed GEN-003 typed fields; the shared finite assignment solver owns district
categories. The existing candidates/modules/masks/aggregates rasterize the
semantic plan and preserve final hard material authority.

The [hierarchy contract](../systems/procedural-hierarchical-generation.md) and
[ADR-013](../decisions/ADR-013-canonical-semantic-generation.md) own semantics and
ownership. The executable four-district profile contains cross-chunk foundries,
rooms, apparatus and nested detail. Copied inspection exposes semantic ancestry,
constraints, field inputs and material contributions. Final raster route reports
qualify an explicit floating-square clearance profile; they do not establish
actor/controller or gravity traversal. Source/runtime acceptance is separately
recorded in the [GEN-004 audit](../audits/2026-10-21-gen004-hierarchical-generation.md).

This stage adds no persistent resident-world streaming, automatic player-edit
reconciliation or semantic depth projection. The next programme stages remain
GEN-005 → GEN-007 → GEN-006, subject to this issue's explicit acceptance gates.

## Semantic depth checkpoint — 2026-10-21

**Current source implementation, GEN-005 / [#192](https://github.com/techrote/cybersand/issues/192):**
[one semantic hierarchy projects into four planes](../systems/procedural-semantic-planes.md)
with explicit geometry, per-plane material intent and omissions, six typed link
families, finite source/drain/setup fixtures, copied provenance and optional
play-only actor placements. Native output is private until complete; the existing
depth owner stages all four Worlds and existing sampled actor owner before one
configuration commit. Camera/parallax never enters generation.

The two executable [refinery/cavern examples](../operations/semantic-depth-authoring.md)
cover four canonical regions and multiple negative-coordinate chunks. Runtime
authority is limited to existing play-to-rear blast and rear-to-effects burst;
background remains frozen. Identical bundle retries are idempotent and old
observations/revisions cannot replay into a new generation. Native reaction
controls measure actual transport/products and complete fixture application counts.

The [dated evidence](../audits/2026-10-21-gen005-semantic-planes.md) and
implementation PR separately record final native/sanitized, Godot/rendered,
Linux/Windows runtime publication and hosted acceptance. Pending gates do not
count as passes. GEN-007 #193 is the next authoring/quality stage after acceptance;
GEN-006 #194 retains persistent streaming and durable mutation reconciliation.

## Decisions and defects to resolve

**Current, 2026-10-24:** #233's diagnostic deliverable is complete. The admitted
[timeout apparatus](../operations/testing-validation-and-replay.md#physical-regression-timeout-diagnostics)
and completed source-bound campaign confirmed intermittent physical-roster stalls;
the [dated evidence](../audits/2026-10-24-issue-233-physical-regression-timeouts.md)
owns distributions, captured process/thread state and causal limits. The new
campaign reproduced Windows timeouts, while retained historical evidence includes
both Windows and Linux. That campaign captured no native stack; its causal limit
remains historical fact. The separate PR #236 lane supplies matching native-stack
attribution and a qualified cooperative-join comparison. The
[#234 repair](../audits/2026-10-24-issue-234-physical-hang-repair.md)
adopts that repair and bounded guards. Its integrated PR passed exact-head
ordinary gates and merged; standard qualification run `40129364630` completed
600/600 physical passes, zero timeouts/other failures and twenty passing imports
at immutable source `13b8e631f3e8fbaa2176ed41afc02c434b11e558`.
The audit and [#234](https://github.com/techrote/cybersand/issues/234) /
[#232](https://github.com/techrote/cybersand/issues/232) own the actual disposition.

Rows distinguish **Current fixes**, remaining defects and open decisions; dated
evidence defines each fix's platform acceptance.

| ID | Precise uncertainty or contradiction | Next bounded check/decision |
|---|---|---|
| F01 — failed ticks | Current fix: latch failed World, distinguish attempted/completed ticks, suppress partial publication, stop desktop/Web owners; explicit reset/validated replacement, no replay/rollback | Windows/native acceptance and browser limits: [issue #1 evidence](../audits/2026-09-08-issue-1-failed-ticks.md); [tick contract](../architecture/simulation-tick-and-threading.md) |
| F02 — region re-entry | Current fix: phased exclusion retains activity/quiet state; new core coverage wakes resident blocks once without catch-up. Serial still ignores the region | Separate and combined acceptance: [issue #2 evidence](../audits/2026-09-08-issue-2-interest-regions.md); [storage](../systems/world-storage-and-interest-region.md). Future field/streaming semantics remain open |
| F03 — tick ownership | Desktop moves character before cells with async Rapier samples; Web moves character after cells and gates on terrain backlog | Decide which ordering differences are acceptable before a common physics/replay contract; [threading](../architecture/simulation-tick-and-threading.md). 2026-11-06: default-off desktop lockstep fence measured bit-identical same-host repeats; the owner chose it as an opt-in desktop mode (`--lockstep-coupling`), with asynchronous pacing kept as the default; [feasibility audit](../audits/2026-11-06-coupling-lockstep-feasibility.md) |
| F04 — delayed rules and sleep | Current MAT-001 fix retains future compact-pair and Ice reaction opportunities across sleep and wakes the center block on body-mask changes; other specialized waiting paths remain material-specific | [Scoped #158 evidence](../audits/2026-10-18-mat001-material-reaction-progress.md), [materials](../systems/materials-and-rule-kernels.md); characterize further lifecycle/feel changes separately rather than claiming every material is accepted |
| F05 — replay and fidelity | Current hashes omit some future-affecting state; CYSD1 omits more; no selectable strict runtime policy | Specify complete input/configuration identity, fidelity policy and replay schema before promising continuation; [determinism](../architecture/determinism-and-boundary-transfers.md). Coupled same-host repeatability needs the opt-in lockstep mode; input capture and a replay schema are still missing, and cross-platform identity is not established ([2026-11-06](../architecture/determinism-and-boundary-transfers.md#coupled-desktop-determinism--2026-11-06)) |
| F06 — bounded operations | Native lazy allocation and partial failure coexist with Approved prepared/no-allocation goals; desktop input Array is unbounded | Define command backpressure, setup/reconfiguration and allocation accounting; [capacity](../operations/configuration-and-capacity-budgets.md) |
| F07 — body physics scope | Rectangle proof does not settle general shapes, sweep/CCD, force/torque units, sample-age policy or particle overflow | Name units and fixture tolerances, extend one bounded coupling case at a time; [coupling](../architecture/rigid-body-and-cellular-coupling.md) |
| F08 — build/release identity | CI 4.0.11 versus builder 4.0.20; missing native binding argument; compile-only skips runtime; historical template lock and base-only export identity | Current/M11 gate separation is implemented; remaining Web work stays in issue #3. [CI contradictions](../operations/github-development-and-release.md#unresolved-ci-contradictions) |

## Approved, Planned, Deferred and Rejected work

**Approved:** native authority, exclusive ownership, immutable handoff, explicit
capacity outcomes, exact fixture comparison, bounded visible approximation, and
replaceable Rapier behind engine interfaces. Some requirements remain only partially
enforced; [invariants](invariants.md) identifies that gap.

**Planned:** generalized bounded command/result queues; safe live reconfiguration;
general world/configuration/replay persistence; field equations and units; production
body-shape/CCD/force policy; GPU subregion writes; authored appearance schema/tooling;
a user-facing material-presentation quality tier with weaker-GPU and browser cost
measurement ([effects register](material-effects-register.md#planned));
remaining platform/LeakSanitizer and production performance acceptance. Current
Linux native ASan/UBSan/TSan results are in the validation ledger.

**Deferred:** asynchronous Web simulation/render ownership, general streamed
world loading/eviction, and GPU/coarse/hex experiments. Opt-in procedural chunk
generation now has the bounded candidate scope described above; it does not
supply a resident-world streaming manager. Active-only buffering is a **Planned candidate**
whose implementation/comparison is **Deferred** until a field or benchmark
justifies it. The reserved buffered enum does not run.

**Rejected within the current architecture:** erase/restore bodies into authoritative
cells, mutable rendering reads, native workers calling Godot, per-cell locks/physics
objects, per-material threads and automatic use of GPU visuals as simulation authority.
See [principles](../architecture/principles-and-non-goals.md) and the [ADRs](../decisions).

## Next implementation checkpoints

**Current:** the [issue #9 measured baseline](../audits/2026-09-09-physics-characterisation.md)
and [reproducible tooling](../operations/physics-characterisation.md) retain the
scoped characterization. Issue #10's
[versioned player and exchange policy](../systems/granular-interaction-policy.md)
is implemented and its dated fixture evidence remains valid, but later owner
gameplay evaluation did not accept the broader player/granular objective; #82 owns
that remediation.

Issue #11's historical repair checkpoint remains bounded evidence, and REM-002
has now established why it disappeared from project truth: the repair branch was
**never integrated into main**, rather than later merged and regressed. Current
source reconciles the still-valid generic masked-source, barrier/foreign-mask
ejection and bounded granular-bearing semantics, with source-matched retained
runtimes and a focused recurrence regression. See the
[REM-002 forensic/current evidence](../audits/2026-09-24-rem002-issue11-integration-forensics.md).

This does not convert the historical result into broad acceptance. The owner
clarification still treats the barrel as a generic Rapier reference body and does
not accept the historical ordinary envelope as finished body physics. **#83 /
REM-004 is now the body↔granular acceptance owner after REM-002**. Raising impulse
caps alone remains an invalid substitute. The
[remediation programme](../operations/development-claims-remediation-programme.md)
owns these claim-state distinctions; #12 remains independently active.

1. Preserve the implemented F01 quarantine and F02 pause/re-entry contracts and
   their combined regressions; extend the documented platform/failure-site gaps
   before broader production acceptance. Do not fold in a new solver or backend.
2. Freeze ordering, units, approximation and replay-input contracts needed by the
   first physics increment; record unresolved choices rather than guessing.
3. Extend one bounded physical behavior, validate conservation/ownership/capacity
   and affected platforms, then apply the [documentation checklist](../operations/documentation-maintenance.md).

CI/provenance repair can be a separate bounded prerequisite for release-quality
builds. The earlier M11 checkpoint sequence and reported rollback archives remain
[historical records](../audits/pre-rag-rewrite-2026-09-08/README.md), not newly verified recovery points.

## Issue #10 player and exchange checkpoint

**Current implementation, bounded acceptance:** Material-aware player support,
separate side resistance, bounded enclosure recovery, powder-pair exclusion and
scheduled Mercury permeability are implemented. The
[dated evidence](../audits/2026-09-09-issue-10-granular-policy.md) records parameter
screening, native/fallback/desktop/Web execution and remaining publication/platform
limits. Those results are retained, but they do not constitute the later owner
gameplay acceptance that #82 must obtain or explicitly disposition. Body/granular
integration/acceptance is separately #81/#83.

## PCHAR-001 player representation checkpoint

**Current experiment:** issue #137 under parent #132 introduces a fresh-reset
choice between the historical sampled character and a barrel/Rapier player using
the existing body-0 rectangle. The sampled baseline now measures its bounded
upward-first runtime enclosure recovery; an optional sampled-burial-safe mode
retains explicit invalid-spawn repair while refusing runtime actor reordering.

The barrel candidate keeps native cells as material authority and main-thread
Rapier as body authority. Horizontal movement is a bounded additive impulse after
cellular reaction, with no vertical velocity assignment and no generic
body↔granular semantic change. #83 remains the production body-envelope owner and
#132 remains open for later representation experiments and selection.

## PENV-001 player/environment tuning checkpoint

**Current implementation candidate:** sampled-player gravity, terminal speed,
effective mass, jetpack acceleration/rise limit, granular/liquid response identity
and step/knee/clamber traversal are explicit versioned profile inputs. The
exact-current preset reproduces the pre-PENV values and one-pixel step envelope;
an Earth-feel owner-tuning candidate doubles gravity only.

Profile changes pause and use the current fresh-reset owner boundary. After
PCHAR-001 merged as `5e53178ba083a0ccd10933cd404395fdbd7dc2b3`,
ordinary barrel/sample selection and sampled burial-safe recovery remain intact.
Tower, Water and ordinary registered MicroScenarios still force PCHAR's
sampled-baseline identity; PLAY-VAL-001 / #139 adds only three explicitly named
experimental REM-003 arms for matched sampled-baseline, sampled-burial-safe and
barrel/Rapier owner review. The desktop exposes active values and REC-001 retains
the resolved profile with exact render-generation evidence.

Granular response reuses the existing REM-003 C1 hook with separate mass and
sensitivity multipliers. Liquid sensitivity is inspectable/captured only; Water
and generic-body semantics are unchanged. Parent #133 remains the long-lived
programme for later environment/player tuning after finite child #138.

## Provisional actor control checkpoint — 2026-10-18

**Current sampled reference implementation, experimental:** ACT-002 / #168 expands the original
ACT-001 trio into 29 [actor rigs](../systems/actor-rigs.md) across SetA/B/F/Y/U/V.
SetA preserves Runner, Skimmer and Crawler plus their original two-button motor
and 16-value observations. The new rigs add independent aim, effort, trim, reel
and auxiliary input, with additive 40-value observations and consumed action/edge
readback. Human, scripted and external-policy producers share admission and motor
capabilities. The canonical rig contract owns each rig's control map and limits.

The experiments include nimble ground traversal, a broad three-legged lunging
robot, tracked/hover/drilling machines, unusual flight/descent, adhesion, ropes,
bounded recoil and six salvage-tool designs. SetV's seven named interface personas
are explicitly fictional designs, not real model preference or capability claims.
F5 compares the selected set through a fresh ordinary-world reset.

New-rig sampled rectangles have bounded conservative rotation/resize queries and
selected local tool effects through existing native cell writes. They do not
replace PENV profiles, select PCHAR's final representation, add articulated rigid
bodies or change generic Rapier/Water authority. Runtime enclosure immobilizes
the rig rather than invoking sampled-baseline runtime relocation.

Neural-network inference/training, larger NPC populations and target-PC
performance/feel acceptance remain future work. A shared command seam or
hand-authored demonstration policy is not evidence of a trained controller.
Registered scientific/control fixtures retain their existing actor identities.
Use the [validation ledger](validation-evidence.md) for scoped execution evidence;
the preserved ACT-001 audit does not automatically validate the additional rigs.

## Physical actor usable checkpoint — 2026-10-19

**Current experimental source, USABLE-002 / ACT-005 / #182:** the
[32-entry equipment catalogue](../systems/actor-usables.md) is reconciled with
ACT-004's physical owner: 12 tools, 10 swept ballistic payloads and 10 processors
retain their U01-U32 identities. Physical loadouts and demonstration strategies
are defined for all 41 actors. The retained sampled equipment route remains a
separate compatibility path.

The physical session binds one actual chassis to an owning part/grip, aims
through configured physical joints, applies matching admitted recoil, and
releases/recovers the same body. The worker receives copied physical source and
part-occupancy information; controllers cannot mutate cells, resources or body
transforms. Equipment epochs, actor control generations, pending-request identity
and issued-observation leases fence stale actions and results. Fixed processors
start from a dropped/settled body and preflight input/output conditions; pickup
and retooling cannot replenish their retained stock history.

The [ACT-005 audit](../audits/2026-10-19-act005-physical-usables.md) owns ongoing
implementation checkpoints, source/runtime identities, recorded failures, actual
regressions and merge status. Current source is not a claim that exact-head hosted
acceptance or owner feel evaluation has already passed. Existing ACT-004,
native/sanitizer, Godot/GDExtension and provenance gates remain applicable.

Committed projectiles and admitted processors outlive a released input, freeze
with simulation pause and clear on fresh actor/World reset. Sampled gameplay
recording retains its equipment state at actor-sample and material-generation
boundaries; this does not establish complete resumed equipment replay.
Health/damage, general inventory/economy, exact chemistry/heat/momentum accounting,
learned policies and Windows/browser interactive qualification remain separate.

## Issue #13 experiment checkpoint

**Current:** shared five-floor Experiment Tower, frozen pre-change references,
validated editable profiles, optional motion-driven transport and measured
horizontal sampling. Desktop and both native Web profiles execute the lab.
[Issue #13 evidence](../audits/2026-09-09-issue-13-transport.md) distinguishes
regression results, measured transport changes, visual observations and remaining
owner feel/performance limits. Baseline remains the gameplay default. Chemistry
retuning, barrel #11 and soliding #12 remain separate.

The Tower is also the Current base for #19's Water Feel Lab extension. #13's
existing evidence and recipes remain unchanged historical/current controls.

## Issue #19 Water Feel Lab checkpoint

**Current, 2026-09-12:** V1 four-level/oriented presentation and V2 H-preparation
are complete. One normalized runtime policy covers semantic mass3..8,
coherence0..12, presentation/interface mode, deterministic scenario/seed and
provenance. The existing Tower now exposes 35 deterministic Water scenarios,
transactional Apply + Reset and reconstructible blind/export controls. Native,
full Windows Godot, actual GPU and real Chrome compatibility/threaded gates pass.
See the [completion evidence](../audits/2026-09-12-issue-19-water-feel-lab.md).

This checkpoint is a valid simulation/presentation apparatus result, not an H
preference result: mass8/coherence12 remain the production/reference control, no
preferred candidate or production packing was selected, #18 remains held, #20
remains downstream and G-final remains open. The earlier "H-ready" label is
qualified for current use by REM-001: formal blind-study capture remains blocked
on #84's arm-identity separation and append-only observation repair.

## Issue #26 Water head/leveling disposition

**Complete experimental Outcome B, 2026-09-19:** the
[dated #26 evidence](../audits/2026-09-19-issue-26-water-leveling.md) confirms that
Current Water has a real deep/extended head-transmission deficit rather than only a
presentation or mass-precision problem. A 108-case frozen control preserves exact
mass, 1/4-worker authoritative parity and zero post-setup allocations. Medium and
deep identical outlets produce the same early discharge; communicating pools and a
true unequal-head U-tube can quiesce with roughly 16- and 24-cell level differences.

The preregistered radius-2 head-scaled-local and same-row-horizon arms were both
rejected. Neither reached the automated survival gate, so no combined arm or owner
H audition was warranted and **no Water semantic change is selected**. The retained
characterization apparatus is reusable.

[Issue #45](https://github.com/techrote/cybersand/issues/45) is the bounded successor
for transmitting head/pressure through saturated connected Water. #18 remains
open/held until that bulk confound is resolved; #20 remains downstream and G-final
remains open. MicroScenario/INT-000 work continues independently and only affected
Water-dependent provisional evidence needs later revalidation.

## Issue #26 post-merge review and #49 correction

The [post-merge review](../audits/2026-09-19-issue-26-post-merge-review.md)
preserves #26 Outcome B for its two exact rejected local candidates, while
qualifying apparatus v1 for future acceptance use.

Confirmed apparatus limitations include dry-column false-pass equilibrium,
success-valued zero for unreached thresholds, non-revoked sustained passage,
a historical three-compartment fixture mislabeled as a clean U-tube, mixed
active/sleep p95 interpretation and evidence-runner durability gaps.

[#49](https://github.com/techrote/cybersand/issues/49) now supplies the bounded
versioned correction and source-matched
[Current-Water v2 baseline](../audits/2026-09-20-issue-49-water-apparatus-v2-baseline.md).
The clean two-limb control remains `not_reached` for both preregistered equilibrium
thresholds by tick 4800; this is a corrected Current-Water observation, not a new
solver selection. Production Water is unchanged. #95 must synthesize this control
with WEX evidence before #45 may proceed, narrow, recharter, defer or no-go.

## Water hybrid / pressure extension checkpoint — 2026-09-20

The [WEX programme](../operations/water-hybrid-pressure-extension-programme.md)
and tracker [#90](https://github.com/techrote/cybersand/issues/90) add a parallel
investigation before any new #45 pressure/head mechanism is treated as inevitable.

- [#91](https://github.com/techrote/cybersand/issues/91) freezes current generic
  Rapier↔Water splash/displacement and hard-boundary failure evidence.
- [#92](https://github.com/techrote/cybersand/issues/92) is dispositioned
  **BLOCKED** on current main: the required generic dynamic cell↔Rapier singular-owner
  handoff remains Planned/model-only under #12. No sheet arm ran and the hypothesis
  is untested, not rejected. See the
  [blocked disposition](../audits/2026-09-24-wex002-water-sheet-blocked-disposition.md).
- [#93](https://github.com/techrote/cybersand/issues/93) research records a
  [bounded lumped-region candidate](../research/lumped-gas-region-pressure-bookkeeping.md):
  technically promising for optional/research use, with no production atmosphere
  adoption.
- [#94](https://github.com/techrote/cybersand/issues/94) completed as
  [NARROW-USE local decompression research](../audits/2026-09-24-wex004-decompression-disposition.md);
  no general routed/room-scale atmosphere feature is admitted.
- [#95](https://github.com/techrote/cybersand/issues/95) synthesis is recorded in
  the [2026-10-23 WEX-005 record](../audits/2026-10-23-wex005-water-evidence-synthesis.md):
  the deep-release deficit is unresolved (on current `main` deep and medium outlets
  deliver identical discharge; sheets untested), and **#45 is NARROW** —
  admission/design only, under shared/vented-atmosphere assumptions, with a
  separately registered surge fixture. No production mechanism is selected.
- The opt-in Liquid Comparison Build pressure lane
  ([#200](https://github.com/techrote/cybersand/issues/200)) is reconciled
  separately by the
  [LCB-000 Gate A record](../audits/2026-10-23-lcb000-gate-a-water-pressure-admission.md).
  [#213](https://github.com/techrote/cybersand/issues/213) is **closed completed;
  Gates A–E PASS**. The [final checkpoint](#liquid-comparison-build-design-checkpoint--2026-10-23)
  records bounded admission. The owner lifted the hold for the
  [#200 policy foundation](#lcb-001-policy-foundation--2026-10-24) and then for the
  bounded LCB implementation, including the
  [#200 pressure reference](#lcb-001-pressure-reference--2026-10-24) and #212.
  `pressure_flow_v1` remains an opt-in comparison family, not #45 selection.

Water FreeMass and other-liquid CellularYield remain separate; no unification or
production solver change is selected. Equal-level communicating-head fixtures are
vented/shared-pressure controls, not universal sealed-room targets. #18 remains
held pending the resulting evidence rather than by issue-number sequence alone.

## Liquid Comparison Build design checkpoint — 2026-10-23

**Current admission status — 2026-10-24:** LCB-000 [#213](https://github.com/techrote/cybersand/issues/213)
is **closed completed; Gates A–E and integrated LCB-000 PASS**, with no RECHARTER.
The [final landed-stack evidence](https://github.com/techrote/cybersand/issues/213#issuecomment-6377498947)
and subsequent [closure](https://github.com/techrote/cybersand/issues/213#issuecomment-6377517354)
supersede the earlier pending-admission status without rewriting those dated records.

| Gate | Accepted scope |
|---|---|
| A — PASS | Separate experimental Water lane; production Water/WEX limits retained. |
| B — PASS | Bounded reversible storage design; no representation winner or schema/ABI freeze; #204 is not complete. |
| C — PASS | [Solver-family policy design](../architecture/liquid-solver-family-policy.md) and source-derived capability matrix. |
| D — PASS | [Bounded Water comparison contract and protected fixtures](../operations/lcb-water-comparison-and-fixtures.md). |
| E — PASS | Independently closed I1/P2 and listed P3; reviewed integrated apparatus landed with passing post-merge CI. |

**Current landed checkpoint:** #215 → #217 → #226 merged to main
`e95fe85d82e108a682a2ae0212d85569f1c03cd8`, whose tree
`fece020ef7fc83faf5cfe3081b018f2647f7e4fe` equals the reviewed #226 head.
Documentation/provenance, Native and GDExtension/Godot post-merge CI passed.
The [dated reconciliation](../audits/2026-10-24-lcb000-landed-status-reconciliation.md)
records exact identities, evidence classes and validation limits.

**Approved admission; owner holds lifted 2026-10-24:** only a separately scoped initial opt-in
[#200](https://github.com/techrote/cybersand/issues/200) start is admitted.
The owner first lifted the hold for the bounded
[#200 policy foundation](#lcb-001-policy-foundation--2026-10-24) only, then authorized the
bounded LCB implementation, including the previously held #200 pressure reference and
[#212](https://github.com/techrote/cybersand/issues/212) inertial work
([owner decision](#lcb-001-pressure-reference--2026-10-24)). Neither decision admits
production default changes, generic #12 Stage-4 cell↔Rapier ownership, a production
Cell-carrier migration, full GEN-006 streaming, new pressure-to-Rapier forces or a
schema/ABI freeze. The policy foundation is Current on main; `pressure_flow_v1/reference`
is Current in source; the other candidate kernels remain **Planned**.
#201/#202/#203 remain open; the scenario apparatus delivered part of
#202, not the complete comparison host or its [manual UX](../operations/lcb-manual-comparison-ux.md).

**Current apparatus:** the [LCB scenario catalogue](../operations/lcb-scenario-catalogue.md)
contains 25 scenarios plus the protected Dam Break and mixed fixtures, with
Current-default controls. Water is the only `freemass_v1` liquid; ten liquids
use `cellular_yield_v1`. The mixed control runs two families; three-family World
execution remains blocked. All **90 candidate arms remain blocked**.
Controls and v2–v6 records are preserved byte-for-byte; v7 retains
**20 closed / 4 unverified source-sink timing / 3 unverified reaction amount**,
with `changed_from_v6=[]`. Characterization and contract-model evidence do not
establish candidate runtime acceptance or change defaults.

## LCB-001 policy foundation — 2026-10-24

**Current on main.** [PR #239](https://github.com/techrote/cybersand/pull/239) merged on
2026-10-24 at 07:01:19Z as
[`1e032e492cafb232e604baf6e2b823b13d779aa8`](https://github.com/techrote/cybersand/commit/1e032e492cafb232e604baf6e2b823b13d779aa8).
Its tree `4519bb257cc1060b1d79dd35ac3f183618ec605a` equals the reviewed head
`cc01899`. The post-merge push runs all passed on first attempt:
[Native 40072499987](https://github.com/techrote/cybersand/actions/runs/40072499987), [GDExtension/Godot 40072499990](https://github.com/techrote/cybersand/actions/runs/40072499990), [Documentation/provenance 40072499986](https://github.com/techrote/cybersand/actions/runs/40072499986) and [#49 Water apparatus 40072499994](https://github.com/techrote/cybersand/actions/runs/40072499994).
The owner lifted the #200 hold for this bounded foundation only. It implements the
accepted Gate C policy object, not a solver: validation precedence, canonical
SHA-256 identity, normalized readback and transactional construction for the
running build, which **admits only each liquid's current default** and refuses
every candidate mapping before any World is built. Defaults, dispatch, C64-E8,
kernels and goldens are unchanged. See the
[native foundation contract](../architecture/liquid-solver-family-policy.md#native-policy-foundation-current-2026-10-24)
and [dated evidence](../audits/2026-10-24-issue-200-policy-foundation.md).

| Item | Status |
|---|---|
| Native policy, wire decode, refusal codes, hash, World admission, experimental C API, GDExtension receipt/validation/construction, MicroScenario request, worker receipt | Current (main `1e032e4`) |
| NC-1, NC-2 and NC-10 | Executable in the foundation regressions; the LCB registry is unchanged |
| Pressure backend, W-CY/W-IN kernels, run receipt hash, normalization, physical-state hash, remaining #202 constructors, durable schema/ABI freeze | Planned, held or deferred at this checkpoint; the pressure backend, physical-state hash and an experimental run-receipt hash followed in the [pressure reference](#lcb-001-pressure-reference--2026-10-24) |
| #212, #201, #202, #203 and all 90 candidate arms | Unchanged at this checkpoint: held or blocked (the #212 hold was lifted later the same day) |

**Issue-state correction (2026-10-24).** GitHub automatically closed
[#200](https://github.com/techrote/cybersand/issues/200) at 07:01:20Z when PR #239
merged, because it parsed the PR body's negated phrase "does not close #200" as a
closing keyword. The issue was reopened on 2026-10-24 with an explanatory comment.
That transition supplies no completion evidence; #200 remains open for the scope
listed below.

## LCB-001 pressure reference — 2026-10-24
**Current on main from merged PR #245 (`03785c3`).** The opt-in
Water family [`pressure_flow_v1/reference`](../architecture/pressure-flow-v1.md)
runs only in a World whose applied policy assigns it; production defaults, every
Current golden, `content_hash`/`state_hash` and CYSD1 are unchanged. Source
identities, commands, local results, failed attempts and runtime publication are
in the [dated evidence record](../audits/2026-10-24-lcb001-pressure-reference-publication.md).

**Owner decision (2026-10-24).** The owner explicitly authorized the bounded LCB
implementation, including the previously held pressure reference (#200) and the
inertial family ([#212](https://github.com/techrote/cybersand/issues/212)),
without changing production defaults, without generic #12 Stage-4 cell↔Rapier
ownership, without a production Cell-carrier migration and without full GEN-006
streaming. This lifts the execution holds recorded in the
[LCB-000 checkpoint](#liquid-comparison-build-design-checkpoint--2026-10-23). It
does not admit new pressure-to-Rapier forces, a schema/ABI freeze or a #45
mechanism: `pressure_flow_v1` is a comparison family, and its characterization
does not freeze #45 thresholds.

| Item at the accepted #245 main checkpoint | Status |
|---|---|
| At the accepted #246 checkpoint, Water admitted `pressure_flow_v1/reference`, optional family block `{gas_enabled 0..1, atmospheric_head_rows 16..4096}` (defaults 1, 32); then-unmerged #201 separately added `cached`/`cached_dormant` | Historical checkpoint; #201 is now accepted on main through #253 as recorded below |
| Solver-owned per-chunk sidecars, World gas table with label-overlap identity and exact ledgers, immutable head snapshot, phased kernel | Current ([design](../architecture/pressure-flow-v1.md)) |
| Physical-state hash v1 and CYPS1 at the historical #245 checkpoint; retained inspection/ledger APIs | Historical codec; accepted main now uses v2 [below](#lcb-001-shared-contract-accepted--2026-10-25). Original APIs ([interfaces](interfaces-and-message-contracts.md#lcb-001-pressure-reference-inspection-and-persistence-experimental)) |
| Capability matrix Water × pressure `executable_today: true`, `executable_variants: ["reference"]`; regenerated digest and vector identity words, with no acceptance/refusal change in the 47 cases | Current |
| Native `test_lcb_pressure.cpp` (13 cases), Godot `test_lcb_pressure_reference.gd` (12 sections), native characterization harness | Current; results in the evidence record |
| Linux/Windows Godot, sanitizer/TSan and apparatus execution | Exact-head required matrix passed for #245; Web not built or run ([acceptance](../audits/2026-10-24-lcb001-pressure-reference-publication.md#exact-head-acceptance-and-merge)) |

**Characterization screens, not admission criteria** (native harness, 1 worker):
at repaired source `349d593`: depth response t240 1.69 (Current 1.06); depth-160
front t240 220 (71); depth-160 retained t1800 0.371 (0.851); vented two-limb
|difference| t2400 9 rows (120); narrow passage 43 rows (120). The sealed
two-limb differs from vented (levels 152/175, gap 23), remains unsettled and has
no sealed-law acceptance. Quantity was exact in all twelve runs. Earlier-source
measurements remain in the dated evidence record.


**Publisher.** The temporary pressure-reference workflow, helper, unittest and
source-bound request, integrated from draft PR #244, are retired after PR #245.
Their original implementation remains recoverable at `48fb275`.
After the retained failed/cancelled attempts and takeover repairs,
publication run `40100666514` passed Linux and actual Windows headless execution
and published both source-matched runtimes at `101758d`; the evidence
record holds their hashes and scope. The final exact-head ready-PR matrix passed
at `e48c5aa` before merge; the [acceptance receipt](../audits/2026-10-24-lcb001-pressure-reference-publication.md#exact-head-acceptance-and-merge)
records all four required runs. Retirement is part of this successor branch.
Successor native changes require fresh source-matched publication,
as described for [branch-scoped publishers](../operations/local-build-and-validation.md#branch-scoped-runtime-publishers).
#200 itself stays open (see the [issue-state correction](#lcb-001-policy-foundation--2026-10-24)).

<a id="lcb-001-residual-shared-contract--2026-10-24"></a>

| Remaining | Owner and status |
|---|---|
| W-CY, `water-normalize-v1`, native typed receipts and exact quantity accounting | #200, Accepted on main through #246; scope and remaining ownership [below](#lcb-001-shared-contract-accepted--2026-10-25) |
| Host provenance/collection proof and remaining normal-application constructors | #202, Planned; preserve native shared interfaces from #200 |
| `cached`/`cached_dormant`, incremental caches and motion certificates | [#201](https://github.com/techrote/cybersand/issues/201), accepted on main through #253 after source-matched publication and full exact-head gates; [earlier branch evidence](#lcb-002-pressure-variants-branch--2026-10-25) keeps its scope |
| Comparison host and UI; re-dispositioning the registered candidate arms | [#202](https://github.com/techrote/cybersand/issues/202), Planned |
| `inertial_cellular_v1` (W-IN, Brine), M1/M2 | #212: Brine/reference accepted on main through #250. Isolated Water native/sourceaa8 sequence2 publication passes both OSes; final ready-PR, registered scientific campaign and full host acceptance remain pending. M1/M2 retained campaign classifications do not change |
| Packaged builds and isolated timing | [#203](https://github.com/techrote/cybersand/issues/203), Planned |

The accepted #201/#250 main status above remains distinct from the later Water
worker activity/storage/pool repairs through c97f68ec. The original sequence1
publication keeps its source4b/C9 identity. Actual sequence2 sourceaa8af247,
run40220697738 and bot03cccd8f now publish the repaired kernel on both OSes;
final ready-head gates/review and full #212/#203 acceptance remain pending.
Local application164/SAN39/35-host preparation is source-bound evidence and
does not replace those gates. The inherited duplicate Current table has been
removed; dated branch evidence remains retained below.

## LCB-001 shared contract accepted — 2026-10-25

**Current on main through [PR #246](https://github.com/techrote/cybersand/pull/246),
merged as `ec58d919b3d904fbd338eaccc25de35782c41a24`.** Final tested head
`560f9a4143852c5a508b5f33a4a7f2059edbcbdc`, its synthetic checkout and the merge
share tree `e8e999899bd35bf20df4b03cf9c0620d86089ff1`.
The [shared native contract](../architecture/liquid-prepared-setup-and-receipts.md)
now supplies whole-cell Water admission/refusal and liveness, explicit final-tuple
`water-normalize-v1`, native-issued outcomes, immutable prepared Worlds, typed
v1 run/attempt receipts and exact quantity aggregates. Complete physical hash
and CYPS are **version 2**; main explicitly refuses historical CYPS1.
Historical content/state hashes, C64-E8, production defaults and prior failures
are preserved. This is a narrow native codec checkpoint, not a global ABI or
full-host replay freeze.

The [final acceptance audit](../audits/2026-10-25-lcb001-shared-contract-acceptance.md)
records Documentation/provenance `40144712901`, Native `40144712872`, Godot
`40144712946` and #49 `40144712913`, all passing at that tree. Native runs all
126 cases ordinarily, with ASan+UBSan and with TSan, plus the required additional
lanes. Godot records 145 Linux + 133 Windows cases, five imports, twelve rendered
Linux cases and 55 physical timing observations without timeouts/other failures.
Windows exploratory construction passes in 71.240 seconds under the original
180-second limit. Source-matched publication and the earlier failed/cancelled
attempts retain their own records; the final audit does not rewrite them.

**Remaining ownership:** #200 stays open pending ownership reconciliation.
#202 retains the normal application constructors, typed host evidence,
normalization opt-in, UX and Web integration. Native-v1 source/runtime/host
qualifications remain explicit and full matched eligibility remains false.
#201 and #212 are separate successor integration/qualification lanes; #203 owns
packaged comparison coverage after integration. Their isolated work does not
change this accepted main checkpoint's capability matrix.

**Owner execution boundary:** after this accepted native checkpoint, fan out
#201/#202/#212 where write sets permit, then integrate and qualify/package via
#203. A #201 rest certificate must retain stationary failed-motion body contacts,
mandatory material stages, other liquids and future cadence/stochastic work.
Zero rounded flow is not rest; a complete tick-inclusive hash cannot be a
cross-tick static-rest predicate. Every successor native change needs fresh
source-matched runtimes and its applicable exact-head gates.

## LCB-002 pressure variants branch — 2026-10-25

**Dated branch evidence; #201 is now accepted on main through #253:** Water
admits `pressure_flow_v1/reference`, `cached` and `cached_dormant` as implementations of
the same physical law. [The optimization contract](../architecture/pressure-optimization.md)
owns sparse head repair, sealed-component discovery reuse, conservative motion
certificates and deterministic execution3 proof-cost admission. Default Water
remains FreeMass. Generic #12 Stage4, pressure-to-Rapier forces and #45 selection
are not admitted by this work.

The [dated #201 evidence](../audits/2026-10-25-lcb002-pressure-variants.md) owns
exact checkpoints, local tests, retained failures and complete-tick cost scopes.
Old execution1 measurements retain sleeping/churn/fallback negatives and cannot
be reattested as execution3 performance. New prepared-head discrepancy and net
boundary-balance observations are separate from equal projection or work counts.
No global speedup is claimed. Source-matched Windows/Linux scoped publication
[`40152121412`](https://github.com/techrote/cybersand/actions/runs/40152121412)
passed actual import plus all13 cases on each OS at source `8354e3a6`, followed
by the single-parent four-path bot append `d726bf34`. Those branch records
precede the later full exact-head gates and #253 acceptance; the new Water
activity repair still requires its own source-matched publication and gates.
Actual Rapier rotation/displacement, full host constructors and
Web/integrated packaging retain #202/#203 ownership.

## LCB-003 controlled application-host slice — 2026-10-24
**Subsequent Water Feel constructor:** explicit unblinded body-free sampled
Exploratory rebuilds retain original Water policy/recipe/player/actions and
ordinary controls/ledger. Reset/semantic changes retain accepted family choice;
same-hash native refusal requires exact serial/applied acknowledgement. Blind,
unstaged bodies and fractional whole-cell future sources refuse before commit.
See [the route contract](../architecture/liquid-prepared-setup-and-receipts.md#ordinary-water-feel-preparation)
and [dated local qualification](../audits/2026-10-25-lcb003-water-feel-constructor.md).
Body/blind/future-source qualification, other constructors and real Web remain open.

**Subsequent qualified host observation foundation:** version1 records native
API-reported library path/current-file facts, actual config/publication files and
bounded current-script observations separately from unverified caller values.
Controlled Windows standalone and real editor module probes confirm the editor
shadow-path distinction. [The contract](../architecture/liquid-prepared-setup-and-receipts.md#qualified-host-observation-foundation)
and [dated evidence](../audits/2026-10-25-lcb003-qualified-host-observation.md)
retain false native/host full matched eligibility. Normal owner integration,
complete setup identity, matching publication and actual browsers remain open.

**Subsequent owner binding:** immutable qualified observation collection now
precedes the actual final commit guard and is adopted only on success. Normal
selected setup/reset publications carry compact record/native receipt identity;
explicit capture carries copied canonical values. Refusal retains the old
record and articulated graph; accepted defaults retire identity. [The contract](../architecture/liquid-prepared-setup-and-receipts.md#owner-bound-construction-observation)
and [local proof](../audits/2026-10-25-lcb003-owner-observation.md) preserve the
remaining complete host/source/publication/browser gaps and false eligibility.

**Subsequent ordinary Tower constructor:** explicit Exploratory solver rebuilds
retain the existing sampled player, selected floor, release/schedule/manual tools
and independent transport profile. Reset/profile rebuild preserve accepted
policy/normalization/geometry, while ordinary defaults retain their separate
constructor and retire typed identity. See [the owner contract](../architecture/liquid-prepared-setup-and-receipts.md#ordinary-experiment-tower-preparation)
and [dated local scope](../audits/2026-10-25-lcb003-tower-constructor.md). Remaining
constructor rows, complete host evidence and actual browser/publication gates
remain open.

**Integrated #202 checkpoint, 2026-10-25:** the application branch now contains
accepted #246 main `ec58d919` and stable #250 IN source `028fc7b6`. Native-backed
normal controls expose actual damping/extension identity and instance hash/CYPS3;
candidate/control radius3 is explicit and Original Current restores radius2.
Fresh scoped local Windows headless tests include all17 parameter values,
three interacting families under workers1/4, exact continuation and actual
articulated actor/equipment/mask adoption. See the
[integrated evidence](../audits/2026-10-25-lcb003-integrated-inertial-host.md).
This closes the accepted-main/IN integration gap in the earlier local ledgers;
it does not complete remaining constructors, separately versioned full host
evidence, published runtimes, Linux, actual Web, owner feel or #202/#212 acceptance.

**Subsequent unmerged #202 source, 2026-10-25:** supported desktop exploratory
maps additionally stage articulated Rapier actors/equipment and complete initial
terrain in a permanent private World2D. Actual frozen poses produce initial
native masks before receipt capture. The nonblocking worker/main continuation
preserves old owners and admitted work on refusal, with final request/settings/
reset/stop and exact definition/policy/options binding. See the [physical host contract](../architecture/liquid-prepared-setup-and-receipts.md#staged-articulated-physical-owners)
and [constructor matrix](../operations/lcb-manual-comparison-ux.md#constructor-coverage-at-this-checkpoint).
Barrel/reference bodies, remaining normal constructors, a separately versioned
complete host-evidence layer, final source/runtime integration and actual browser
qualification remain open. Native outer receipt-v1 keeps its qualifications and
false full-match eligibility.

**Current experimental source on `codex/lcb003-application-host`, based on
the frozen #246 head `9e91a9f7`:** fixed actor-free schema-2 MicroScenarios can
request an explicit family policy and `water-normalize-v1` through the normal
desktop and synchronous application controllers. One pending native candidate,
preallocated rendering, final execution/interest capture and copied typed
native receipts precede a one-use token commit. The worker checks current
request revision/reset/stop under its queue mutex at the actual swap; a newer
same-definition request cannot commit an older preparation. Reset retains the
accepted policy and normalization selection. Refusal retains the old World,
cursor, generation and applied receipt, with a distinct native attempt value
where native preparation/admission supplied that outcome.

The [host contract](../architecture/liquid-prepared-setup-and-receipts.md#controlled-application-host-preparation-slice)
and [dated evidence](../audits/2026-10-24-lcb003-controlled-host-slice.md) own exact
scope. Native-v1 setup/source/runtime/host qualifications and false full-match
eligibility remain intact. Linux/hosted publication, real Web execution of this
new path, verified definition/provenance collection, physical actor/body staging,
remaining normal constructors, full comparison exhibition and complete UI coverage remain #202 work.
The subsequent source checkpoint `0a702eb3` adds a native-validated per-material
picker/presets, explicit normalization, actual launcher/panel Apply/readback and
protected Current/mixed fixture controls. The [manual UX contract and constructor
coverage](../operations/lcb-manual-comparison-ux.md) distinguish this bounded
Current UI from remaining Planned actor/exploratory/import/plane routes; the
[UI evidence](../audits/2026-10-25-lcb003-liquid-comparison-ui.md) records local
Windows controller execution and preserved Current physical hashes.
The next source checkpoint `da800552` stages sampled characters and allowlisted
sampled actor/equipment owners against native candidate collision queries before
swap. Explicit Exploratory mode captures actual initial owner interest/settings,
retains solver choice through F5/reset and holds initial presentation frames until
the matching accepted acknowledgement. The [sampled contract](../architecture/liquid-prepared-setup-and-receipts.md#staged-sampled-actors-and-exploratory-owners)
and [evidence](../audits/2026-10-25-lcb003-sampled-exploratory-host.md) keep physical
bodies, remaining constructors and complete verified host/provenance open. Shared
native source is still `9e91a9f7`, before final #246 checked-scalar fixes; final
integrated tests/publication remain required.
The work is prepared independently while #246 completes its acceptance gates;
integration still follows fresh accepted main.

**Subsequent ordinary synchronous demos:** source89baee16 explicitly rebuilds
Material Lab, Waterworks, Foundry and Neon Works in Exploratory mode using exact
ordered recipes, privately staged sampled player and actual view/cadence before
the final native commit. Restart retains accepted recipe/policy/geometry;
imported labels cannot impersonate authored recipe identity. Six strict local
Windows processes pass, including117 new ordinary-demo assertions and actual
quarantined prepared Restart refusal/explicit Current recovery. See [scope and
evidence](../audits/2026-10-25-lcb003-ordinary-demo-host.md) and the
[constructor matrix](../operations/lcb-manual-comparison-ux.md#constructor-coverage-at-this-checkpoint).
Desktop counterparts, body/showcase/arbitrary recipe routes, same-policy failed-
World recovery, final native repair/integration and complete platform/host gates
remain open; this does not complete #202 or qualify Brine IN rest contacts.

**Subsequent synchronous Physics Pit:** source5d5c75ed adds explicit Exploratory
apply to its actual authored rectangle/three-body/sampled-player owner. Private
frozen permanent-space preparation, copied request/token, actual final masks
and serial/source/generation/settings fences precede adoption; cancellation and
refusal retain old state. Six local Windows processes pass490 assertions,
including70 new normal-owner checks and three original240-tick PF arms with
consumed positive feedback/exact quantity. See [the owner contract](../architecture/liquid-prepared-setup-and-receipts.md#synchronous-physics-pit-reference-bodies)
and [dated proof](../audits/2026-10-25-lcb003-synchronous-reference-body.md).
Imported physical saves and other physical routes,
complete host identity and final source-matched/browser gates remain open.

## Opt-in transport profiles

**Current:** the [profile contract](../systems/flow-transport-and-profiles.md)
owns schema, inheritance, units, immutable native tables and explicit owner restart.
The Tower applies validated profiles through restart. Actual powder falls and
lateral Water mass transport drive bounded optional mixing and grain pickup;
horizontal sampling and cadence are separate fixed experiments.
The [September 10 Water follow-up](../audits/2026-09-10-water-leveling.md) increases
default lateral relaxation after owner feedback. Historical #13 Water traces are
preserved; the new source identity owns its changed front/erosion behavior.
Ordinary gameplay keeps Baseline; chemistry cadence, compact cells and CYSD1
are unchanged. No unsynchronized live descriptor mutation is introduced.

## Architecture investigation after the Water checkpoint

**Planned:** the [architecture programme](../operations/architecture-programme.md)
and its dated [Water-feel addendum](../operations/architecture-programme-water-feel-addendum.md)
isolate raw Cell layout/epoch cost, liquid characterization, quantitative precision,
presentation, human-test preparation and conditional compact motion before any
policy migration. Sparse ballistic implementation still requires admission evidence;
coherent soliding reuses #12. No 4/8-byte winner, liquid unification or representation
ladder is adopted. GitHub #11 is closed while this source still records its missing
barrel work; support-dependent integration requires actual source/evidence reconciliation.

## Architecture gate reconciliation, 2026-09-11

**Dated 2026-09-11 programme state:** G-L, G-C and G-P are complete. #16 research is complete;
that checkpoint retained its 4-byte Cell baseline pending G-final, not a permanent
width selection. The source-qualified 2026-09-19 storage correction below governs
current physical-size accounting. #17 retains mass8 as the numerical/reference Water control and proves
existing Water coherence 0..12 fits exactly in four semantic bits. No production
Water precision or Cell layout migration is authorized.

Following G-P, owner intent clarified the role of precision work: lower Water
precision primarily exists to investigate flexible material-state budgets, while
performance is secondary. Quantitative differences therefore describe what changes
but do not by themselves determine gameplay desirability. The dated
[post-G-P Water-feel refinement](../operations/architecture-programme-water-feel-addendum.md)
records the governing rule that **quantitative equivalence and perceptual adequacy
are separate gates**.

#19 completed its expansion from presentation-only V into **V plus H-preparation**. Its
[first-stage contract](../operations/architecture-programme-prompts/fractional-presentation.md)
established the intended four-visible-level fractional presentation and left
a verified Water Feel Lab with deterministic scenarios, runtime semantic policies,
A/B/blind support and #17 correspondence. Available later human-test semantic axes include
mass3..8 and coherent duration0..12 without recompilation; this is semantic emulation
in a superset experimental representation, not production repacking.

#19 completion is **H-ready**, not evidence that a preferred Water model has been selected.
The later human-led H gate will use the real apparatus to classify candidates and,
where applicable, name a perceptual motion deficit. #18/M remains held until such
a concrete directional-persistence target is justified, or may complete by reasoned
no-go. #20/B remains dependent on #18/G-M and its own admission. #14/G-final remains open.

See the earlier [identity and scope audit](../audits/2026-09-11-programme-gate-reconciliation.md)
for the pre-refinement reconciliation; the Water-feel addendum is the later dated
planning authority for the affected #19/#18 ordering.

## Issue17 precision completion

[G-P is complete](../operations/architecture-programme.md#g-p-staged-decision-2026-09-11)
with [exact fixed-carrier evidence](../audits/2026-09-11-issue-17-state-precision.md).
Mass8 remains the numerical reference; Water delay4 is an exact storage budget for
current 0..12 coherence semantics. That result is **not retracted** by the later
Water-feel refinement. Instead, #19/H-preparation uses it as the quantitative oracle
against which runtime mass4/6/8 controls are checked before novel mass3/5/7 and
shortened-coherence candidates are offered for human testing. No production migration.


## MicroScenarios and intermaterial-interaction programme

**Planned/active apparatus, revised 2026-09-18:** the
[canonical programme graph](../operations/microscenarios-programme.md) is the
ordering authority for #24/#27-#30. GitHub issue numbers are identifiers, not a
serial path.

#27/MS-000 no longer waits for #18 or G-final. Once the #24 launcher/input fix is
present (including as an isolated prerequisite on the working branch), #27 may
extract the deterministic common scenario host from #13/#19. It remains
apparatus-only and cannot alter #18 compact-motion admission, #20 G-B admission,
#26 Water evidence or #14 architecture semantics.

#28/MS-001 may then build **exploratory/provisional** Materials Laboratory,
Flood-Control Puzzle and Simulation Stress Test scenarios before G-final. Their
purpose includes organically discovering unknown edge cases. The Materials
Laboratory has an explicit readiness checkpoint that can unblock #29 while the
other two scenarios continue; all affected provisional scenarios are versioned
and revalidated after relevant physics/architecture changes rather than being
silently relabelled as accepted evidence.

#29 is **INT-000: intermaterial interactions**, not a chemistry-only campaign.
**Merged/current infrastructure:** PR #55 landed as
`910717aac101363ec2b1b89e4041a22bc9a97b97`; #29 is complete for its bounded
infrastructure checkpoint and #30 remains the programme tracker. The landed #27/#28
apparatus has been consumed by the versioned sparse interaction substrate. The compact 14-rule
pair boundary now resolves through stable IDs/channels with a literal frozen
pre-migration oracle; layered family/material/pair/context authoring, conflict
validation, specialized-kernel provenance, coverage/revalidation records,
generated schema-2 fixtures and batch comparison tooling are implemented in the
source checkpoint. Specialized neighbourhood/lifecycle mechanisms remain
authoritative in their existing `world.cpp` kernels where migration would
unnecessarily entangle kinetic ownership.

No broad interaction tuning is selected by this infrastructure checkpoint.
Kinetic movement/support/bridging/erosion/collision remain owned by existing
physics systems. Each later accepted tuning pass must pin the relevant
source/runtime/contact/transport baseline and retain prior evidence so later
physics changes trigger targeted re-screening rather than destructive retuning.

The discovery workflow is: explore a scenario -> capture an anomaly with exact
identities -> reduce it -> triage ownership -> bounded fix/tuning -> retained
regression -> return to the larger world. #30 tracks this programme; it is not
itself an execution prerequisite. #18/#20/#14 retain their independent gates in
the architecture programme.

## MS-000 common MicroScenarios checkpoint

**Current source, 2026-09-19:** [MS-000](../operations/microscenarios.md) extracts one
validated, bounded scenario host for the existing Tower/Water owners and a
native-only runner. Play/Inspect/Benchmark share definitions, while legacy blind,
reset and physics-order contracts remain distinct where they were distinct before.
Two exploratory generic fixtures exercise Water quantity and non-Water material
observations. Captures identify source/runtime/profile state but are not replay saves.

This is apparatus, not a solver/interaction migration. The [programme graph](../operations/microscenarios-programme.md)
still controls #28/#29 readiness and keeps architecture gates separate. Read the
[checkpoint evidence](../audits/2026-09-19-issue-27-microscenarios.md) before claiming
Windows, GPU or native Web runtime acceptance for this version.

## MS-001 reference-pack checkpoint

**Merged exploratory checkpoint, 2026-09-19:** PR #44 landed the schema-2
[reference pack](../operations/microscenario-reference-pack.md) at merge
`c1edf907cce1693fa45f89e9f1f573f05483c1e4`: Materials Laboratory with
complete generated interaction fixtures/fresh-reset A/B, a Flood-Control Puzzle
with a wet untreated control and three distinct geometry-only successful
witnesses, and four finite Water/granular/gas/mixed Simulation Stress profiles.
Schema-1 Tower/Water definitions retain their hashes and existing blind controls.
No material rules, profiles, capacities or physics defaults changed.

The accepted PR head `95aa2a0cb7b68445ed4a23ad16481c947e5a4695` passed
documentation/provenance, native and Godot CI before merge. The
[execution ledger](../audits/2026-09-19-issue-28-ms001.md) records a bounded
post-merge review that retained the implementation while correcting Flood
endpoint wording, the Stress uniqueness regression and stale compact definition
hashes. Actual Windows/browser/target-GPU execution remains unavailable.

The explicit Lab readiness prerequisite for #29 was satisfied and consumed by
PR #55 after a fresh reconciliation of the historical preflight against the
landed schema-2 contract. PR #55 subsequently passed its required acceptance gates
and merged; #29 is closed. MS-001/INT-000 completion still does not waive
#18/#20/#26/#14 gates, and later interaction tuning remains separately bounded.

## INT-000 implementation checkpoint, 2026-09-19

**Historical pre-merge checkpoint:** PR #55 was the sole #29 implementation
owner at this point. It has since merged as
`910717aac101363ec2b1b89e4041a22bc9a97b97`; use the current programme/status
paragraphs above for live routing. It preserves existing compact pair behavior while migrating
that bounded authority behind the versioned sparse resolver, exposes read-only
effective provenance through the existing schema-2 Materials Laboratory path, and
adds generated mechanism fixtures plus batch coverage/pass comparison tooling.

The interaction schema defines seven independent channels and explicit precedence
for channel default < family default < material adjustment < pair override <
context modifier. Current behavior authors no implicit defaults/adjustments/
modifiers; tests cover ordered, symmetric and unordered-role-preserving pair
semantics plus equal-precedence conflict detection. Captures retain rolling
source/runtime/transport/Water/execution/worker baseline identity for targeted
revalidation. Coverage gaps remain explicit rather than being converted into a
dense fabricated matrix.

This checkpoint does **not** migrate specialized movement-entangled `world.cpp`
kernels, select new material tuning, alter Water/granular/soliding/ballistic
semantics or satisfy independent architecture gates. Final status is not upgraded
from candidate until exact-head current checks and final diff/acceptance review
complete.

## Issue #12 successor programme, 2026-09-19

**Approved direction / Planned implementation:** #12 now owns scalable reversible
soliding for large-world acceleration and Rapier macro-dynamics/fracture. The
[canonical stage gates](../operations/soliding-programme.md) supersede the earlier
bounded-prototype scope. PR #23 remains Phase 0 evidence at `0b96ce2`; it does not
close #12. The successor starts at `de332ea` in an isolated worktree, preserving
#26/#27 source identities. Lifecycle tests precede discovery; measured Current
sleep precedes performance claims; region discovery precedes acceleration.
Dynamic handoff, torque-driven rotation, coherent-child fracture and persistence
remain later unpassed gates, not implied by a standalone contract model.

[Successor evidence](../audits/2026-09-19-issue-12-foundation.md) includes the
reviewed standalone lifecycle, bounded journal and measured Current sleep control.
The parent-owned [Stage-3 review](../audits/issue-12-2026-09-19/stage3-exit-review.md)
classifies the integrated producer/connectivity implementation as the passed Stage-3A
bounded correctness/reference checkpoint at `82e65f3`, with exact-head CI,
provenance and final parent review complete. Stage 3B locality/scalability remains open: measured fixed memory,
full tracked-tile signal refresh and whole-region sparse-edit rebuilds prevent full
Stage-3 admission. PR #47 merged the bounded reference as `fc299c1`. The read-only Stage-3B
architecture review is complete; its supervising-parent reconciliation is recorded in
the [Stage-3B parent decision](../audits/issue-12-2026-09-19/stage3b-parent-decision.md).
The active implementation route is the
[Stage-3B production plan](../operations/soliding-stage3b-production-plan.md), issues
#56-#70. #56-#65 and #69 are complete. #65 / PR #106 landed as
`cdf0a0874d4732c41273e10d921bcd5feaac3e3c` after exact-head validation and
source-matched runtime publication; landed-main Documentation, Water, Native and
GDExtension/Godot validation also passed. **#66 is now dependency-ready**, then
#67, #68 and #70. Stage 4 is blocked; production dynamics, fracture and persistence
remain unimplemented. Source `de332ea` actually uses
the 8-byte superset carrier after #19 integration;
the [storage contract](../architecture/chunk-tile-and-buffer-model.md) supersedes
earlier four-byte physical-size statements for this source without selecting G-final.

## Combined desktop features and physical actor trial — 2026-10-18

The [physical actor programme](../operations/physical-actor-programme.md) retains the initial barrel/Ripper comparison and owner notes. The [ACT-004 contract](../systems/physical-actor-rigs.md) now owns articulation, shared physical control and usable attachments. Broad granular acceptance remains separate; owner observations and scripted fixture results are distinct forms of evidence.

## Strata Theatre integration — 2026-10-18

The opt-in [depth prototype](../systems/depth-layers-and-parallax.md) supplies four native material worlds and five compositor modes. It remains a synchronous comparison host, separate from ordinary asynchronous gameplay; production layering, immutable native-event forwarding, persistence and browser qualification remain Planned.

## WORKBENCH-001 / #391 integration candidate

The [desktop development workbench](../systems/player-control-playground.md#development-workbench-on-desktop) is being qualified on a separate Draft branch from main 751edc0b. The required baseline includes the eight-flyer fleet, five-piece Scooper and actual multi-body granular response. The preserved #392 attempt covers an earlier assignment. Review the [dated evidence and source compatibility disposition](../audits/2026-11-04-workbench-consolidation.md) before making a platform, physics or promotion claim.

[Owner-feedback follow-up](../audits/2026-11-04-workbench-live-editing.md) records immediate pilot switching, acknowledged reset during play, recovery of the authored start and explicit workbench-only liquid conversions on PR #394.

The [edge-conversion and desktop pacing follow-up](../audits/2026-11-04-workbench-boundary-and-pacing.md) covers live solver changes after material leaves the canvas, render-independent body stepping, and parity and throughput of workbench pressure-column dispatch.

The [PR #394 cleanup](../audits/2026-11-04-workbench394-cleanup.md) retains tuning across missing-model pilot replacement and repairs the fleet registry shutdown lifetime. Its [three-consumer MAT source transition](../audits/2026-11-04-workbench394-material-source-transition.md) reuses the approved #396 mechanism and preserves the frozen lock. Technical admission, owner adoption and merge are separately recorded; #394 remains Draft and unmerged.

The owner accepted the playable workbench and authorized [current-main reconciliation and Ready qualification](../audits/2026-11-04-workbench394-ready-validation.md). Accepted main now includes #396 and #382 at `ee92dc45`; the combined native source requires rebuilt desktop runtimes and its own complete gates. The earlier Draft checkpoints remain historical; merge remains held.
