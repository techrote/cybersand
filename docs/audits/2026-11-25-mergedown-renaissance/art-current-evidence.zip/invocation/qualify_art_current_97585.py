from pathlib import Path
import contextlib
import dataclasses
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/2e90cf7b4aa3/cybersand-ambient')
OUT = Path('/workspace/scratch/2e90cf7b4aa3/art-current-97585-qualified')
ENGINE = Path('/workspace/scratch/2e90cf7b4aa3/deps/godot-4.7/Godot_v4.7-stable_linux.x86_64')
sys.path[:0] = [str(ROOT/'tools'), str(ROOT/'tools/ci')]
import qualify_workbench_landscapes as custody
import run_godot_regressions as regressions

OUT.mkdir(parents=True, exist_ok=True)

def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def identity():
    source = custody.source_identity()
    runtime = custody.verify_runtime_identity()
    project = custody.project_identity(ROOT/'godot', source, runtime)
    supplemental = {}
    for relative in custody.git('ls-files', '-z', '--', 'examples/worldgen', 'godot/.godot').decode().split('\0'):
        if not relative:
            continue
        actual = (ROOT/relative).read_bytes()
        expected = custody.git('show', 'HEAD:'+relative)
        assert actual == expected, 'Supplemental input changed: '+relative
        supplemental[relative] = hashlib.sha256(actual).hexdigest()
    engine_hash = custody.sha(ENGINE)
    assert engine_hash == 'f85bbc6b15e22416c7d797cd60b63286dd67b9cb13498847056c18520ae55a75'
    version = subprocess.check_output([str(ENGINE),'--version'], text=True).strip()
    assert version == '4.7.stable.official.5b4e0cb0f'
    return {'source':source, 'runtime':runtime, 'loaded_project':project,
            'supplemental_inputs':supplemental,
            'engine':{'version':version, 'sha256':engine_hash, 'bytes':ENGINE.stat().st_size}}

cases = {case.name:case for case in regressions.discover_cases()}
names = ['test_ambient_default_off_integration', 'test_art_architecture_workbench', 'test_art_request_preparation',
         'test_art_request_admission', 'test_art_owned_transport',
         'test_art_provider_failure_lifecycle', 'test_art_response_preparation',
         'test_art_session_log', 'test_art_local_close', 'test_batch_lab_namespace',
         'test_batch_lab_security', 'test_architecture_proposal_bridge',
         'test_architecture_workflow_controls']
planned = [{'name':name,'case':regressions.case_dict(cases[name])} for name in names]
planned += [{'name':'combined-author','case':regressions.case_dict(cases['test_workbench_combined_authoring'])},
            {'name':'combined-reopen','case':regressions.case_dict(cases['test_workbench_combined_authoring'])}]
write('campaign-plan.json', {'purpose':'Qualify the exact Art/Architecture union reconciled with Goblin001/AMBIENT001, strict regressions and ordinary native lifecycle; no actual-model, Windows, graphical or owner acceptance is claimed.',
                          'created_utc':datetime.now(timezone.utc).isoformat(),
                          'expected_source':'97585a0af02f1534eb254adf2d2fbe9036a281b2',
                          'cases':planned, 'watchdogs':'Existing regression and operation contracts unchanged',
                          'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
before = identity()
assert before['source']['source_commit'] == '97585a0af02f1534eb254adf2d2fbe9036a281b2'
write('before-identity.json', before)
results = []
for name in names+['combined-author','combined-reopen']:
    combined = name.startswith('combined-')
    case = cases['test_workbench_combined_authoring' if combined else name]
    output = OUT/name
    output.mkdir()
    profile = OUT/('combined-profile' if combined else name+'-profile')
    env = dict(os.environ, XDG_DATA_HOME=str(profile), XDG_CONFIG_HOME=str(profile/'config'),
               GODOT_SILENCE_ROOT_WARNING='1', CYBERSAND_SOURCE_REVISION=before['source']['source_commit'])
    if combined:
        env['WB_COMBINED_SIDE']='512'
        env['WB_COMBINED_WORKERS']='1'
        if name == 'combined-reopen': env['WB_COMBINED_REOPEN']='1'
    with (output/'runner.txt').open('w') as stream, contextlib.redirect_stdout(stream):
        result, failed = regressions.run_case(str(ENGINE), case, output, 'primary', env=env)
    result['qualification_name'] = name
    result['fail_boolean'] = failed
    text = (output/result['log']).read_text()
    result['receipt_lines'] = [line for line in text.splitlines() if
                              ('_RESULT ' in line or line.startswith('WB_COMBINED_EVIDENCE '))]
    results.append(result)
    write('results.json', results)
    print(json.dumps({'case':name,'status':result['status'],'seconds':result['seconds'],
                      'diagnostic_error':result['diagnostic_error'],'failed':failed}),flush=True)
after = identity()
write('after-identity.json', after)
unchanged = before == after
write('summary.json', {'source':before['source']['source_commit'],
                      'tree':before['source']['source_tree'],
                      'source_runtime_project_engine_unchanged':unchanged,
                      'cases':len(results), 'passed':sum(not item['fail_boolean'] for item in results),
                      'failed':sum(item['fail_boolean'] for item in results),
                      'seconds':round(sum(item['seconds'] for item in results),3),
                      'completed_utc':datetime.now(timezone.utc).isoformat(),
                      'status':'PASS' if unchanged and not any(item['fail_boolean'] for item in results) else 'FAIL',
                      'scope':'Linux pinned Godot 4.7, source-matched native/Rapier; deterministic loopback; headless; no model or owner acceptance'})
assert unchanged, 'Qualification identity moved'
sys.exit(1 if any(item['fail_boolean'] for item in results) else 0)
