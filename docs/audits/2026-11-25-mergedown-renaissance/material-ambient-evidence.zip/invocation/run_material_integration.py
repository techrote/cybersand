import json
import os
from pathlib import Path
import sys

root = Path('/workspace/scratch/2e90cf7b4aa3/cybersand-material')
out = Path(sys.argv[1]).resolve()
out.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root / 'tools'), str(root / 'tools/ci')]
import qualify_workbench_landscapes as q
import run_godot_regressions as r

godot = '/workspace/scratch/2e90cf7b4aa3/deps/godot-4.7/Godot_v4.7-stable_linux.x86_64'
def identity():
    current = {'source': q.source_identity(), 'runtime': q.verify_runtime_identity()}
    current['project'] = q.project_identity(root / 'godot', current['source'], current['runtime'])
    return current

before = identity()
(out / 'identity-before.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, XDG_DATA_HOME=str(out / 'profile'), XDG_CONFIG_HOME=str(out / 'config'),
           GODOT_SILENCE_ROOT_WARNING='1', CYBERSAND_SOURCE_REVISION=before['source']['source_commit'])
selected = [c for c in r.discover_cases() if c.name in sys.argv[2:]]
if len(selected) != len(sys.argv[2:]):
    raise RuntimeError('Requested cases must each appear exactly once in the current registry')
cases = [r.Case('import', ('--editor', '--quit'), r.execution_policy.watchdog_seconds('godot_import_seconds'), 3.0)] + selected
result = {'source': before['source']['source_commit'], 'tree': before['source'].get('source_tree'),
          'scope': 'Targeted resulting-source Linux qualification; no full Windows or owner acceptance claim',
          'planned': [c.name for c in cases], 'results': [], 'status': 'running'}
try:
    for case in cases:
        record, failed = r.run_case(godot, case, out, 'preflight' if case.name == 'import' else 'primary', env=env)
        result['results'].append(record)
        (out / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
        if failed:
            raise RuntimeError('Strict case failed: ' + case.name)
    after = identity()
    (out / 'identity-after.json').write_text(json.dumps(after, indent=2) + '\n')
    if after != before:
        raise RuntimeError('Source/runtime/project moved during measured execution')
    result['status'] = 'passed'
except BaseException as exc:
    result.update(status='failed', error=str(exc))
    raise
finally:
    (out / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'source': result['source'], 'cases': len(result['results'])}))
