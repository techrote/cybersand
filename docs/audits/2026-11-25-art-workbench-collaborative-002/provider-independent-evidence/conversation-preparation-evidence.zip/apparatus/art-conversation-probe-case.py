#!/usr/bin/env python3
"""One source-bound collaborative case, never a full qualification receipt."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import platform
import resource
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--sha", required=True)
parser.add_argument("--case", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
source = args.source.resolve()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location("art_gates", source / "tools/ci/run_art_collaborative_gates.py")
gates = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gates)
assert args.case in gates.TESTS
godot = Path("/workspace/scratch/051e78157ffb/runtime/godot-4.7/Godot_v4.7-stable_linux.x86_64")

def memory():
    return [line for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith(("MemTotal", "MemAvailable", "SwapTotal", "Shmem:"))]

env = os.environ.copy()
for key, folder in (("XDG_DATA_HOME", "profile"), ("XDG_CONFIG_HOME", "profile/config"),
                    ("XDG_CACHE_HOME", "profile/cache")):
    env[key] = str(output / folder)
env["CYBERSAND_SOURCE_REVISION"] = args.sha
env["CYBERSAND_TEST_ARTIFACT_DIR"] = str(output / "artifacts")
command = [str(godot), "--headless", "--path", str(source / "godot"), "--audio-driver", "Dummy",
           "--script", "res://tests/" + args.case + ".gd"]
receipt = {"scope": "One actual source-bound case; not the complete collaborative suite or package qualification",
           "source_before": gates.source_identity(output / "source-before-rejection.json"),
           "command": command, "memory_before": memory(), "host": platform.platform(),
           "godot_sha256": gates.digest(godot),
           "runtime_sha256": {path: gates.digest(source / path) for path in gates.RUNTIME_PATHS["linux"]}}
assert receipt["source_before"]["commit"] == args.sha
(output / "admission.json").write_text(json.dumps(receipt, indent=2) + "\n")
began = time.monotonic()
timed_out = False
with (output / "output.log").open("wb") as stream:
    process = subprocess.Popen(command, env=env, cwd=source, stdout=stream, stderr=subprocess.STDOUT)
    try:
        process.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        process.wait(timeout=10)
log = (output / "output.log").read_bytes()
text = log.decode(errors="replace")
error = ""
result = None
source_after = None
try:
    result = gates.parse_case_output(text, gates.TESTS[args.case])
except (ValueError, AssertionError) as failure:
    error = str(failure)
try:
    source_after = gates.source_identity(output / "source-after-rejection.json")
    assert source_after == receipt["source_before"], "Source identity changed during the case"
except (ValueError, AssertionError) as failure:
    error += ("; " if error else "") + str(failure)
receipt.update({"source_after": source_after, "exit_code": process.returncode, "timed_out": timed_out,
                "elapsed_seconds": time.monotonic() - began, "memory_after": memory(),
                "max_child_rss_kib": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                "result": result, "log_sha256": hashlib.sha256(log).hexdigest(),
                "error": error, "passed": process.returncode == 0 and not timed_out and not error,
                "engine_error_lines": [line for line in text.splitlines()
                                       if line.startswith(("ERROR:", "SCRIPT ERROR:"))]})
(output / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
raise SystemExit(0 if receipt["passed"] else 1)
