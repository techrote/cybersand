@echo off
setlocal
cd /d "%~dp0"
if not exist "profile" mkdir "profile"
if not exist "diagnostics" mkdir "diagnostics"
set "APPDATA=%~dp0profile"
set "LOCALAPPDATA=%~dp0profile-local"
set "CYBERSAND_SOURCE_REVISION=bcc92927ce3894a16d5544923cfbf7b1d0339fda"
set "WB_ART_DIAGNOSTIC_PATH=%~dp0diagnostics\art-responsiveness.json"
set "ART_EVALUATOR_RENDER_ARGS="
if "%WB_ART_EVALUATOR_SOFTWARE%"=="1" set "ART_EVALUATOR_RENDER_ARGS=--rendering-driver opengl3_angle"
if not exist "godot\.godot\global_script_class_cache.cfg" (
  echo Preparing the Workbench for first launch...
  "Godot_v4.7-stable_win64_console.exe" --headless --path "%~dp0godot" --editor --import > "diagnostics\import.log" 2>&1
  if errorlevel 1 goto failed
)
"Godot_v4.7-stable_win64_console.exe" --path "%~dp0godot" --resolution 1280x720 %ART_EVALUATOR_RENDER_ARGS% --script res://tests/run_art_owner_evaluator.gd > "diagnostics\workbench.log" 2>&1
if errorlevel 1 goto failed
exit /b 0
:failed
echo Workbench could not start. See diagnostics\import.log and diagnostics\workbench.log.
if not defined WB_ART_EVALUATOR_SMOKE_SECONDS pause
exit /b 1
