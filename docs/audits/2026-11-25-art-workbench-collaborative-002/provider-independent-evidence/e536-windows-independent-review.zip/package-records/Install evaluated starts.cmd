@echo off
setlocal
set "ART_EXAMPLE_DEST=%~dp0profile\Godot\app_userdata\Cyber Sand Reference Sandbox\workbench"
if not exist "%ART_EXAMPLE_DEST%" mkdir "%ART_EXAMPLE_DEST%"
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-industrial_repair.json" copy /b "%~dp0examples\art-collaborative-evaluated\00-industrial_repair-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-industrial_repair.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-structural_facade.json" copy /b "%~dp0examples\art-collaborative-evaluated\01-structural_facade-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-structural_facade.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-scifi_interior.json" copy /b "%~dp0examples\art-collaborative-evaluated\02-scifi_interior-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-scifi_interior.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-revised_arcology.json" copy /b "%~dp0examples\art-collaborative-evaluated\03-revised_arcology-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-revised_arcology.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-protected_courtyard.json" copy /b "%~dp0examples\art-collaborative-evaluated\04-protected_courtyard-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-protected_courtyard.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-palette_foundry.json" copy /b "%~dp0examples\art-collaborative-evaluated\05-palette_foundry-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-palette_foundry.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-stopped_workshop.json" copy /b "%~dp0examples\art-collaborative-evaluated\06-stopped_workshop-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-stopped_workshop.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-staged_megaframe.json" copy /b "%~dp0examples\art-collaborative-evaluated\07-staged_megaframe-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-staged_megaframe.json" >nul
if errorlevel 1 exit /b 1
if not exist "%ART_EXAMPLE_DEST%\setup-art02-xeno_vault.json" copy /b "%~dp0examples\art-collaborative-evaluated\08-xeno_vault-editable-setup.json" "%ART_EXAMPLE_DEST%\setup-art02-xeno_vault.json" >nul
if errorlevel 1 exit /b 1
echo Evaluated starts installed without replacing existing saved starts.
echo In Workbench, enter one of these names and click Load start:
echo art02-industrial_repair
echo art02-structural_facade
echo art02-scifi_interior
echo art02-revised_arcology
echo art02-protected_courtyard
echo art02-palette_foundry
echo art02-stopped_workshop
echo art02-staged_megaframe
echo art02-xeno_vault
exit /b 0
