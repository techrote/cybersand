extends SceneTree
const Experiment = preload("res://scripts/render_upload_experiment.gd")
func _init(): call_deferred("_run")
func _run():
	var controller = Experiment.new()
	var image := Image.create_empty(257, 263, false, Image.FORMAT_RG8)
	image.fill(Color(1.0 / 255, 12.0 / 255, 0, 1))
	print("HELPER_INITIALIZE ", controller.initialize(image, 0, 1), " ", controller.last_error, " ", controller.canary_result)
	if not controller.initialized:
		quit(1)
		return
	for serial in range(1, 4):
		var prior: Image = image.duplicate()
		var point := Vector2i(0, 0) if serial != 2 else Vector2i(256, 262)
		image.set_pixelv(point, Color(float(serial + 2) / 255, float(serial * 51) / 255, 0, 1))
		var result: Dictionary = controller.publish(image, PackedInt32Array([point.x, point.y, 1, 1, 0, 2]), serial, 1, false)
		await RenderingServer.frame_post_draw
		var current: Image = controller.current.get_image()
		var previous: Image = controller.previous.get_image()
		current.convert(Image.FORMAT_RG8)
		previous.convert(Image.FORMAT_RG8)
		print("HELPER_PUBLICATION ", serial, " accepted=", result.accepted, " current=", current.get_data() == image.get_data(), " previous=", previous.get_data() == prior.get_data(), " metrics=", result.metrics)
		if not result.accepted or current.get_data() != image.get_data() or previous.get_data() != prior.get_data():
			controller.close()
			quit(2)
			return
	controller.close()
	print("HELPER_SMOKE_PASS")
	quit()
