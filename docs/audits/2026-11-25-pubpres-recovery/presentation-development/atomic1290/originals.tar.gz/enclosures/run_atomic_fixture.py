import argparse, datetime, hashlib, json, os, subprocess, time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--project', default='/workspace/scratch/8a0b6cd48416/pubpres-presentation')
parser.add_argument('--engine', default='/workspace/scratch/8a0b6cd48416/engine-source/bin/godot.linuxbsd.template_debug.x86_64')
parser.add_argument('--thread', choices=['safe','separate'], default='safe')
parser.add_argument('--budget', choices=['0','4'], default='0')
parser.add_argument('--timeout', type=float, default=240)
a = parser.parse_args()
project = Path(a.project)
out = Path('/workspace/scratch/8a0b6cd48416/presentation-evidence') / a.label
out.mkdir(exist_ok=False)
stop = out/'STOP'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip()
env = {key:value for key,value in os.environ.items() if not key.startswith(('CYBERSAND_','WB_COMBINED_'))}
env.update(DISPLAY='127.0.0.1:97',CYBERSAND_SOURCE_REVISION=revision,
    XDG_DATA_HOME=str(out/'profile'), LIBGL_ALWAYS_SOFTWARE='1',
    DBUS_SESSION_BUS_ADDRESS='unix:path=/tmp/cybersand-presentation-absent-session-bus',
    CYBERSAND_ENGINE_RENDER_LOOKAHEAD=a.budget,
    CYBERSAND_DIAG_ACTUAL_SUBMISSION='1', CYBERSAND_DIAG_WATER_COMPOSITION='0',
    CYBERSAND_MATERIAL_PUBLICATION='full', CYBERSAND_DIAG_FULL_IMAGE_SLOTS='2',
    CYBERSAND_DIAG_MATERIAL_DEADLINE_HZ='0', CYBERSAND_DIAG_MATERIAL_STEP_INTERVAL='0',
    CYBERSAND_DIAG_SAME_FRAME_CONTINUATION='0', CYBERSAND_DIAG_PHYSICS_PUBLICATION='early',
    CYBERSAND_MATERIAL_QUEUE_THREAD=a.thread, CYBERSAND_PLAYABILITY_RENDER_THREAD=a.thread,
    CYBERSAND_ENGINE_RENDER_LOOKAHEAD_TRACE=str(out/'engine.json'))
cmd=[a.engine,'--path',str(project/'godot'),'--rendering-method','gl_compatibility',
     '--render-thread',a.thread,'--audio-driver','Dummy',
     '--script','res://tests/test_workbench_presentation_submission.gd','--',
     '--submission-evidence='+str(out/'receipt.json')]
record={'schema':'pubpres-local-atomic-graphical-launch-v1','application_source':revision,
        'engine_sha256':sha(a.engine),'argv':cmd,'thread':a.thread,'budget':a.budget,
        'host_scope':'Linux Xorg dummy Mesa llvmpipe; developmental engine; no Windows/NVIDIA claim',
        'native_sha256':sha(project/'godot/addons/cybersand_native/bin/libcybersand_native.linux.x86_64.so'),
        'rapier_sha256':sha(project/'godot/addons/godot-rapier2d/bin/libgodot_rapier.linux.x86_64-unknown-linux-gnu.so'),
        'input_hashes':{p:sha(project/p) for p in [
            'godot/scripts/main.gd','godot/scripts/workbench_presentation_submission.gd',
            'godot/tests/test_workbench_presentation_submission.gd','godot/scripts/simulation_worker.gd',
            'godot/scripts/shared_workbench.gd','godot/scripts/physical_actor_overlay.gd']},
        'environment':{key:value for key,value in env.items() if key.startswith('CYBERSAND_') or key in ['DISPLAY','DBUS_SESSION_BUS_ADDRESS','LIBGL_ALWAYS_SOFTWARE']},
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
x=subprocess.Popen(['Xorg',':97','-config','/workspace/scratch/8a0b6cd48416/local-graphics/xorg.conf',
    '-logfile',str(out/'xorg.log'),'-noreset','-nolisten','unix','-listen','tcp','-ac'],
    stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
p=None
try:
    time.sleep(1)
    with (out/'process.log').open('w') as log:
        p=subprocess.Popen(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+a.timeout
        while p.poll() is None and not stop.exists() and time.monotonic()<deadline:
            time.sleep(0.2)
        if p.poll() is None:
            record['interruption']='requested' if stop.exists() else 'timeout'
            p.terminate()
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        record['exit_code']=p.returncode
finally:
    if p is not None and p.poll() is None:p.kill();p.wait()
    x.terminate()
    try:x.wait(timeout=5)
    except subprocess.TimeoutExpired:x.kill();x.wait()
    record['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['fixture_receipt_present']=(out/'receipt.json').exists()
    (out/'launch.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((out/'process.log').read_text()[-20000:])
