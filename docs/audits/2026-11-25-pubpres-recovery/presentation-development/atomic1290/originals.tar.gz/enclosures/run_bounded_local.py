"""Local display/process enclosure; exact committed recovery driver owns every gate."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--label', required=True)
p.add_argument('--mode', choices=['observer-abba', 'cohort'], required=True)
p.add_argument('--calibration-engine', choices=['stock', 'bounded'], default='bounded')
p.add_argument('--observer-calibration', action='append', default=[])
p.add_argument('--timeout', type=float, default=7200)
p.add_argument('--display-number', type=int, default=95)
a = p.parse_args()
base = Path('/workspace/scratch/8a0b6cd48416')
source = base/'pubpres-presentation'
out = base/'presentation-evidence'/a.label
out.mkdir(exist_ok=False)
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert revision == '1290c31dc262cdc6d31e9d53bde80fe3527585d7'
display = '127.0.0.1:'+str(a.display_number)
dbus = 'unix:path=/tmp/cybersand-bounded-local-absent-session-bus'
record = {'schema': 'pubpres-recovery-external-local-display-v1', 'display': display,
    'dbus_session_bus_address': dbus, 'source_commit': revision,
    'scope': 'Linux Xorg dummy Mesa llvmpipe, isolated local quiet window; no physical hardware claim.',
    'xorg_config_sha256': hashlib.sha256((base/'local-graphics/xorg.conf').read_bytes()).hexdigest()}
(out/'display.json').write_text(json.dumps(record, indent=2)+'\n')
env = {k:v for k,v in os.environ.items() if not k.startswith(('CYBERSAND_', 'WB_COMBINED_'))}
env.update(DISPLAY=display, DBUS_SESSION_BUS_ADDRESS=dbus, LIBGL_ALWAYS_SOFTWARE='1')
command = ['python3', str(source/'tools/pubpres_final_recovery/run_bounded_comparison.py'),
    '--source', str(source), '--runtime', str(base/'recovery-evidence/runtime-linux-1290'),
    '--stock-engine', str(base/'runtime-cache/Godot_v4.7-stable_linux.x86_64'),
    '--development-engine', str(base/'engine-source/bin/godot.linuxbsd.template_debug.x86_64'),
    '--development-engine-proof', str(source/'docs/audits/2026-11-25-pubpres-recovery/atomic-linux-development-02/proof.json'),
    '--development-gates', str(base/'presentation-evidence/atomic1290-integration-gates.json'),
    '--external-display-record', str(out/'display.json'), '--water-composition', '0',
    '--case', 'wave_512_follow', '--case', 'wave_gameplay_2048_follow',
    '--mode', a.mode, '--calibration-engine', a.calibration_engine,
    '--output', str(out/'campaign')]
for value in a.observer_calibration:
    command.extend(['--observer-calibration', value])
launch = {'schema': 'pubpres-local-bounded-campaign-launch-v1', 'application_source': revision,
    'argv': command, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment': {'DISPLAY': display, 'DBUS_SESSION_BUS_ADDRESS': dbus, 'LIBGL_ALWAYS_SOFTWARE': '1'}}
(out/'launch.json').write_text(json.dumps(launch, indent=2)+'\n')
server_log = (out/'xorg-console.log').open('w')
server = subprocess.Popen(['Xorg', ':'+str(a.display_number), '-config', str(base/'local-graphics/xorg.conf'),
    '-logfile', str(out/'xorg.log'), '-noreset', '-nolisten', 'unix', '-listen', 'tcp', '-ac'],
    stdout=server_log, stderr=subprocess.STDOUT)
child = None
try:
    time.sleep(1)
    if server.poll() is not None:
        raise RuntimeError('Xorg did not stay alive')
    with (out/'runner.log').open('w') as log:
        child = subprocess.Popen(command, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True)
        deadline = time.monotonic()+a.timeout
        while child.poll() is None and not (out/'STOP').exists() and time.monotonic()<deadline:
            time.sleep(0.25)
        if child.poll() is None:
            launch['interruption'] = 'requested' if (out/'STOP').exists() else 'timeout'
            import signal
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        launch['exit_code'] = child.returncode
finally:
    if child is not None and child.poll() is None:
        child.terminate()
        child.wait(timeout=10)
    server.terminate()
    try: server.wait(timeout=5)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait()
    server_log.close()
    launch['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/'launch.json').write_text(json.dumps(launch, indent=2)+'\n')
print(json.dumps(launch, indent=2))
print((out/'runner.log').read_text()[-15000:])
raise SystemExit(launch.get('exit_code', 1))
